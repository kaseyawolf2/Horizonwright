# Baritone 1.12.2 → 1.7.10 Porting Guide

Target: Minecraft 1.7.10, Forge 10.13.4.1614, built with GTNH RetroFuturaGradle + UniMixins.
Java level: 8 (Jabel allows modern syntax, but stick to what the code already uses).

## Compat layer (`baritone.compat.*`)

These classes reimplement 1.8+ vanilla APIs. Imports were already mass-rewritten to point here:

| Compat class | Replaces | Notes |
|---|---|---|
| `BlockPos`, `BlockPos.MutableBlockPos` | `net.minecraft.util.math.BlockPos` | full 1.12 API: `up/down/north/south/east/west/offset/add/subtract/toLong/fromLong/getAllInBox` |
| `Vec3i` | `net.minecraft.util.math.Vec3i` | |
| `Vec3d` | `net.minecraft.util.math.Vec3d` | public final `x,y,z`; `toVec3()`/`new Vec3d(Vec3)` convert to/from 1.7.10 `Vec3` |
| `ChunkPos` | `net.minecraft.util.math.ChunkPos` | `asLong(x,z)` matches 1.7.10 `ChunkCoordIntPair.chunkXZ2Int` packing |
| `EnumFacing` (+`Axis`, `AxisDirection`, `Plane`) | `net.minecraft.util.EnumFacing` | `getIndex()` == 1.7.10 side int == ForgeDirection ordinal; `toForge()`/`fromForge()` |
| `IBlockState` | `net.minecraft.block.state.IBlockState` | interned (Block, meta) pair. `IBlockState.of(block)`, `of(block, meta)`, `getBlock()`, `getMeta()`. Same (block,meta) ⇒ same instance, so `==` works |
| `MathHelper` | `net.minecraft.util.math.MathHelper` | pure-java: `sqrt/floor/ceil/clamp/cos/sin/atan2/wrapDegrees` |
| `RayTraceResult` | `net.minecraft.util.math.RayTraceResult` | wrap vanilla with `RayTraceResult.fromVanilla(mop)`; has `typeOfHit`, `hitVec`, `sideHit` (compat EnumFacing), `getBlockPos()`, `entityHit` |
| `EnumHand` | `net.minecraft.util.EnumHand` | no offhand in 1.7.10; both constants = main hand |
| `GlStateManager` | `net.minecraft.client.renderer.GlStateManager` | delegates to GL11 |
| `Blocks` / `Items` | `net.minecraft.init.Blocks/Items` | 1.12 CONSTANT_NAMES aliased to 1.7.10 registry objects. Post-1.7.10 blocks/items (MAGMA, shulker boxes, ELYTRA, …) are `null` — `==` checks vs them are simply false. Never use a null constant as a map key / switch case |
| `Compat` | static bridges | `getBlockState(world,pos)`, `getBlockState(chunk,x,y,z)`, `setBlockState`, `isAirBlock`, `aabb(...)` (replaces `new AxisAlignedBB(...)`), `getPositionVector(entity)`, `getPositionEyes(entity,pt)`, `getLook(entity,pt)`, `sendMessage(player, comp)` |

Already applied by script across the tree: import rewrites, `TextFormatting`→`EnumChatFormatting`, `ITextComponent`→`IChatComponent`, `TextComponentString`→`ChatComponentText`, `new AxisAlignedBB(`→`Compat.aabb(`, `X.getDefaultState()`→`IBlockState.of(X)`, `x.getBlockState(y)`→`Compat.getBlockState(x, y)`, `mc.player`→`mc.thePlayer`, `mc.world`→`mc.theWorld`, `.addScheduledTask(`→`.func_152344_a(`, `.isCallingFromMinecraftThread()`→`.func_152345_ab()`, `.getStyle()`→`.getChatStyle()`, `.setStyle(`→`.setChatStyle(`, `.getEntityBoundingBox()`→`.boundingBox`.

## Frequent API mappings (do these at call sites)

### Minecraft / player / world
- `mc.thePlayer` is `EntityClientPlayerMP` (extends `EntityPlayerSP`). `mc.theWorld` is `WorldClient`.
- `player.connection` → `player.sendQueue` (type `NetHandlerPlayClient`); `.sendPacket(p)` → `.addToSendQueue(p)`; `.getNetworkManager()` exists.
- `player.getHeldItemMainhand()` → `player.getHeldItem()` (may return **null**).
- `player.swingArm(EnumHand.MAIN_HAND)` → `player.swingItem()`.
- `player.sendChatMessage(String)` — exists on `EntityClientPlayerMP` (1.7.10).
- `entity.world` → `entity.worldObj`; `entity.getEntityWorld()` → `entity.worldObj`.
- `world.isAirBlock(pos)` → `world.isAirBlock(x, y, z)`; `world.getBlock(x,y,z)`, `world.getBlockMetadata(x,y,z)` are the primitives.
- `world.getChunk(cx, cz)` → `world.getChunkFromChunkCoords(cx, cz)`.
- `chunk.x` / `chunk.z` → `chunk.xPosition` / `chunk.zPosition`; `chunk.isLoaded()` → `chunk.isChunkLoaded` (field).
- `world.getWorldBorder()` — **does not exist** (world border is 1.8+). `BetterWorldBorder` becomes a permissive stub.
- `world.rayTraceBlocks(...)` takes 1.7.10 `Vec3` (use `vec3d.toVec3()`); result is `MovingObjectPosition` → wrap with `RayTraceResult.fromVanilla`.
- `mc.getRenderManager().viewerPosX/Y/Z` → static `RenderManager.instance.viewerPosX` etc., or `RenderManager.renderPosX`.
- `mc.getConnection()` → `mc.getNetHandler()`.
- Game type: `net.minecraft.world.GameType` → `net.minecraft.world.WorldSettings.GameType`.
- Scheduled tasks: `mc.func_152344_a(Runnable)` (addScheduledTask) / `mc.func_152345_ab()` (isCallingFromMinecraftThread) — these are the real 1.7.10 SRG names, already substituted by script.

### ItemStack — no EMPTY in 1.7.10!
- `ItemStack.EMPTY` → `null`; `stack.isEmpty()` → `stack == null || stack.stackSize == 0`.
- Empty inventory slots are `null`. Guard all `.getItem()` calls accordingly.
- `stack.getCount()` → `stack.stackSize`; `stack.getMetadata()` → `stack.getItemDamage()`.
- `NonNullList<ItemStack>` → `ItemStack[]` or `List<ItemStack>` (inventory `mainInventory` is `ItemStack[36]`).

### Blocks / states / properties
There are no blockstate properties in 1.7.10 — only metadata. `state.getValue(PROP)` / `.withProperty(...)` must be rewritten as metadata logic:

| 1.12 property | 1.7.10 metadata |
|---|---|
| `BlockLiquid.LEVEL` | meta directly (0 = source, 1–7 flowing, ≥8 falling) |
| door `BlockDoor.OPEN` | lower-half meta bit `0x4`; upper half has bit `0x8` set. `BlockDoor.func_150012_g(world,x,y,z)` returns combined metadata (bit 16 flag = upper) |
| fence gate open | meta bit `0x4`; facing = `meta & 3` |
| `BlockStairs.HALF` (TOP) | meta bit `0x4`; facing = `meta & 3` |
| slab top half | meta bit `0x8` |
| ladder facing | meta 2..5 = attached side (use `EnumFacing.byIndex(meta)`) |
| vine sides | meta bitmask: 1=south, 2=west, 4=north, 8=east (0 = up only) |
| snow layers `BlockSnow.LAYERS` | meta 0–7 = layers−1 |
| farmland moisture | meta 0–7 |
| crops age | wheat/carrots/potatoes meta 0–7; nether wart 0–3; cocoa age = `(meta & 12) >> 2`, facing = `meta & 3` |
| bed part | meta bit `0x8` = head |
| chest/furnace facing | meta 2..5 |

- `block.isPassable(world, pos)` → `block.getBlocksMovement(world, x, y, z)`.
- `Block.REGISTRY.getObject(rl)` → `Block.blockRegistry.getObject(name)`; `Block.getBlockFromName(s)` exists.
- `Block.REGISTRY.getNameForObject(block)` → `Block.blockRegistry.getNameForObject(block)` returns **String** (not ResourceLocation) in 1.7.10.
- `state.getMaterial().isLiquid()/isSolid()/blocksMovement()` — fine, Material API is the same.
- `state.getMobilityFlag()` → `block.getMobilityFlag()` returns int in 1.7.10 (0=normal,1=push-only,2=immovable).

### Effects / enchants / biomes
- `MobEffects.HASTE` → `Potion.digSpeed`; `MobEffects.MINING_FATIGUE` → `Potion.digSlowdown`. `player.isPotionActive(Potion.digSpeed)`, `getActivePotionEffect(...)` exist; `PotionEffect.getAmplifier()` exists.
- `Enchantments.EFFICIENCY` → `Enchantment.efficiency`; `EnchantmentHelper.getEnchantmentLevel(ench.effectId, stack)` (int id, not object!). `Enchantments.SILK_TOUCH` → `Enchantment.silkTouch`. FROST_WALKER doesn't exist — delete the code path.
- `Biomes.FOREST` → `BiomeGenBase.forest`; `world.getBiome(pos)` → `world.getBiomeGenForCoords(x, z)`.

### Text/chat (class renames already applied)
- `comp.getChatStyle().setColor(EnumChatFormatting.RED)`; `ChatStyle` replaces `Style`.
- `ClickEvent`/`HoverEvent` live in `net.minecraft.event`; Action enums are the same.
- `player.addChatMessage(comp)` sends to the client player's chat GUI.
- `comp.getUnformattedText()` / `getFormattedText()` exist in 1.7.10.

### Packets (1.7.10 names)
- `CPacketPlayer` → `C03PacketPlayer` (+ `C04PacketPlayerPosition`, `C05PacketPlayerLook`, `C06PacketPlayerPosLook` subclasses)
- `SPacketBlockChange` → `S23PacketBlockChange`; `SPacketMultiBlockChange` → `S22PacketMultiBlockChange`
- `SPacketChunkData` → `S21PacketChunkData`; `SPacketPlayerPosLook` → `S08PacketPlayerPosLook`
- `SPacketCombatEvent` → `S42PacketCombatEvent`
- All in `net.minecraft.network.play.client` / `.server`.

### Forge / FML (1.7.10 packages!)
- FML classes are under `cpw.mods.fml.*` (NOT `net.minecraftforge.fml.*`): `cpw.mods.fml.common.Mod`, `cpw.mods.fml.common.event.FMLInitializationEvent`, `cpw.mods.fml.common.eventhandler.SubscribeEvent`, `cpw.mods.fml.common.gameevent.TickEvent`.
- Two event buses: `MinecraftForge.EVENT_BUS` (world/render events) and `FMLCommonHandler.instance().bus()` (tick/key/connection events). Register on the right one.
- `RenderWorldLastEvent` ✓ `net.minecraftforge.client.event.RenderWorldLastEvent`, field `partialTicks`.

### Rendering (fixed-function, no BufferBuilder)
```java
Tessellator t = Tessellator.instance;
t.startDrawing(GL11.GL_LINES);      // or GL_QUADS, GL_LINE_STRIP...
t.addVertex(x, y, z);               // repeat
t.draw();
```
No `DefaultVertexFormats`, no `BufferBuilder`, no `GlStateManager` state caching (compat class delegates to GL11 directly). Colors via `GL11.glColor4f` before drawing (glColor works with tessellator when GL_COLOR not in vertex data) or `t.setColorRGBA_F(...)` per vertex.

### Mixins
- UniMixins (Mixin 0.8.5) — annotations and injection points work as in 1.12.2.
- Target method names must be the 1.7.10 MCP names. The decompiled, remapped 1.7.10 + Forge source is available in the Gradle cache (`~/.gradle/caches/retro_futura_gradle/`) — **always verify a target method's exact signature there before writing the mixin**.
- 1.7.10 `Minecraft.runTick`, `EntityPlayerSP.onUpdate`/`onLivingUpdate`, `PlayerControllerMP.onPlayerDamageBlock(int x, int y, int z, int side)`, `NetworkManager.channelRead0`, etc. — signatures differ from 1.12.2; check the source.

## Deleted from scope (do not port; remove references)
- Everything elytra: `ElytraProcess`, `process/elytra/**`, `IElytraProcess`, `ElytraCommand`, firework handling in `LookBehavior`/`PathingBehavior`/mixins.
- Schematica/Litematica integration (`utils/schematic/schematica/**`, `LitematicaSchematic`, `SchematicaCommand`). MCEdit `.schematic` support stays (it's blocks+meta, 1.7.10-native).
- `FasterWorldScanner` (1.12 palette internals). `WorldScanner` is rewritten against 1.7.10 `ExtendedBlockStorage` (`getBlockByExtId(x,y,z)` / `getExtBlockMetadata(x,y,z)`, `getBlockLSBArray()`).
- Tab-completion mixins (`MixinTabCompleter`, `MixinChatTabCompleter`) and 1.8+ palette/render mixins.
- Toasts (`logToast` → route to chat log).
- World border logic (permissive stub).

## Style
- Keep upstream Baritone code style and license headers.
- Prefer the smallest change that compiles and behaves identically on 1.7.10; do not refactor while porting.
- When a 1.12 feature has no 1.7.10 equivalent (e.g. shulker boxes in block lists), delete the entry, don't invent one.
