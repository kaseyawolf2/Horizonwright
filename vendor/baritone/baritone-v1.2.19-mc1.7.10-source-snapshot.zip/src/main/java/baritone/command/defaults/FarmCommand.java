/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.command.defaults;

import baritone.api.IBaritone;
import baritone.api.cache.IWaypoint;
import baritone.api.command.Command;
import baritone.api.command.argument.IArgConsumer;
import baritone.api.command.datatypes.ForWaypoints;
import baritone.api.command.exception.CommandException;
import baritone.api.command.exception.CommandInvalidStateException;
import baritone.api.utils.BetterBlockPos;
import baritone.api.utils.BlockOptionalMeta;
import baritone.api.utils.BlockUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class FarmCommand extends Command {

    public FarmCommand(IBaritone baritone) {
        super(baritone, "farm");
    }

    @Override
    public void execute(String label, IArgConsumer args) throws CommandException {
        int range = 0;
        BetterBlockPos origin = null;
        List<BlockOptionalMeta> crops = new ArrayList<>();

        //optional leading range
        if (args.hasAny() && args.is(Integer.class)) {
            range = args.getAs(Integer.class);
        }

        //the remainder is either a crop-type list ("mod:id[:meta], ...") or a single waypoint
        if (args.hasAny()) {
            String rest = args.rawRest().trim();
            if (looksLikeCropSelector(rest)) {
                crops = parseCrops(rest);
            } else {
                IWaypoint[] waypoints = args.getDatatypeFor(ForWaypoints.INSTANCE);
                IWaypoint waypoint;
                switch (waypoints.length) {
                    case 0:
                        throw new CommandInvalidStateException("No waypoints found");
                    case 1:
                        waypoint = waypoints[0];
                        break;
                    default:
                        throw new CommandInvalidStateException("Multiple waypoints were found");
                }
                origin = waypoint.getLocation();
            }
        }

        baritone.getFarmProcess().farm(range, origin, crops);
        if (crops.isEmpty()) {
            logDirect("Farming");
        } else {
            logDirect("Farming (also right-click harvesting: " + describe(crops) + ")");
        }
    }

    private static String describe(List<BlockOptionalMeta> crops) {
        StringBuilder sb = new StringBuilder();
        for (BlockOptionalMeta bom : crops) {
            if (sb.length() > 0) {
                sb.append(", ");
            }
            sb.append(BlockUtils.blockToString(bom.getBlock()));
            if (bom.getMeta() != null) {
                sb.append(':').append(bom.getMeta());
            }
        }
        return sb.toString();
    }

    /**
     * Crop selectors always carry a namespace colon ({@code mod:id}) and may be comma-separated;
     * a plain waypoint name has neither, so those two signals disambiguate the tail without
     * colliding with the legacy {@code farm <range> <waypoint>} form.
     */
    private static boolean looksLikeCropSelector(String rest) {
        return rest.indexOf(':') >= 0 || rest.indexOf(',') >= 0;
    }

    private static List<BlockOptionalMeta> parseCrops(String rest) throws CommandException {
        List<BlockOptionalMeta> crops = new ArrayList<>();
        for (String piece : rest.split(",")) {
            String selector = piece.trim();
            if (selector.isEmpty()) {
                continue;
            }
            try {
                crops.add(new BlockOptionalMeta(selector));
            } catch (IllegalArgumentException e) {
                throw new CommandInvalidStateException("Invalid crop '" + selector + "': " + e.getMessage());
            }
        }
        if (crops.isEmpty()) {
            throw new CommandInvalidStateException("No valid crop types were given");
        }
        return crops;
    }

    @Override
    public Stream<String> tabComplete(String label, IArgConsumer args) {
        return Stream.empty();
    }

    @Override
    public String getShortDesc() {
        return "Farm nearby crops";
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList(
                "The farm command starts farming nearby plants. It harvests mature crops and plants new ones.",
                "",
                "By default crops are harvested by right-clicking (works on vanilla and modded crops on packs",
                "with right-click harvest, e.g. GTNH) and any nearby mature IGrowable crop is detected",
                "automatically - so most modded crops need no naming. Toggle with the farmRightClickHarvest",
                "and farmAutoDetectCrops settings.",
                "",
                "You can still name specific crops as 'mod:id' selectors (useful for crops that aren't",
                "auto-detected, like berry bushes). If such a crop isn't an IGrowable, append the mature",
                "metadata as ':meta' so Baritone knows when it's ripe.",
                "",
                "Usage:",
                "> farm - farms every vanilla crop it can find.",
                "> farm <range> - farm crops within range from the starting position.",
                "> farm <range> <waypoint> - farm crops within range from waypoint.",
                "> farm <mod:id>[, <mod:id>...] - also right-click harvest the named modded crops.",
                "> farm <range> <mod:id>[, ...] - both, e.g. 'farm 30 Natura:N Crops'.",
                "> farm <mod:id:meta> - right-click harvest that crop only at the given ripe metadata."
        );
    }
}
