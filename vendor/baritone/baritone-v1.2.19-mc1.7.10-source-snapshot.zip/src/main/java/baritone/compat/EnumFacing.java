/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.compat;

import net.minecraftforge.common.util.ForgeDirection;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.function.Predicate;

/**
 * Backport of the 1.8+ {@code net.minecraft.util.EnumFacing} API for 1.7.10.
 * <p>
 * The ordinal order (DOWN, UP, NORTH, SOUTH, WEST, EAST) matches both the 1.8+ EnumFacing index
 * and the classic 1.7.10 side integers, as well as {@link ForgeDirection} ordinals, so
 * {@link #getIndex()} can be passed directly to 1.7.10 methods taking an int side.
 */
public enum EnumFacing {

    DOWN(0, 1, -1, "down", AxisDirection.NEGATIVE, Axis.Y, new Vec3i(0, -1, 0)),
    UP(1, 0, -1, "up", AxisDirection.POSITIVE, Axis.Y, new Vec3i(0, 1, 0)),
    NORTH(2, 3, 2, "north", AxisDirection.NEGATIVE, Axis.Z, new Vec3i(0, 0, -1)),
    SOUTH(3, 2, 0, "south", AxisDirection.POSITIVE, Axis.Z, new Vec3i(0, 0, 1)),
    WEST(4, 5, 1, "west", AxisDirection.NEGATIVE, Axis.X, new Vec3i(-1, 0, 0)),
    EAST(5, 4, 3, "east", AxisDirection.POSITIVE, Axis.X, new Vec3i(1, 0, 0));

    private final int index;
    private final int opposite;
    private final int horizontalIndex;
    private final String name;
    private final Axis axis;
    private final AxisDirection axisDirection;
    private final Vec3i directionVec;

    public static final EnumFacing[] VALUES = values();
    public static final EnumFacing[] HORIZONTALS = {SOUTH, WEST, NORTH, EAST};

    EnumFacing(int index, int opposite, int horizontalIndex, String name, AxisDirection axisDirection, Axis axis, Vec3i directionVec) {
        this.index = index;
        this.opposite = opposite;
        this.horizontalIndex = horizontalIndex;
        this.name = name;
        this.axis = axis;
        this.axisDirection = axisDirection;
        this.directionVec = directionVec;
    }

    public int getIndex() {
        return this.index;
    }

    public int getHorizontalIndex() {
        return this.horizontalIndex;
    }

    public AxisDirection getAxisDirection() {
        return this.axisDirection;
    }

    public EnumFacing getOpposite() {
        return VALUES[this.opposite];
    }

    public EnumFacing rotateY() {
        switch (this) {
            case NORTH:
                return EAST;
            case EAST:
                return SOUTH;
            case SOUTH:
                return WEST;
            case WEST:
                return NORTH;
            default:
                throw new IllegalStateException("Unable to get Y-rotated facing of " + this);
        }
    }

    public EnumFacing rotateYCCW() {
        switch (this) {
            case NORTH:
                return WEST;
            case EAST:
                return NORTH;
            case SOUTH:
                return EAST;
            case WEST:
                return SOUTH;
            default:
                throw new IllegalStateException("Unable to get CCW facing of " + this);
        }
    }

    public int getXOffset() {
        return this.axis == Axis.X ? this.axisDirection.getOffset() : 0;
    }

    public int getYOffset() {
        return this.axis == Axis.Y ? this.axisDirection.getOffset() : 0;
    }

    public int getZOffset() {
        return this.axis == Axis.Z ? this.axisDirection.getOffset() : 0;
    }

    // pre-1.12 MCP names, used in some places
    public int getFrontOffsetX() {
        return getXOffset();
    }

    public int getFrontOffsetY() {
        return getYOffset();
    }

    public int getFrontOffsetZ() {
        return getZOffset();
    }

    public String getName2() {
        return this.name;
    }

    public String getName() {
        return this.name;
    }

    public Axis getAxis() {
        return this.axis;
    }

    public static EnumFacing byName(String name) {
        if (name == null) {
            return null;
        }
        for (EnumFacing facing : VALUES) {
            if (facing.name.equalsIgnoreCase(name)) {
                return facing;
            }
        }
        return null;
    }

    public static EnumFacing byIndex(int index) {
        return VALUES[Math.abs(index % VALUES.length)];
    }

    // pre-1.12 MCP name
    public static EnumFacing getFront(int index) {
        return byIndex(index);
    }

    public static EnumFacing byHorizontalIndex(int horizontalIndexIn) {
        return HORIZONTALS[Math.abs(horizontalIndexIn % HORIZONTALS.length)];
    }

    // pre-1.12 MCP name
    public static EnumFacing getHorizontal(int horizontalIndexIn) {
        return byHorizontalIndex(horizontalIndexIn);
    }

    public static EnumFacing fromAngle(double angle) {
        return byHorizontalIndex(MathHelper.floor(angle / 90.0D + 0.5D) & 3);
    }

    public float getHorizontalAngle() {
        return (float) ((this.horizontalIndex & 3) * 90);
    }

    public static EnumFacing random(Random rand) {
        return VALUES[rand.nextInt(VALUES.length)];
    }

    public static EnumFacing getFacingFromVector(float x, float y, float z) {
        EnumFacing result = NORTH;
        float best = Float.MIN_VALUE;
        for (EnumFacing facing : VALUES) {
            float dot = x * facing.directionVec.getX() + y * facing.directionVec.getY() + z * facing.directionVec.getZ();
            if (dot > best) {
                best = dot;
                result = facing;
            }
        }
        return result;
    }

    public static EnumFacing getFacingFromAxis(AxisDirection axisDirection, Axis axis) {
        for (EnumFacing facing : VALUES) {
            if (facing.getAxisDirection() == axisDirection && facing.getAxis() == axis) {
                return facing;
            }
        }
        throw new IllegalArgumentException("No such direction: " + axisDirection + " " + axis);
    }

    public Vec3i getDirectionVec() {
        return this.directionVec;
    }

    /**
     * @return the equivalent 1.7.10 ForgeDirection (ordinals match)
     */
    public ForgeDirection toForge() {
        return ForgeDirection.getOrientation(this.index);
    }

    public static EnumFacing fromForge(ForgeDirection dir) {
        if (dir == null || dir == ForgeDirection.UNKNOWN) {
            return null;
        }
        return VALUES[dir.ordinal()];
    }

    @Override
    public String toString() {
        return this.name;
    }

    public enum Axis implements Predicate<EnumFacing> {
        X("x", Plane.HORIZONTAL),
        Y("y", Plane.VERTICAL),
        Z("z", Plane.HORIZONTAL);

        private final String name;
        private final Plane plane;

        Axis(String name, Plane plane) {
            this.name = name;
            this.plane = plane;
        }

        public static Axis byName(String name) {
            if (name == null) {
                return null;
            }
            for (Axis axis : values()) {
                if (axis.name.equalsIgnoreCase(name)) {
                    return axis;
                }
            }
            return null;
        }

        public String getName2() {
            return this.name;
        }

        public String getName() {
            return this.name;
        }

        public boolean isVertical() {
            return this.plane == Plane.VERTICAL;
        }

        public boolean isHorizontal() {
            return this.plane == Plane.HORIZONTAL;
        }

        @Override
        public String toString() {
            return this.name;
        }

        @Override
        public boolean test(EnumFacing facing) {
            return facing != null && facing.getAxis() == this;
        }

        public Plane getPlane() {
            return this.plane;
        }
    }

    public enum AxisDirection {
        POSITIVE(1, "Towards positive"),
        NEGATIVE(-1, "Towards negative");

        private final int offset;
        private final String description;

        AxisDirection(int offset, String description) {
            this.offset = offset;
            this.description = description;
        }

        public int getOffset() {
            return this.offset;
        }

        @Override
        public String toString() {
            return this.description;
        }
    }

    public enum Plane implements Predicate<EnumFacing>, Iterable<EnumFacing> {
        HORIZONTAL,
        VERTICAL;

        public EnumFacing[] facings() {
            switch (this) {
                case HORIZONTAL:
                    return new EnumFacing[]{NORTH, EAST, SOUTH, WEST};
                case VERTICAL:
                    return new EnumFacing[]{UP, DOWN};
                default:
                    throw new Error("Someone's been tampering with the universe!");
            }
        }

        public EnumFacing random(Random rand) {
            EnumFacing[] facings = this.facings();
            return facings[rand.nextInt(facings.length)];
        }

        @Override
        public boolean test(EnumFacing facing) {
            return facing != null && facing.getAxis().getPlane() == this;
        }

        @Override
        public Iterator<EnumFacing> iterator() {
            final EnumFacing[] facings = this.facings();
            return new Iterator<EnumFacing>() {
                private int index;

                @Override
                public boolean hasNext() {
                    return this.index < facings.length;
                }

                @Override
                public EnumFacing next() {
                    if (!hasNext()) {
                        throw new NoSuchElementException();
                    }
                    return facings[this.index++];
                }
            };
        }
    }
}
