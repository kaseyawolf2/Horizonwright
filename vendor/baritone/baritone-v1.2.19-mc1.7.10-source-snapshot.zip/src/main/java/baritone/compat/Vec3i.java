/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.compat;

/**
 * Backport of 1.8+ {@code net.minecraft.util.math.Vec3i} for 1.7.10.
 */
public class Vec3i implements Comparable<Vec3i> {

    public static final Vec3i NULL_VECTOR = new Vec3i(0, 0, 0);

    private final int x;
    private final int y;
    private final int z;

    public Vec3i(int x, int y, int z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public Vec3i(double x, double y, double z) {
        this(MathHelper.floor(x), MathHelper.floor(y), MathHelper.floor(z));
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public int getZ() {
        return this.z;
    }

    public Vec3i crossProduct(Vec3i vec) {
        return new Vec3i(
                this.getY() * vec.getZ() - this.getZ() * vec.getY(),
                this.getZ() * vec.getX() - this.getX() * vec.getZ(),
                this.getX() * vec.getY() - this.getY() * vec.getX()
        );
    }

    public double getDistance(int xIn, int yIn, int zIn) {
        double dx = this.getX() - xIn;
        double dy = this.getY() - yIn;
        double dz = this.getZ() - zIn;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    public double distanceSq(double toX, double toY, double toZ) {
        double dx = this.getX() - toX;
        double dy = this.getY() - toY;
        double dz = this.getZ() - toZ;
        return dx * dx + dy * dy + dz * dz;
    }

    public double distanceSqToCenter(double xIn, double yIn, double zIn) {
        double dx = this.getX() + 0.5D - xIn;
        double dy = this.getY() + 0.5D - yIn;
        double dz = this.getZ() + 0.5D - zIn;
        return dx * dx + dy * dy + dz * dz;
    }

    public double distanceSq(Vec3i to) {
        return this.distanceSq(to.getX(), to.getY(), to.getZ());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Vec3i)) {
            return false;
        }
        Vec3i vec = (Vec3i) o;
        return this.getX() == vec.getX() && this.getY() == vec.getY() && this.getZ() == vec.getZ();
    }

    @Override
    public int hashCode() {
        return (this.getY() + this.getZ() * 31) * 31 + this.getX();
    }

    @Override
    public int compareTo(Vec3i o) {
        if (this.getY() == o.getY()) {
            return this.getZ() == o.getZ() ? this.getX() - o.getX() : this.getZ() - o.getZ();
        }
        return this.getY() - o.getY();
    }

    @Override
    public String toString() {
        return "(" + this.getX() + ", " + this.getY() + ", " + this.getZ() + ")";
    }
}
