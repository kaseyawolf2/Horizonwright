/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.compat;

import net.minecraft.item.Item;

/**
 * 1.12.2-style {@code net.minecraft.init.Items} constant names mapped to the 1.7.10 registry
 * fields. Items added after 1.7.10 are {@code null}.
 */
public final class Items {

    private Items() {}

    public static final Item BUCKET = net.minecraft.init.Items.bucket;
    public static final Item CARROT = net.minecraft.init.Items.carrot;
    public static final Item MELON = net.minecraft.init.Items.melon;
    public static final Item MELON_SEEDS = net.minecraft.init.Items.melon_seeds;
    public static final Item NETHER_WART = net.minecraft.init.Items.nether_wart;
    public static final Item POTATO = net.minecraft.init.Items.potato;
    public static final Item PUMPKIN_SEEDS = net.minecraft.init.Items.pumpkin_seeds;
    public static final Item REEDS = net.minecraft.init.Items.reeds;
    public static final Item WATER_BUCKET = net.minecraft.init.Items.water_bucket;
    public static final Item WHEAT = net.minecraft.init.Items.wheat;
    public static final Item WHEAT_SEEDS = net.minecraft.init.Items.wheat_seeds;
    public static final Item FIREWORKS = net.minecraft.init.Items.fireworks;

    // Items added after 1.7.10 — always null here.
    public static final Item BEETROOT = null;
    public static final Item BEETROOT_SEEDS = null;
    public static final Item ELYTRA = null;
}
