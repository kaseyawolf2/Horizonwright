/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.compat;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Backport of 1.8+ {@code net.minecraft.block.state.IBlockState} for 1.7.10, modeled as an
 * interned (block, metadata) pair. Instances are canonical: two states with the same block and
 * metadata are always the same object, so {@code ==} comparisons behave like 1.8+ state identity
 * for simple blocks.
 */
public final class IBlockState {

    // of() is on the hottest paths in the mod (every pathfinding node expansion, every block of
    // every chunk scan) and is called concurrently from the pathing, main and packer threads —
    // reads must not take a lock. Interning identity is preserved by double-checked writes; the
    // racy unsynchronized array read is safe because IBlockState's fields are final.
    private static final ConcurrentMap<Block, IBlockState[]> CACHE = new ConcurrentHashMap<>();
    // GTNH stores 16-bit metadata (ChunkAPI): GregTech ores encode material/stone/small in
    // values up to ~26000, so metadata must NOT be masked to 4 bits. Values above 15 are rare
    // enough that a per-block map alongside the vanilla 16-slot array is fine.
    private static final ConcurrentMap<Block, ConcurrentMap<Integer, IBlockState>> EXTENDED_CACHE = new ConcurrentHashMap<>();

    private final Block block;
    private final int meta;

    private IBlockState(Block block, int meta) {
        this.block = block;
        this.meta = meta;
    }

    /**
     * @return the canonical state for the given block with metadata 0 (the 1.8+ "default state")
     */
    public static IBlockState of(Block block) {
        return of(block, 0);
    }

    public static IBlockState of(Block block, int meta) {
        if (block == null) {
            block = Blocks.air;
        }
        if (meta < 0) {
            meta = 0;
        }
        if (meta < 16) {
            IBlockState[] states = CACHE.get(block);
            if (states == null) {
                IBlockState[] fresh = new IBlockState[16];
                IBlockState[] raced = CACHE.putIfAbsent(block, fresh);
                states = raced != null ? raced : fresh;
            }
            IBlockState state = states[meta];
            if (state == null) {
                synchronized (states) {
                    state = states[meta];
                    if (state == null) {
                        state = new IBlockState(block, meta);
                        states[meta] = state;
                    }
                }
            }
            return state;
        }
        ConcurrentMap<Integer, IBlockState> extended = EXTENDED_CACHE.get(block);
        if (extended == null) {
            ConcurrentMap<Integer, IBlockState> fresh = new ConcurrentHashMap<>();
            ConcurrentMap<Integer, IBlockState> raced = EXTENDED_CACHE.putIfAbsent(block, fresh);
            extended = raced != null ? raced : fresh;
        }
        IBlockState state = extended.get(meta);
        if (state == null) {
            IBlockState fresh = new IBlockState(block, meta);
            IBlockState raced = extended.putIfAbsent(meta, fresh);
            state = raced != null ? raced : fresh;
        }
        return state;
    }

    public Block getBlock() {
        return this.block;
    }

    public int getMeta() {
        return this.meta;
    }

    public IBlockState withMeta(int newMeta) {
        return of(this.block, newMeta);
    }

    public Material getMaterial() {
        return this.block.getMaterial();
    }

    public boolean isFullCube() {
        return this.block.renderAsNormalBlock() && this.block.isOpaqueCube();
    }

    public boolean isFullBlock() {
        return this.block.isOpaqueCube();
    }

    public boolean isOpaqueCube() {
        return this.block.isOpaqueCube();
    }

    public boolean isBlockNormalCube() {
        return this.block.isBlockNormalCube();
    }

    public boolean isNormalCube() {
        return this.block.isNormalCube();
    }

    public boolean isReplaceable(IBlockAccess world, BlockPos pos) {
        return this.block.isReplaceable(world, pos.getX(), pos.getY(), pos.getZ());
    }

    public boolean isPassable(IBlockAccess world, BlockPos pos) {
        return this.block.getBlocksMovement(world, pos.getX(), pos.getY(), pos.getZ());
    }

    public float getBlockHardness(World world, BlockPos pos) {
        return this.block.getBlockHardness(world, pos.getX(), pos.getY(), pos.getZ());
    }

    /**
     * 1.12's {@code state.getPlayerRelativeBlockHardness(player, world, pos)}
     */
    public float getPlayerRelativeBlockHardness(net.minecraft.entity.player.EntityPlayer player, World world, BlockPos pos) {
        return this.block.getPlayerRelativeBlockHardness(player, world, pos.getX(), pos.getY(), pos.getZ());
    }

    public net.minecraft.util.AxisAlignedBB getCollisionBoundingBox(World world, BlockPos pos) {
        return this.block.getCollisionBoundingBoxFromPool(world, pos.getX(), pos.getY(), pos.getZ());
    }

    public net.minecraft.util.AxisAlignedBB getSelectedBoundingBox(World world, BlockPos pos) {
        return this.block.getSelectedBoundingBoxFromPool(world, pos.getX(), pos.getY(), pos.getZ());
    }

    public boolean isSideSolid(IBlockAccess world, BlockPos pos, EnumFacing side) {
        return this.block.isSideSolid(world, pos.getX(), pos.getY(), pos.getZ(), side.toForge());
    }

    @Override
    public String toString() {
        return this.block + "[meta=" + this.meta + "]";
    }
}
