/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.compat;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.Vec3;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;

/**
 * Static bridges for 1.8+ instance methods that do not exist on 1.7.10 classes.
 */
public final class Compat {

    private Compat() {}

    // === World access ===

    public static IBlockState getBlockState(IBlockAccess world, BlockPos pos) {
        if (pos.getY() < 0 || pos.getY() >= 256) {
            return IBlockState.of(net.minecraft.init.Blocks.air, 0);
        }
        return IBlockState.of(
                world.getBlock(pos.getX(), pos.getY(), pos.getZ()),
                world.getBlockMetadata(pos.getX(), pos.getY(), pos.getZ())
        );
    }

    public static IBlockState getBlockState(Chunk chunk, int x, int y, int z) {
        // chunk-local coordinates for the getters
        int lx = x & 15;
        int lz = z & 15;
        return IBlockState.of(chunk.getBlock(lx, y, lz), chunk.getBlockMetadata(lx, y, lz));
    }

    public static boolean isAirBlock(World world, BlockPos pos) {
        return world.isAirBlock(pos.getX(), pos.getY(), pos.getZ());
    }

    public static boolean setBlockState(World world, BlockPos pos, IBlockState state) {
        return world.setBlock(pos.getX(), pos.getY(), pos.getZ(), state.getBlock(), state.getMeta(), 3);
    }

    // === Geometry ===

    public static AxisAlignedBB aabb(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
        return AxisAlignedBB.getBoundingBox(minX, minY, minZ, maxX, maxY, maxZ);
    }

    public static AxisAlignedBB aabb(BlockPos pos) {
        return AxisAlignedBB.getBoundingBox(pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1, pos.getY() + 1, pos.getZ() + 1);
    }

    public static Vec3 toVec3(Vec3d vec) {
        return Vec3.createVectorHelper(vec.x, vec.y, vec.z);
    }

    // === Entity ===

    /**
     * Feet Y of any entity. On 1.7.10, players have a yOffset of 1.62, so their {@code posY} is at
     * eye level rather than the 1.8+ feet level Baritone assumes; {@code boundingBox.minY} is the
     * feet for every entity type.
     */
    public static double feetY(Entity entity) {
        return entity.boundingBox.minY;
    }

    /**
     * 1.12's {@code entity.getPositionVector()} — feet-level position for all entities.
     */
    public static Vec3d getPositionVector(Entity entity) {
        return new Vec3d(entity.posX, entity.boundingBox.minY, entity.posZ);
    }

    public static Vec3d getPositionEyes(Entity entity, float partialTicks) {
        // For players, posY is already eye-ish level on 1.7.10 (this matches the origin vanilla
        // uses for the mouseover ray trace); for everything else it's feet + eye height.
        double eyeOffset = entity instanceof EntityPlayer ? 0.0D : entity.getEyeHeight();
        if (partialTicks == 1.0F) {
            return new Vec3d(entity.posX, entity.posY + eyeOffset, entity.posZ);
        }
        double x = entity.prevPosX + (entity.posX - entity.prevPosX) * partialTicks;
        double y = entity.prevPosY + (entity.posY - entity.prevPosY) * partialTicks + eyeOffset;
        double z = entity.prevPosZ + (entity.posZ - entity.prevPosZ) * partialTicks;
        return new Vec3d(x, y, z);
    }

    public static Vec3d getLook(Entity entity, float partialTicks) {
        if (entity instanceof net.minecraft.entity.EntityLivingBase) {
            return new Vec3d(((net.minecraft.entity.EntityLivingBase) entity).getLook(partialTicks));
        }
        // Entity#getLook doesn't exist in 1.7.10; replicate its math for non-living entities
        float pitch = entity.prevRotationPitch + (entity.rotationPitch - entity.prevRotationPitch) * partialTicks;
        float yaw = entity.prevRotationYaw + (entity.rotationYaw - entity.prevRotationYaw) * partialTicks;
        float cosYaw = MathHelper.cos(-yaw * 0.017453292F - (float) Math.PI);
        float sinYaw = MathHelper.sin(-yaw * 0.017453292F - (float) Math.PI);
        float cosPitch = -MathHelper.cos(-pitch * 0.017453292F);
        float sinPitch = MathHelper.sin(-pitch * 0.017453292F);
        return new Vec3d(sinYaw * cosPitch, sinPitch, cosYaw * cosPitch);
    }

    public static BlockPos entityPos(Entity entity) {
        return new BlockPos(entity.posX, entity.boundingBox.minY, entity.posZ);
    }

    // === Chat ===

    public static void sendMessage(EntityPlayer player, IChatComponent component) {
        player.addChatMessage(component);
    }
}
