/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.compat;

import net.minecraft.block.Block;

/**
 * 1.12.2-style {@code net.minecraft.init.Blocks} constant names mapped to the 1.7.10 registry
 * fields, so ported code only needs its import rewritten.
 * <p>
 * Blocks that do not exist in 1.7.10 (added in 1.8+) are {@code null}; reference-equality
 * checks against them are always false, which is the desired behavior.
 */
public final class Blocks {

    private Blocks() {}

    public static final Block AIR = net.minecraft.init.Blocks.air;
    public static final Block ANVIL = net.minecraft.init.Blocks.anvil;
    public static final Block BEACON = net.minecraft.init.Blocks.beacon;
    public static final Block BED = net.minecraft.init.Blocks.bed;
    public static final Block BEDROCK = net.minecraft.init.Blocks.bedrock;
    public static final Block BREWING_STAND = net.minecraft.init.Blocks.brewing_stand;
    public static final Block CACTUS = net.minecraft.init.Blocks.cactus;
    public static final Block CARPET = net.minecraft.init.Blocks.carpet;
    public static final Block CARROTS = net.minecraft.init.Blocks.carrots;
    public static final Block CHEST = net.minecraft.init.Blocks.chest;
    public static final Block COAL_BLOCK = net.minecraft.init.Blocks.coal_block;
    public static final Block COAL_ORE = net.minecraft.init.Blocks.coal_ore;
    public static final Block COBBLESTONE = net.minecraft.init.Blocks.cobblestone;
    public static final Block COCOA = net.minecraft.init.Blocks.cocoa;
    public static final Block CRAFTING_TABLE = net.minecraft.init.Blocks.crafting_table;
    public static final Block DIAMOND_BLOCK = net.minecraft.init.Blocks.diamond_block;
    public static final Block DIRT = net.minecraft.init.Blocks.dirt;
    public static final Block DRAGON_EGG = net.minecraft.init.Blocks.dragon_egg;
    public static final Block EMERALD_BLOCK = net.minecraft.init.Blocks.emerald_block;
    public static final Block EMERALD_ORE = net.minecraft.init.Blocks.emerald_ore;
    public static final Block ENCHANTING_TABLE = net.minecraft.init.Blocks.enchanting_table;
    public static final Block END_PORTAL = net.minecraft.init.Blocks.end_portal;
    public static final Block END_PORTAL_FRAME = net.minecraft.init.Blocks.end_portal_frame;
    public static final Block END_STONE = net.minecraft.init.Blocks.end_stone;
    public static final Block ENDER_CHEST = net.minecraft.init.Blocks.ender_chest;
    public static final Block FARMLAND = net.minecraft.init.Blocks.farmland;
    public static final Block FIRE = net.minecraft.init.Blocks.fire;
    public static final Block FLOWING_LAVA = net.minecraft.init.Blocks.flowing_lava;
    public static final Block FLOWING_WATER = net.minecraft.init.Blocks.flowing_water;
    public static final Block FURNACE = net.minecraft.init.Blocks.furnace;
    public static final Block GLASS = net.minecraft.init.Blocks.glass;
    public static final Block GOLD_BLOCK = net.minecraft.init.Blocks.gold_block;
    public static final Block GOLD_ORE = net.minecraft.init.Blocks.gold_ore;
    public static final Block GRAVEL = net.minecraft.init.Blocks.gravel;
    public static final Block HOPPER = net.minecraft.init.Blocks.hopper;
    public static final Block ICE = net.minecraft.init.Blocks.ice;
    public static final Block IRON_BLOCK = net.minecraft.init.Blocks.iron_block;
    public static final Block IRON_DOOR = net.minecraft.init.Blocks.iron_door;
    public static final Block IRON_ORE = net.minecraft.init.Blocks.iron_ore;
    public static final Block JUKEBOX = net.minecraft.init.Blocks.jukebox;
    public static final Block LADDER = net.minecraft.init.Blocks.ladder;
    public static final Block LAVA = net.minecraft.init.Blocks.lava;
    public static final Block LIT_FURNACE = net.minecraft.init.Blocks.lit_furnace;
    public static final Block LOG = net.minecraft.init.Blocks.log;
    public static final Block LOG2 = net.minecraft.init.Blocks.log2;
    public static final Block MELON_BLOCK = net.minecraft.init.Blocks.melon_block;
    public static final Block MOB_SPAWNER = net.minecraft.init.Blocks.mob_spawner;
    public static final Block NETHER_BRICK = net.minecraft.init.Blocks.nether_brick;
    public static final Block NETHER_WART = net.minecraft.init.Blocks.nether_wart;
    public static final Block NETHERRACK = net.minecraft.init.Blocks.netherrack;
    public static final Block OBSIDIAN = net.minecraft.init.Blocks.obsidian;
    public static final Block PORTAL = net.minecraft.init.Blocks.portal;
    public static final Block POTATOES = net.minecraft.init.Blocks.potatoes;
    public static final Block PUMPKIN = net.minecraft.init.Blocks.pumpkin;
    public static final Block REEDS = net.minecraft.init.Blocks.reeds;
    public static final Block SKULL = net.minecraft.init.Blocks.skull;
    public static final Block SOUL_SAND = net.minecraft.init.Blocks.soul_sand;
    public static final Block STAINED_GLASS = net.minecraft.init.Blocks.stained_glass;
    public static final Block STANDING_SIGN = net.minecraft.init.Blocks.standing_sign;
    public static final Block STONE = net.minecraft.init.Blocks.stone;
    public static final Block TRAPPED_CHEST = net.minecraft.init.Blocks.trapped_chest;
    public static final Block TRIPWIRE = net.minecraft.init.Blocks.tripwire;
    public static final Block VINE = net.minecraft.init.Blocks.vine;
    public static final Block WALL_SIGN = net.minecraft.init.Blocks.wall_sign;
    public static final Block WATER = net.minecraft.init.Blocks.water;
    public static final Block WATERLILY = net.minecraft.init.Blocks.waterlily;
    public static final Block WEB = net.minecraft.init.Blocks.web;
    public static final Block WHEAT = net.minecraft.init.Blocks.wheat;

    // Blocks added after 1.7.10 — always null here. == checks against these are simply false.
    public static final Block BARRIER = null;
    public static final Block BEETROOTS = null;
    public static final Block END_GATEWAY = null;
    public static final Block END_ROD = null;
    public static final Block GRASS_PATH = null;
    public static final Block MAGMA = null;
    public static final Block OBSERVER = null;
    public static final Block WHITE_SHULKER_BOX = null;
    public static final Block ORANGE_SHULKER_BOX = null;
    public static final Block MAGENTA_SHULKER_BOX = null;
    public static final Block LIGHT_BLUE_SHULKER_BOX = null;
    public static final Block YELLOW_SHULKER_BOX = null;
    public static final Block LIME_SHULKER_BOX = null;
    public static final Block PINK_SHULKER_BOX = null;
    public static final Block GRAY_SHULKER_BOX = null;
    public static final Block SILVER_SHULKER_BOX = null;
    public static final Block CYAN_SHULKER_BOX = null;
    public static final Block PURPLE_SHULKER_BOX = null;
    public static final Block BLUE_SHULKER_BOX = null;
    public static final Block BROWN_SHULKER_BOX = null;
    public static final Block GREEN_SHULKER_BOX = null;
    public static final Block RED_SHULKER_BOX = null;
    public static final Block BLACK_SHULKER_BOX = null;
}
