/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.compat;

import net.minecraft.entity.Entity;
import net.minecraft.util.MovingObjectPosition;

/**
 * Backport of 1.9+ {@code net.minecraft.util.math.RayTraceResult} for 1.7.10, wrapping
 * {@link MovingObjectPosition}.
 */
public class RayTraceResult {

    public enum Type {
        MISS,
        BLOCK,
        ENTITY
    }

    public final Type typeOfHit;
    public final Vec3d hitVec;
    public final EnumFacing sideHit;
    public final Entity entityHit;
    private final BlockPos blockPos;

    public RayTraceResult(Type type, Vec3d hitVec, EnumFacing sideHit, BlockPos blockPos, Entity entityHit) {
        this.typeOfHit = type;
        this.hitVec = hitVec;
        this.sideHit = sideHit;
        this.blockPos = blockPos;
        this.entityHit = entityHit;
    }

    public RayTraceResult(Vec3d hitVec, EnumFacing sideHit, BlockPos blockPos) {
        this(Type.BLOCK, hitVec, sideHit, blockPos, null);
    }

    public RayTraceResult(Entity entity, Vec3d hitVec) {
        this(Type.ENTITY, hitVec, null, null, entity);
    }

    public BlockPos getBlockPos() {
        return this.blockPos;
    }

    /**
     * @param mop the 1.7.10 ray trace result, possibly null
     * @return the compat equivalent, or null
     */
    public static RayTraceResult fromVanilla(MovingObjectPosition mop) {
        if (mop == null) {
            return null;
        }
        Vec3d hit = mop.hitVec == null ? null : new Vec3d(mop.hitVec);
        switch (mop.typeOfHit) {
            case BLOCK:
                return new RayTraceResult(Type.BLOCK, hit, EnumFacing.byIndex(mop.sideHit), new BlockPos(mop.blockX, mop.blockY, mop.blockZ), null);
            case ENTITY:
                return new RayTraceResult(Type.ENTITY, hit, null, null, mop.entityHit);
            default:
                return new RayTraceResult(Type.MISS, hit, null, null, null);
        }
    }
}
