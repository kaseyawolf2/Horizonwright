/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.utils.pathing;

import net.minecraft.world.World;

/**
 * Essentially, a "rule" for the path finder, prevents proposed movements from attempting to venture
 * into the world border, and prevents actual movements from placing blocks in the world border.
 * <p>
 * 1.7.10 has no world border, so this is a permissive stub that allows everything.
 */
public class BetterWorldBorder {

    public BetterWorldBorder() {
    }

    /**
     * 1.7.10 has no world border; the world parameter is accepted (and ignored) so call sites
     * can simply drop the {@code .getWorldBorder()} call.
     */
    public BetterWorldBorder(World world) {
    }

    public boolean entirelyContains(int x, int z) {
        return true;
    }

    public boolean canPlaceAt(int x, int z) {
        return true;
    }
}
