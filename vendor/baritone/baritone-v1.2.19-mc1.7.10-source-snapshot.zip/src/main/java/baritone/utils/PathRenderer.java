/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.utils;

import baritone.compat.Compat;

import baritone.api.BaritoneAPI;
import baritone.api.event.events.RenderEvent;
import baritone.api.pathing.goals.*;
import baritone.api.utils.BetterBlockPos;
import baritone.api.utils.IPlayerContext;
import baritone.api.utils.interfaces.IGoalRenderPos;
import baritone.behavior.PathingBehavior;
import baritone.pathing.path.PathExecutor;
import baritone.compat.IBlockState;
import baritone.compat.GlStateManager;
import net.minecraft.entity.Entity;
import baritone.compat.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ResourceLocation;
import baritone.compat.BlockPos;
import baritone.compat.MathHelper;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * @author Brady
 * @since 8/9/2018
 */
public final class PathRenderer implements IRenderer {

    private static final ResourceLocation TEXTURE_BEACON_BEAM = new ResourceLocation("textures/entity/beacon_beam.png");

    private PathRenderer() {}

    public static void render(RenderEvent event, PathingBehavior behavior) {
        final IPlayerContext ctx = behavior.ctx;
        if (ctx.world() == null) {
            return;
        }
        if (ctx.minecraft().currentScreen instanceof GuiClick) {
            ((GuiClick) ctx.minecraft().currentScreen).onRender();
        }

        final float partialTicks = event.getPartialTicks();
        final Goal goal = behavior.getGoal();

        final int thisPlayerDimension = ctx.world().provider.dimensionId;
        final int currentRenderViewDimension = BaritoneAPI.getProvider().getPrimaryBaritone().getPlayerContext().world().provider.dimensionId;

        if (thisPlayerDimension != currentRenderViewDimension) {
            // this is a path for a bot in a different dimension, don't render it
            return;
        }

        if (goal != null && settings.renderGoal.value) {
            drawGoal(ctx.player(), goal, partialTicks, settings.colorGoalBox.value);
        }

        if (!settings.renderPath.value) {
            return;
        }

        PathExecutor current = behavior.getCurrent(); // this should prevent most race conditions?
        PathExecutor next = behavior.getNext(); // like, now it's not possible for current!=null to be true, then suddenly false because of another thread
        if (current != null && settings.renderSelectionBoxes.value) {
            drawManySelectionBoxes(ctx.player(), current.toBreak(), settings.colorBlocksToBreak.value);
            drawManySelectionBoxes(ctx.player(), current.toPlace(), settings.colorBlocksToPlace.value);
            drawManySelectionBoxes(ctx.player(), current.toWalkInto(), settings.colorBlocksToWalkInto.value);
        }

        //drawManySelectionBoxes(player, Collections.singletonList(behavior.pathStart()), partialTicks, Color.WHITE);

        // Render the current path, if there is one
        if (current != null && current.getPath() != null) {
            int renderBegin = Math.max(current.getPosition() - 3, 0);
            drawPath(current.getPath().positions(), renderBegin, settings.colorCurrentPath.value, settings.fadePath.value, 10, 20);
        }

        if (next != null && next.getPath() != null) {
            drawPath(next.getPath().positions(), 0, settings.colorNextPath.value, settings.fadePath.value, 10, 20);
        }

        // If there is a path calculation currently running, render the path calculation process
        behavior.getInProgress().ifPresent(currentlyRunning -> {
            currentlyRunning.bestPathSoFar().ifPresent(p -> {
                drawPath(p.positions(), 0, settings.colorBestPathSoFar.value, settings.fadePath.value, 10, 20);
            });

            currentlyRunning.pathToMostRecentNodeConsidered().ifPresent(mr -> {
                drawPath(mr.positions(), 0, settings.colorMostRecentConsidered.value, settings.fadePath.value, 10, 20);
                drawManySelectionBoxes(ctx.player(), Collections.singletonList(mr.getDest()), settings.colorMostRecentConsidered.value);
            });
        });
    }

    public static void drawPath(List<BetterBlockPos> positions, int startIndex, Color color, boolean fadeOut, int fadeStart0, int fadeEnd0) {
        drawPath(positions, startIndex, color, fadeOut, fadeStart0, fadeEnd0, 0.5D);
    }

    public static void drawPath(List<BetterBlockPos> positions, int startIndex, Color color, boolean fadeOut, int fadeStart0, int fadeEnd0, double offset) {
        IRenderer.startLines(color, settings.pathRenderLineWidthPixels.value, settings.renderPathIgnoreDepth.value);

        int fadeStart = fadeStart0 + startIndex;
        int fadeEnd = fadeEnd0 + startIndex;

        for (int i = startIndex, next; i < positions.size() - 1; i = next) {
            BetterBlockPos start = positions.get(i);
            BetterBlockPos end = positions.get(next = i + 1);

            int dirX = end.x - start.x;
            int dirY = end.y - start.y;
            int dirZ = end.z - start.z;

            while (next + 1 < positions.size() && (!fadeOut || next + 1 < fadeStart) &&
                    (dirX == positions.get(next + 1).x - end.x &&
                            dirY == positions.get(next + 1).y - end.y &&
                            dirZ == positions.get(next + 1).z - end.z)) {
                end = positions.get(++next);
            }

            if (fadeOut) {
                float alpha;

                if (i <= fadeStart) {
                    alpha = 0.4F;
                } else {
                    if (i > fadeEnd) {
                        break;
                    }
                    alpha = 0.4F * (1.0F - (float) (i - fadeStart) / (float) (fadeEnd - fadeStart));
                }

                IRenderer.glColor(color, alpha);
            }

            emitPathLine(start.x, start.y, start.z, end.x, end.y, end.z, offset);
        }

        IRenderer.endLines(settings.renderPathIgnoreDepth.value);
    }

    private static void emitPathLine(double x1, double y1, double z1, double x2, double y2, double z2, double offset) {
        final double extraOffset = offset + 0.03D;
        double vpX = renderManager.viewerPosX;
        double vpY = renderManager.viewerPosY;
        double vpZ = renderManager.viewerPosZ;
        boolean renderPathAsFrickinThingy = !settings.renderPathAsLine.value;

        IRenderer.vertex(x1 + offset - vpX, y1 + offset - vpY, z1 + offset - vpZ);
        IRenderer.vertex(x2 + offset - vpX, y2 + offset - vpY, z2 + offset - vpZ);

        if (renderPathAsFrickinThingy) {
            IRenderer.vertex(x2 + offset - vpX, y2 + offset - vpY, z2 + offset - vpZ);
            IRenderer.vertex(x2 + offset - vpX, y2 + extraOffset - vpY, z2 + offset - vpZ);

            IRenderer.vertex(x2 + offset - vpX, y2 + extraOffset - vpY, z2 + offset - vpZ);
            IRenderer.vertex(x1 + offset - vpX, y1 + extraOffset - vpY, z1 + offset - vpZ);

            IRenderer.vertex(x1 + offset - vpX, y1 + extraOffset - vpY, z1 + offset - vpZ);
            IRenderer.vertex(x1 + offset - vpX, y1 + offset - vpY, z1 + offset - vpZ);
        }
    }

    public static void drawManySelectionBoxes(Entity player, Collection<BlockPos> positions, Color color) {
        IRenderer.startLines(color, settings.pathRenderLineWidthPixels.value, settings.renderSelectionBoxesIgnoreDepth.value);

        //BlockPos blockpos = movingObjectPositionIn.getBlockPos();
        BlockStateInterface bsi = new BlockStateInterface(BaritoneAPI.getProvider().getPrimaryBaritone().getPlayerContext()); // TODO this assumes same dimension between primary baritone and render view? is this safe?

        positions.forEach(pos -> {
            IBlockState state = bsi.get0(pos);
            AxisAlignedBB toDraw;

            if (state.getBlock().equals(Blocks.AIR)) {
                toDraw = IBlockState.of(Blocks.DIRT).getSelectedBoundingBox(player.worldObj, pos);
            } else {
                toDraw = state.getSelectedBoundingBox(player.worldObj, pos);
            }

            IRenderer.emitAABB(toDraw, .002D);
        });

        IRenderer.endLines(settings.renderSelectionBoxesIgnoreDepth.value);
    }

    public static void drawGoal(Entity player, Goal goal, float partialTicks, Color color) {
        drawGoal(player, goal, partialTicks, color, true);
    }

    private static void drawGoal(Entity player, Goal goal, float partialTicks, Color color, boolean setupRender) {
        double renderPosX = renderManager.viewerPosX;
        double renderPosY = renderManager.viewerPosY;
        double renderPosZ = renderManager.viewerPosZ;
        double minX, maxX;
        double minZ, maxZ;
        double minY, maxY;
        double y, y1, y2;
        if (!settings.renderGoalAnimated.value) {
            // y = 1 causes rendering issues when the player is at the same y as the top of a block for some reason
            y = 0.999F;
        } else {
            y = MathHelper.cos((float) (((float) ((System.nanoTime() / 100000L) % 20000L)) / 20000F * Math.PI * 2));
        }
        if (goal instanceof IGoalRenderPos) {
            BlockPos goalPos = ((IGoalRenderPos) goal).getGoalPos();
            minX = goalPos.getX() + 0.002 - renderPosX;
            maxX = goalPos.getX() + 1 - 0.002 - renderPosX;
            minZ = goalPos.getZ() + 0.002 - renderPosZ;
            maxZ = goalPos.getZ() + 1 - 0.002 - renderPosZ;
            if (goal instanceof GoalGetToBlock || goal instanceof GoalTwoBlocks) {
                y /= 2;
            }
            y1 = 1 + y + goalPos.getY() - renderPosY;
            y2 = 1 - y + goalPos.getY() - renderPosY;
            minY = goalPos.getY() - renderPosY;
            maxY = minY + 2;
            if (goal instanceof GoalGetToBlock || goal instanceof GoalTwoBlocks) {
                y1 -= 0.5;
                y2 -= 0.5;
                maxY--;
            }
            drawDankLitGoalBox(color, minX, maxX, minZ, maxZ, minY, maxY, y1, y2, setupRender);
        } else if (goal instanceof GoalXZ) {
            GoalXZ goalPos = (GoalXZ) goal;

            if (settings.renderGoalXZBeacon.value) {
                textureManager.bindTexture(TEXTURE_BEACON_BEAM);

                if (settings.renderGoalIgnoreDepth.value) {
                    GlStateManager.disableDepth();
                }

                renderBeaconBeam(
                        goalPos.getX() - renderPosX,
                        -renderPosY,
                        goalPos.getZ() - renderPosZ,
                        settings.renderGoalAnimated.value ? partialTicks : 0,
                        settings.renderGoalAnimated.value ? player.worldObj.getTotalWorldTime() : 0,
                        color.getColorComponents(null)
                );

                if (settings.renderGoalIgnoreDepth.value) {
                    GlStateManager.enableDepth();
                }
                return;
            }

            minX = goalPos.getX() + 0.002 - renderPosX;
            maxX = goalPos.getX() + 1 - 0.002 - renderPosX;
            minZ = goalPos.getZ() + 0.002 - renderPosZ;
            maxZ = goalPos.getZ() + 1 - 0.002 - renderPosZ;

            y1 = 0;
            y2 = 0;
            minY = 0 - renderPosY;
            maxY = 256 - renderPosY;
            drawDankLitGoalBox(color, minX, maxX, minZ, maxZ, minY, maxY, y1, y2, setupRender);
        } else if (goal instanceof GoalComposite) {
            // Simple way to determine if goals can be batched, without having some sort of GoalRenderer
            boolean batch = Arrays.stream(((GoalComposite) goal).goals()).allMatch(IGoalRenderPos.class::isInstance);

            if (batch) {
                IRenderer.startLines(color, settings.goalRenderLineWidthPixels.value, settings.renderGoalIgnoreDepth.value);
            }
            for (Goal g : ((GoalComposite) goal).goals()) {
                drawGoal(player, g, partialTicks, color, !batch);
            }
            if (batch) {
                IRenderer.endLines(settings.renderGoalIgnoreDepth.value);
            }
        } else if (goal instanceof GoalInverted) {
            drawGoal(player, ((GoalInverted) goal).origin, partialTicks, settings.colorInvertedGoalBox.value);
        } else if (goal instanceof GoalYLevel) {
            GoalYLevel goalpos = (GoalYLevel) goal;
            minX = player.posX - settings.yLevelBoxSize.value - renderPosX;
            minZ = player.posZ - settings.yLevelBoxSize.value - renderPosZ;
            maxX = player.posX + settings.yLevelBoxSize.value - renderPosX;
            maxZ = player.posZ + settings.yLevelBoxSize.value - renderPosZ;
            minY = ((GoalYLevel) goal).level - renderPosY;
            maxY = minY + 2;
            y1 = 1 + y + goalpos.level - renderPosY;
            y2 = 1 - y + goalpos.level - renderPosY;
            drawDankLitGoalBox(color, minX, maxX, minZ, maxZ, minY, maxY, y1, y2, setupRender);
        }
    }

    private static void drawDankLitGoalBox(Color colorIn, double minX, double maxX, double minZ, double maxZ, double minY, double maxY, double y1, double y2, boolean setupRender) {
        if (setupRender) {
            IRenderer.startLines(colorIn, settings.goalRenderLineWidthPixels.value, settings.renderGoalIgnoreDepth.value);
        }

        renderHorizontalQuad(minX, maxX, minZ, maxZ, y1);
        renderHorizontalQuad(minX, maxX, minZ, maxZ, y2);

        IRenderer.vertex(minX, minY, minZ);
        IRenderer.vertex(minX, maxY, minZ);
        IRenderer.vertex(maxX, minY, minZ);
        IRenderer.vertex(maxX, maxY, minZ);
        IRenderer.vertex(maxX, minY, maxZ);
        IRenderer.vertex(maxX, maxY, maxZ);
        IRenderer.vertex(minX, minY, maxZ);
        IRenderer.vertex(minX, maxY, maxZ);

        if (setupRender) {
            IRenderer.endLines(settings.renderGoalIgnoreDepth.value);
        }
    }

    private static void renderHorizontalQuad(double minX, double maxX, double minZ, double maxZ, double y) {
        if (y != 0) {
            IRenderer.vertex(minX, y, minZ);
            IRenderer.vertex(maxX, y, minZ);

            IRenderer.vertex(maxX, y, minZ);
            IRenderer.vertex(maxX, y, maxZ);

            IRenderer.vertex(maxX, y, maxZ);
            IRenderer.vertex(minX, y, maxZ);

            IRenderer.vertex(minX, y, maxZ);
            IRenderer.vertex(minX, y, minZ);
        }
    }

    /**
     * Fixed-function port of the 1.7.10 beacon beam renderer (see {@code TileEntityBeaconRenderer}),
     * with a custom beam color. The beam texture must already be bound.
     */
    private static void renderBeaconBeam(double x, double y, double z, float partialTicks, long totalWorldTime, float[] colors) {
        float f2 = totalWorldTime + partialTicks;
        float f3 = -f2 * 0.2F - MathHelper.floor(-f2 * 0.1F);

        GL11.glTexParameterf(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, 10497.0F);
        GL11.glTexParameterf(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, 10497.0F);
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.disableBlend();
        GlStateManager.depthMask(true);
        GlStateManager.tryBlendFuncSeparate(770, 1, 1, 0);

        // inner, rotating beam
        double d3 = (double) f2 * 0.025D * -1.5D;
        tessellator.startDrawingQuads();
        tessellator.setColorRGBA_F(colors[0], colors[1], colors[2], 1.0F);
        double d5 = 0.2D;
        double d7 = 0.5D + Math.cos(d3 + 2.356194490192345D) * d5;
        double d9 = 0.5D + Math.sin(d3 + 2.356194490192345D) * d5;
        double d11 = 0.5D + Math.cos(d3 + (Math.PI / 4D)) * d5;
        double d13 = 0.5D + Math.sin(d3 + (Math.PI / 4D)) * d5;
        double d15 = 0.5D + Math.cos(d3 + 3.9269908169872414D) * d5;
        double d17 = 0.5D + Math.sin(d3 + 3.9269908169872414D) * d5;
        double d19 = 0.5D + Math.cos(d3 + 5.497787143782138D) * d5;
        double d21 = 0.5D + Math.sin(d3 + 5.497787143782138D) * d5;
        double d23 = 256.0D;
        double d25 = 0.0D;
        double d27 = 1.0D;
        double d28 = (double) (-1.0F + f3);
        double d29 = 256.0D * (0.5D / d5) + d28;
        tessellator.addVertexWithUV(x + d7, y + d23, z + d9, d27, d29);
        tessellator.addVertexWithUV(x + d7, y, z + d9, d27, d28);
        tessellator.addVertexWithUV(x + d11, y, z + d13, d25, d28);
        tessellator.addVertexWithUV(x + d11, y + d23, z + d13, d25, d29);
        tessellator.addVertexWithUV(x + d19, y + d23, z + d21, d27, d29);
        tessellator.addVertexWithUV(x + d19, y, z + d21, d27, d28);
        tessellator.addVertexWithUV(x + d15, y, z + d17, d25, d28);
        tessellator.addVertexWithUV(x + d15, y + d23, z + d17, d25, d29);
        tessellator.addVertexWithUV(x + d11, y + d23, z + d13, d27, d29);
        tessellator.addVertexWithUV(x + d11, y, z + d13, d27, d28);
        tessellator.addVertexWithUV(x + d19, y, z + d21, d25, d28);
        tessellator.addVertexWithUV(x + d19, y + d23, z + d21, d25, d29);
        tessellator.addVertexWithUV(x + d15, y + d23, z + d17, d27, d29);
        tessellator.addVertexWithUV(x + d15, y, z + d17, d27, d28);
        tessellator.addVertexWithUV(x + d7, y, z + d9, d25, d28);
        tessellator.addVertexWithUV(x + d7, y + d23, z + d9, d25, d29);
        tessellator.draw();

        // outer, translucent shell
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.depthMask(false);
        tessellator.startDrawingQuads();
        tessellator.setColorRGBA_F(colors[0], colors[1], colors[2], 0.125F);
        double d30 = 0.2D;
        double d4 = 0.2D;
        double d6 = 0.8D;
        double d8 = 0.2D;
        double d10 = 0.2D;
        double d12 = 0.8D;
        double d14 = 0.8D;
        double d16 = 0.8D;
        double d18 = 256.0D;
        double d20 = 0.0D;
        double d22 = 1.0D;
        double d24 = (double) (-1.0F + f3);
        double d26 = 256.0D + d24;
        tessellator.addVertexWithUV(x + d30, y + d18, z + d4, d22, d26);
        tessellator.addVertexWithUV(x + d30, y, z + d4, d22, d24);
        tessellator.addVertexWithUV(x + d6, y, z + d8, d20, d24);
        tessellator.addVertexWithUV(x + d6, y + d18, z + d8, d20, d26);
        tessellator.addVertexWithUV(x + d14, y + d18, z + d16, d22, d26);
        tessellator.addVertexWithUV(x + d14, y, z + d16, d22, d24);
        tessellator.addVertexWithUV(x + d10, y, z + d12, d20, d24);
        tessellator.addVertexWithUV(x + d10, y + d18, z + d12, d20, d26);
        tessellator.addVertexWithUV(x + d6, y + d18, z + d8, d22, d26);
        tessellator.addVertexWithUV(x + d6, y, z + d8, d22, d24);
        tessellator.addVertexWithUV(x + d14, y, z + d16, d20, d24);
        tessellator.addVertexWithUV(x + d14, y + d18, z + d16, d20, d26);
        tessellator.addVertexWithUV(x + d10, y + d18, z + d12, d22, d26);
        tessellator.addVertexWithUV(x + d10, y, z + d12, d22, d24);
        tessellator.addVertexWithUV(x + d30, y, z + d4, d20, d24);
        tessellator.addVertexWithUV(x + d30, y + d18, z + d4, d20, d26);
        tessellator.draw();

        GlStateManager.enableLighting();
        GlStateManager.enableCull();
        GlStateManager.enableTexture2D();
        GlStateManager.depthMask(true);
    }
}
