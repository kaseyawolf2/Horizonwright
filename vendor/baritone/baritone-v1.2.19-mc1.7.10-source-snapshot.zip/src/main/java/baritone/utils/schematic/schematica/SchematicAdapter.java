/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.utils.schematic.schematica;

import baritone.compat.Compat;

import baritone.api.schematic.IStaticSchematic;
import baritone.compat.IBlockState;
import com.github.lunatrius.schematica.client.world.SchematicWorld;
import net.minecraft.world.World;

import java.util.List;

public final class SchematicAdapter implements IStaticSchematic {

    private final SchematicWorld schematic;

    public SchematicAdapter(SchematicWorld schematicWorld) {
        this.schematic = schematicWorld;
    }

    @Override
    public IBlockState desiredState(int x, int y, int z, IBlockState current, List<IBlockState> approxPlaceable) {
        return this.getDirect(x, y, z);
    }

    @Override
    public IBlockState getDirect(int x, int y, int z) {
        // go through a World-typed reference so the getBlock/getBlockMetadata call sites
        // reobfuscate to the SRG names that the real SchematicWorld overrides
        World world = this.schematic;
        return IBlockState.of(world.getBlock(x, y, z), world.getBlockMetadata(x, y, z));
    }

    @Override
    public int widthX() {
        return schematic.getWidth();
    }

    @Override
    public int heightY() {
        World world = this.schematic;
        return world.getHeight();
    }

    @Override
    public int lengthZ() {
        return schematic.getLength();
    }
}
