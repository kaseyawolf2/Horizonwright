/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.utils.schematic.schematica;

import baritone.compat.Compat;

import baritone.api.schematic.IStaticSchematic;
import baritone.compat.BlockPos;
import com.github.lunatrius.core.util.vector.Vector3i;
import com.github.lunatrius.schematica.client.world.SchematicWorld;
import com.github.lunatrius.schematica.proxy.ClientProxy;

import java.util.Optional;

public enum SchematicaHelper {
    ;

    /**
     * Holder for an open schematic and its world-space origin. Deliberately free of any
     * Schematica types so it can be loaded even when the mod is absent.
     */
    public static final class OpenSchematic {

        private final IStaticSchematic schematic;
        private final BlockPos origin;

        OpenSchematic(IStaticSchematic schematic, BlockPos origin) {
            this.schematic = schematic;
            this.origin = origin;
        }

        public IStaticSchematic getSchematic() {
            return schematic;
        }

        public BlockPos getOrigin() {
            return origin;
        }
    }

    public static boolean isSchematicaPresent() {
        try {
            Class.forName("com.github.lunatrius.schematica.Schematica");
            return true;
        } catch (ClassNotFoundException | NoClassDefFoundError ex) {
            return false;
        }
    }

    /**
     * Only call after {@link #isSchematicaPresent()} returned true — this method's body
     * references Schematica classes directly.
     */
    public static Optional<OpenSchematic> getOpenSchematic() {
        SchematicWorld world = ClientProxy.schematic;
        if (world == null) {
            return Optional.empty();
        }
        Vector3i pos = world.position;
        return Optional.of(new OpenSchematic(new SchematicAdapter(world), new BlockPos(pos.getX(), pos.getY(), pos.getZ())));
    }
}
