/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.utils;

import baritone.compat.Compat;

import baritone.Baritone;
import baritone.api.utils.Helper;
import baritone.utils.accessor.IItemTool;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import baritone.compat.BlockPos;
import baritone.compat.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraftforge.common.ForgeHooks;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

/**
 * A cached list of the best tools on the hotbar for any block
 *
 * @author Avery, Brady, leijurv
 */
public class ToolSet {

    /**
     * A cache mapping a {@link Block} to how long it will take to break
     * with this toolset, given the optimum tool is used.
     */
    private final Map<Block, Double> breakStrengthCache;

    /**
     * My buddy leijurv owned me so we have this to not create a new lambda instance.
     */
    private final Function<Block, Double> backendCalculation;

    private final EntityPlayerSP player;

    public ToolSet(EntityPlayerSP player) {
        breakStrengthCache = new HashMap<>();
        this.player = player;

        if (Baritone.settings().considerPotionEffects.value) {
            double amplifier = potionAmplifier();
            Function<Double, Double> amplify = x -> amplifier * x;
            backendCalculation = amplify.compose(this::getBestDestructionTime);
        } else {
            backendCalculation = this::getBestDestructionTime;
        }
    }

    /**
     * Using the best tool on the hotbar, how fast we can mine this block
     *
     * @param state the blockstate to be mined
     * @return the speed of how fast we'll mine it. 1/(time in ticks)
     */
    public double getStrVsBlock(IBlockState state) {
        return breakStrengthCache.computeIfAbsent(state.getBlock(), backendCalculation);
    }

    /**
     * Evaluate the material cost of a possible tool. The priority matches the
     * harvest level order; there is a chance for multiple at the same with modded tools
     * but in that case we don't really care.
     *
     * @param itemStack a possibly empty ItemStack
     * @return values from 0 up
     */
    private int getMaterialCost(ItemStack itemStack) {
        if (itemStack != null && itemStack.getItem() instanceof ItemTool) {
            ItemTool tool = (ItemTool) itemStack.getItem();
            return ((IItemTool) tool).getHarvestLevel();
        } else {
            return -1;
        }
    }

    public boolean hasSilkTouch(ItemStack stack) {
        return EnchantmentHelper.getEnchantmentLevel(Enchantment.silkTouch.effectId, stack) > 0;
    }

    /**
     * Calculate which tool on the hotbar is best for mining, depending on an override setting,
     * related to auto tool movement cost, it will either return current selected slot, or the best slot.
     *
     * @param b the blockstate to be mined
     * @return An int containing the index in the tools array that worked best
     */

    public int getBestSlot(Block b, boolean preferSilkTouch) {
        // meta-blind fallback; prefer the IBlockState overload where the real state is known
        return getBestSlot(IBlockState.of(b), preferSilkTouch, false);
    }

    public int getBestSlot(IBlockState blockState, boolean preferSilkTouch) {
        return getBestSlot(blockState, preferSilkTouch, false, null);
    }

    public int getBestSlot(IBlockState blockState, boolean preferSilkTouch, boolean pathingCalculation) {
        return getBestSlot(blockState, preferSilkTouch, pathingCalculation, null);
    }

    public int getBestSlot(IBlockState blockState, boolean preferSilkTouch, boolean pathingCalculation, BlockPos pos) {

        /*
        If we actually want know what efficiency our held item has instead of the best one
        possible, this lets us make pathing depend on the actual tool to be used (if auto tool is disabled)
        */
        if (!Baritone.settings().autoTool.value && pathingCalculation) {
            return player.inventory.currentItem;
        }

        // On the main thread we can rate each slot exactly the way the game itself would break
        // the block: through the player, so PlayerEvent.BreakSpeed and harvest checks fire.
        // Tinkers' Construct (GTNH fork) computes its tools' real speed only via those events,
        // and GregTech ores only reveal harvest data through the player path.
        boolean live = !pathingCalculation && Minecraft.getMinecraft().func_152345_ab(); // isCallingFromMinecraftThread

        // #set chatDebug true → one line per new target block with every slot's score
        boolean debug = live && Baritone.settings().chatDebug.value && blockState != lastDebugState;
        double[] debugScores = debug ? new double[9] : null;

        int best = 0;
        double highestSpeed = Double.NEGATIVE_INFINITY;
        int lowestCost = Integer.MIN_VALUE;
        boolean bestSilkTouch = false;
        for (int i = 0; i < 9; i++) {
            ItemStack itemStack = player.inventory.getStackInSlot(i);
            if (itemStack != null) {
                if (!Baritone.settings().useSwordToMine.value && itemStack.getItem() instanceof ItemSword) {
                    continue;
                }

                if (Baritone.settings().itemSaver.value && (itemStack.getItemDamage() + Baritone.settings().itemSaverThreshold.value) >= itemStack.getMaxDamage() && itemStack.getMaxDamage() > 1) {
                    continue;
                }
            }
            double speed = live ? playerSpeedVsBlock(i, blockState, pos) : calculateSpeedVsBlock(itemStack, blockState);
            if (debugScores != null) {
                debugScores[i] = speed;
            }
            if (speed > 0 && hasRightToolClass(itemStack, blockState)) {
                // break exact ties toward the right kind of tool: e.g. GT small ores are
                // hand-harvestable, so a fist and a pickaxe can score identically otherwise
                speed *= 1.001;
            }
            boolean silkTouch = hasSilkTouch(itemStack);
            if (speed > highestSpeed) {
                highestSpeed = speed;
                best = i;
                lowestCost = getMaterialCost(itemStack);
                bestSilkTouch = silkTouch;
            } else if (speed == highestSpeed) {
                int cost = getMaterialCost(itemStack);
                if ((cost < lowestCost && (silkTouch || !bestSilkTouch)) ||
                        (preferSilkTouch && !bestSilkTouch && silkTouch)) {
                    highestSpeed = speed;
                    best = i;
                    lowestCost = cost;
                    bestSilkTouch = silkTouch;
                }
            }
        }
        if (debug) {
            lastDebugState = blockState;
            StringBuilder sb = new StringBuilder("ToolSet ")
                    .append(blockState.getBlock().getUnlocalizedName())
                    .append(" meta=").append(blockState.getMeta())
                    .append(" scores:");
            for (int i = 0; i < 9; i++) {
                sb.append(String.format(" %d=%.5f", i + 1, debugScores[i]));
            }
            sb.append(" -> slot ").append(best + 1);
            Helper.HELPER.logDebug(sb.toString());
        }
        return best;
    }

    private static IBlockState lastDebugState = null; // interned, identity compare is fine

    /**
     * Calculate how effectively a block can be destroyed
     *
     * @param b the blockstate to be mined
     * @return A double containing the destruction ticks with the best tool
     */
    private double getBestDestructionTime(Block b) {
        ItemStack stack = player.inventory.getStackInSlot(getBestSlot(IBlockState.of(b), false, true));
        return calculateSpeedVsBlock(stack, IBlockState.of(b)) * avoidanceMultiplier(b);
    }

    private double avoidanceMultiplier(Block b) {
        return Baritone.settings().blocksToAvoidBreaking.value.contains(b) ? Baritone.settings().avoidBreakingMultiplier.value : 1;
    }

    /**
     * Calculates how long would it take to mine the specified block given the best tool
     * in this toolset is used. A negative value is returned if the specified block is unbreakable.
     *
     * @param item  the item to mine it with
     * @param state the blockstate to be mined
     * @return how long it would take in ticks
     */
    /**
     * Rate a hotbar slot by asking the player itself, exactly like real block breaking does.
     * Temporarily selects the slot so held-item-sensitive logic (Tinkers' Construct BreakSpeed
     * events, GregTech harvest checks, IguanaTweaks penalties) all apply, then restores it.
     * Main thread only.
     */
    private double playerSpeedVsBlock(int slot, IBlockState state, BlockPos pos) {
        int previous = player.inventory.currentItem;
        try {
            player.inventory.currentItem = slot;
            float hardness = getHardness(state, pos);
            if (hardness < 0) {
                return -1;
            }
            // hardness 0 means instant break; never divide by it or every slot ties at Infinity
            hardness = Math.max(hardness, 0.001F);
            boolean harvest;
            try {
                harvest = net.minecraftforge.common.ForgeHooks.canHarvestBlock(state.getBlock(), player, state.getMeta());
            } catch (Throwable t) {
                harvest = false;
            }
            float speed;
            try {
                // real position when known; otherwise Forge's own "no position" convention
                // of (0,-1,0), which BreakSpeed event handlers are written to expect
                speed = pos != null
                        ? player.getBreakSpeed(state.getBlock(), !harvest, state.getMeta(), pos.getX(), pos.getY(), pos.getZ())
                        : player.getBreakSpeed(state.getBlock(), !harvest, state.getMeta());
            } catch (Throwable t) {
                return calculateSpeedVsBlock(player.inventory.getStackInSlot(slot), state);
            }
            double result = speed / hardness;
            return harvest ? result / 30 : result / 100;
        } finally {
            player.inventory.currentItem = previous;
        }
    }

    public static double calculateSpeedVsBlock(ItemStack item, IBlockState state) {
        float hardness = getHardness(state, null);
        if (hardness < 0) {
            return -1;
        }
        hardness = Math.max(hardness, 0.001F);

        // Forge's stack- and meta-aware dig speed, not vanilla getStrVsBlock: tools that keep
        // their stats outside the vanilla ItemTool model (Tinkers' Construct reads NBT) only
        // report their real speed through this overload
        float speed;
        if (item == null) {
            speed = 1.0F;
        } else {
            try {
                speed = item.getItem().getDigSpeed(item, state.getBlock(), state.getMeta());
            } catch (Throwable t) {
                speed = item.func_150997_a(state.getBlock()); // getStrVsBlock
            }
        }
        if (speed > 1) {
            int effLevel = EnchantmentHelper.getEnchantmentLevel(Enchantment.efficiency.effectId, item);
            if (effLevel > 0 && item != null) {
                speed += effLevel * effLevel + 1;
            }
        }

        speed /= hardness;
        if (canHarvest(item, state)) {
            return speed / 30;
        } else if (hasRightToolClass(item, state)) {
            // the right category of tool (a pickaxe on an ore, say) even though the harvest
            // check failed — blocks like GregTech ores hide their harvest data from the
            // vanilla-visible paths, and this tier at least beats punching with a bare hand
            return speed / 60;
        } else {
            return speed / 100;
        }
    }

    private static boolean hasRightToolClass(ItemStack item, IBlockState state) {
        if (item == null) {
            return false;
        }
        String tool = null;
        try {
            tool = state.getBlock().getHarvestTool(state.getMeta());
        } catch (Throwable ignored) {
        }
        if (tool == null) {
            Material mat = state.getMaterial();
            if (mat == Material.rock || mat == Material.iron || mat == Material.anvil
                    || mat == Material.glass || mat == Material.ice || mat == Material.packedIce) {
                tool = "pickaxe";
            } else if (mat == Material.wood) {
                tool = "axe";
            } else if (mat == Material.ground || mat == Material.grass || mat == Material.sand
                    || mat == Material.clay || mat == Material.snow || mat == Material.craftedSnow) {
                tool = "shovel";
            }
        }
        if (tool == null) {
            return false;
        }
        try {
            return item.getItem().getToolClasses(item).contains(tool)
                    || item.getItem().getHarvestLevel(item, tool) >= 0;
        } catch (Throwable t) {
            return false;
        }
    }

    private static float getHardness(IBlockState state, BlockPos pos) {
        // with a real position, ask exactly like the game does — blocks like GregTech ores
        // compute hardness from the metadata at the queried coordinates, so dummy coordinates
        // return garbage (even 0.0)
        if (pos != null) {
            try {
                return state.getBlock().getBlockHardness(Minecraft.getMinecraft().theWorld, pos.getX(), pos.getY(), pos.getZ());
            } catch (Throwable ignored) {
            }
        }
        try {
            return state.getBlock().getBlockHardness(null, 0, 0, 0);
        } catch (Throwable t) {
            // modded blocks dereference the world for meta-dependent hardness; retry against
            // the client world, and if the block still throws settle for a moderate guess
            try {
                return state.getBlock().getBlockHardness(Minecraft.getMinecraft().theWorld, 0, 0, 0);
            } catch (Throwable t2) {
                return 5.0F;
            }
        }
    }

    private static boolean canHarvest(ItemStack item, IBlockState state) {
        if (state.getMaterial().isToolNotRequired()) {
            return true;
        }
        if (item == null) {
            return false;
        }
        // the meta-aware Forge check first: blocks like GregTech ores declare their harvest
        // tool/level per metadata, which the stack-only vanilla path can't see
        try {
            if (ForgeHooks.canToolHarvestBlock(state.getBlock(), state.getMeta(), item)) {
                return true;
            }
        } catch (Throwable ignored) {
        }
        return item.func_150998_b(state.getBlock()); // canHarvestBlock
    }

    /**
     * Calculates any modifier to breaking time based on status effects.
     *
     * @return a double to scale block breaking speed.
     */
    private double potionAmplifier() {
        double speed = 1;
        if (player.isPotionActive(Potion.digSpeed)) {
            speed *= 1 + (player.getActivePotionEffect(Potion.digSpeed).getAmplifier() + 1) * 0.2;
        }
        if (player.isPotionActive(Potion.digSlowdown)) {
            switch (player.getActivePotionEffect(Potion.digSlowdown).getAmplifier()) {
                case 0:
                    speed *= 0.3;
                    break;
                case 1:
                    speed *= 0.09;
                    break;
                case 2:
                    speed *= 0.0027; // you might think that 0.09*0.3 = 0.027 so that should be next, that would make too much sense. it's 0.0027.
                    break;
                default:
                    speed *= 0.00081;
                    break;
            }
        }
        return speed;
    }
}
