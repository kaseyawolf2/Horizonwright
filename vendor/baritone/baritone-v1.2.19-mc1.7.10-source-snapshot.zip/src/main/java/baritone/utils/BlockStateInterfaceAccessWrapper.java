/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.utils;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraftforge.common.util.ForgeDirection;

import javax.annotation.Nullable;

/**
 * @author Brady
 * @since 11/5/2019
 */
@SuppressWarnings("NullableProblems")
public final class BlockStateInterfaceAccessWrapper implements IBlockAccess {

    private final BlockStateInterface bsi;
    private final IBlockAccess world;

    BlockStateInterfaceAccessWrapper(BlockStateInterface bsi, IBlockAccess world) {
        this.bsi = bsi;
        this.world = world;
    }

    @Override
    public Block getBlock(int x, int y, int z) {
        // BlockStateInterface#get0(BlockPos) btfo!
        return this.bsi.get0(x, y, z).getBlock();
    }

    @Override
    public int getBlockMetadata(int x, int y, int z) {
        return this.bsi.get0(x, y, z).getMeta();
    }

    @Nullable
    @Override
    public TileEntity getTileEntity(int x, int y, int z) {
        return null;
    }

    @Override
    public int getLightBrightnessForSkyBlocks(int x, int y, int z, int min) {
        return 0;
    }

    @Override
    public int isBlockProvidingPowerTo(int x, int y, int z, int direction) {
        return 0;
    }

    @Override
    public boolean isAirBlock(int x, int y, int z) {
        return this.bsi.get0(x, y, z).getMaterial() == Material.air;
    }

    @Override
    public BiomeGenBase getBiomeGenForCoords(int x, int z) {
        return BiomeGenBase.forest;
    }

    @Override
    public int getHeight() {
        return this.world.getHeight();
    }

    @Override
    public boolean extendedLevelsInChunkCache() {
        return this.world.extendedLevelsInChunkCache();
    }

    @Override
    public boolean isSideSolid(int x, int y, int z, ForgeDirection side, boolean _default) {
        if (y < 0 || y >= 256) {
            return _default;
        }
        return this.bsi.get0(x, y, z).getBlock().isSideSolid(this, x, y, z, side);
    }
}
