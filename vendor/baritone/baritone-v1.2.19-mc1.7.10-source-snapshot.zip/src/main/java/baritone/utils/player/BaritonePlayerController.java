/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.utils.player;

import baritone.api.utils.IPlayerController;
import baritone.utils.accessor.IPlayerControllerMP;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import baritone.compat.EnumFacing;
import baritone.compat.EnumHand;
import baritone.compat.BlockPos;
import baritone.compat.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldSettings.GameType;

/**
 * Implementation of {@link IPlayerController} that chains to the primary player controller's methods
 *
 * @author Brady
 * @since 12/14/2018
 */
public final class BaritonePlayerController implements IPlayerController {

    private final Minecraft mc;

    public BaritonePlayerController(Minecraft mc) {
        this.mc = mc;
    }

    @Override
    public void syncHeldItem() {
        ((IPlayerControllerMP) mc.playerController).callSyncCurrentPlayItem();
    }

    @Override
    public boolean hasBrokenBlock() {
        return ((IPlayerControllerMP) mc.playerController).getCurrentBlock().getY() == -1;
    }

    @Override
    public boolean onPlayerDamageBlock(BlockPos pos, EnumFacing side) {
        // void in 1.7.10; the damage attempt always counts as a swing
        mc.playerController.onPlayerDamageBlock(pos.getX(), pos.getY(), pos.getZ(), side.getIndex());
        return true;
    }

    @Override
    public void resetBlockRemoving() {
        mc.playerController.resetBlockRemoving();
    }

    @Override
    public ItemStack windowClick(int windowId, int slotId, int mouseButton, int mode, EntityPlayer player) {
        return mc.playerController.windowClick(windowId, slotId, mouseButton, mode, player);
    }

    @Override
    public GameType getGameType() {
        return ((IPlayerControllerMP) mc.playerController).getGameType();
    }

    @Override
    public boolean processRightClickBlock(EntityPlayerSP player, World world, BlockPos pos, EnumFacing direction, Vec3d vec, EnumHand hand) {
        // no hands in 1.7.10; the held item is passed explicitly
        return mc.playerController.onPlayerRightClick(player, world, player.getHeldItem(), pos.getX(), pos.getY(), pos.getZ(), direction.getIndex(), vec.toVec3());
    }

    @Override
    public boolean processRightClick(EntityPlayerSP player, World world, EnumHand hand) {
        return mc.playerController.sendUseItem(player, world, player.getHeldItem());
    }

    @Override
    public boolean clickBlock(BlockPos loc, EnumFacing face) {
        // void in 1.7.10
        mc.playerController.clickBlock(loc.getX(), loc.getY(), loc.getZ(), face.getIndex());
        return true;
    }

    @Override
    public void setHittingBlock(boolean hittingBlock) {
        ((IPlayerControllerMP) mc.playerController).setIsHittingBlock(hittingBlock);
    }
}
