/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.api.utils;

import baritone.compat.Compat;

import baritone.api.BaritoneAPI;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import baritone.compat.EnumFacing;
import baritone.compat.EnumHand;
import baritone.compat.BlockPos;
import baritone.compat.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldSettings;

/**
 * @author Brady
 * @since 12/14/2018
 */
public interface IPlayerController {

    void syncHeldItem();

    boolean hasBrokenBlock();

    boolean onPlayerDamageBlock(BlockPos pos, EnumFacing side);

    void resetBlockRemoving();

    // 1.7.10: click type is a plain int (0=pickup, 1=quick move, 2=swap, 3=clone, 4=throw, 5=quick craft, 6=pickup all)
    ItemStack windowClick(int windowId, int slotId, int mouseButton, int clickType, EntityPlayer player);

    WorldSettings.GameType getGameType();

    // 1.7.10: no EnumActionResult, the underlying PlayerControllerMP methods return boolean
    boolean processRightClickBlock(EntityPlayerSP player, World world, BlockPos pos, EnumFacing direction, Vec3d vec, EnumHand hand);

    boolean processRightClick(EntityPlayerSP player, World world, EnumHand hand);

    boolean clickBlock(BlockPos loc, EnumFacing face);

    void setHittingBlock(boolean hittingBlock);

    default double getBlockReachDistance() {
        return this.getGameType().isCreative() ? 5.0F : BaritoneAPI.getSettings().blockReachDistance.value;
    }
}
