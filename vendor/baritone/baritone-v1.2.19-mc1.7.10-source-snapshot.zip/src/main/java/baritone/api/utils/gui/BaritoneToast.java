/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.api.utils.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;

/**
 * 1.7.10 has no toast GUI (toasts are 1.12+), so toast messages are routed to the chat log instead.
 */
public class BaritoneToast {

    public static void addOrUpdate(IChatComponent title, IChatComponent subtitle) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.ingameGUI == null) {
            return;
        }
        IChatComponent line = new ChatComponentText("");
        line.appendSibling(title);
        if (subtitle != null) {
            line.appendText(" ");
            line.appendSibling(subtitle);
        }
        mc.ingameGUI.getChatGUI().printChatMessage(line);
    }
}
