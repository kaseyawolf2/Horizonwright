/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.api.utils;

import baritone.api.utils.accessor.IItemStack;
import baritone.compat.IBlockState;
import com.google.common.collect.ImmutableSet;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLeavesBase;
import net.minecraft.block.BlockRotatedPillar;
import net.minecraft.block.BlockSlab;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.oredict.OreDictionary;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class BlockOptionalMeta {
    // id:meta or id[] or id[properties]; meta may be up to 5 digits (GTNH 16-bit metadata)
    private static final Pattern PATTERN = Pattern.compile("^(?<id>.+?)(?::(?<meta>\\d{1,5})|\\[(?<properties>.+?)?\\])?$");

    private final Block block;
    private final Set<Block> blocks;
    private final int meta;
    private final boolean noMeta;
    // "match any metadata of these blocks" — true for block selectors without :meta, but NEVER
    // for ore dictionary selectors: those expand to exact states, and GT ore blocks pack many
    // different materials into one block distinguished only by metadata
    private final boolean anyMeta;
    private final Set<IBlockState> blockstates;
    private final Set<Integer> stateHashes;
    private final Set<Integer> stackHashes;

    public BlockOptionalMeta(@Nonnull Block block, @Nullable Integer meta) {
        this.block = block;
        this.blocks = Collections.singleton(block);
        this.noMeta = meta == null;
        this.anyMeta = meta == null;
        this.meta = noMeta ? 0 : meta;
        this.blockstates = getStates(block, meta);
        this.stateHashes = getStateHashes(blockstates);
        this.stackHashes = getStackHashes(blockstates);
    }

    public BlockOptionalMeta(@Nonnull Block block) {
        this(block, null);
    }

    public BlockOptionalMeta(@Nonnull String selector) {
        Matcher matcher = PATTERN.matcher(selector);

        if (!matcher.find()) {
            throw new IllegalArgumentException("invalid block selector");
        }

        if (matcher.group("properties") != null) {
            // 1.7.10 has no blockstate properties, only metadata
            throw new IllegalArgumentException("Blockstate properties are not supported on 1.7.10, use id:meta");
        }

        noMeta = matcher.group("meta") == null;

        // exactly two selector forms: namespaced block ids ("minecraft:stone", optionally
        // ":meta") and ore dictionary names ("oreIron", "logWood"); no bare-block-name guessing
        String id = matcher.group("id");
        Set<Integer> extraDropHashes = null;
        if (id.indexOf(':') >= 0) {
            Block parsed = BlockUtils.stringToBlockNullable(id);
            if (parsed == null) {
                throw new IllegalArgumentException("Unknown block '" + id + "' (expected mod:id, e.g. minecraft:stone)");
            }
            block = parsed;
            blocks = Collections.singleton(parsed);
            anyMeta = noMeta;
            meta = noMeta ? 0 : Integer.parseInt(matcher.group("meta"));
            blockstates = getStates(block, getMeta());
        } else {
            // ore dictionary entries carry their own metadata, so a :meta suffix is invalid here
            if (!noMeta) {
                throw new IllegalArgumentException("Meta is only valid on mod:id selectors, not ore dictionary names");
            }
            String oreName = resolveOreDictName(id);
            Set<IBlockState> oreStates = oreName == null ? Collections.emptySet() : getOreDictStates(oreName);
            if (oreStates.isEmpty()) {
                throw new IllegalArgumentException("Unknown ore dictionary name '" + id + "' (blocks must be given as mod:id, e.g. minecraft:stone)");
            }
            blockstates = Collections.unmodifiableSet(oreStates);
            Set<Block> oreBlocks = new LinkedHashSet<>();
            for (IBlockState state : oreStates) {
                oreBlocks.add(state.getBlock());
            }
            blocks = Collections.unmodifiableSet(oreBlocks);
            block = blocks.iterator().next();
            anyMeta = false; // exact states only — see field comment
            meta = 0;
            extraDropHashes = getRelatedOreDropHashes(oreName);
        }
        stateHashes = getStateHashes(blockstates);
        if (extraDropHashes == null || extraDropHashes.isEmpty()) {
            stackHashes = getStackHashes(blockstates);
        } else {
            Set<Integer> combined = new HashSet<>(getStackHashes(blockstates));
            combined.addAll(extraDropHashes);
            stackHashes = ImmutableSet.copyOf(combined);
        }
    }

    /**
     * Resolve a selector to a registered ore dictionary name: the name itself
     * (case-insensitive), then with the conventional "ore" prefix, so "oreMagnetite",
     * "oremagnetite" and plain "magnetite" all work.
     */
    private static String resolveOreDictName(String name) {
        for (String oreName : OreDictionary.getOreNames()) {
            if (oreName.equalsIgnoreCase(name)) {
                return oreName;
            }
        }
        String prefixed = "ore" + name;
        for (String oreName : OreDictionary.getOreNames()) {
            if (oreName.equalsIgnoreCase(prefixed)) {
                return oreName;
            }
        }
        return null;
    }

    /**
     * Items that mining an "oreX" block actually yields but that no drop-probing can discover:
     * GregTech ores drop processed items (raw ore, crushed ore, impure dust, ...) from getDrops
     * overrides invisible to {@code Block.getItemDropped}. A normal ore block drops "rawOreX"; the
     * small-ore variant drops "crushedX" and "dustImpureX". Register every GregTech ore-processing
     * form for this material (matching the GregTech OrePrefixes names) so "#mine oreX" both counts
     * and walks over to pick up the real drops.
     */
    private static Set<Integer> getRelatedOreDropHashes(String oreName) {
        Set<Integer> hashes = new HashSet<>();
        if (!oreName.startsWith("ore")) {
            return hashes;
        }
        String base = oreName.substring(3);
        // GregTech OrePrefixes that a mined ore/small-ore block can drop, per material
        String[] prefixes = {"rawOre", "crushed", "crushedPurified", "crushedCentrifuged", "dustImpure", "dustPure"};
        for (String prefix : prefixes) {
            for (ItemStack stack : OreDictionary.getOres(prefix + base)) {
                if (stack == null || stack.getItem() == null) {
                    continue;
                }
                if (stack.getItemDamage() == OreDictionary.WILDCARD_VALUE) {
                    continue;
                }
                //noinspection ConstantConditions
                hashes.add(((IItemStack) (Object) stack).getBaritoneHash());
            }
        }
        return hashes;
    }

    private static Set<IBlockState> getOreDictStates(String match) {
        Set<IBlockState> states = new LinkedHashSet<>();
        for (ItemStack stack : OreDictionary.getOres(match)) {
            if (stack == null || stack.getItem() == null) {
                continue;
            }
            Block block = Block.getBlockFromItem(stack.getItem());
            if (block == null || block == net.minecraft.init.Blocks.air) {
                continue; // item-only entry (dusts, gems, ...), nothing placeable to mine
            }
            int damage = stack.getItemDamage();
            if (damage == OreDictionary.WILDCARD_VALUE) {
                for (int m = 0; m < 16; m++) {
                    states.add(IBlockState.of(block, m));
                }
            } else {
                // both the placed-meta mapping and the raw damage: ItemBlocks vary on which
                // one corresponds to the world metadata (GT ores map damage 1:1)
                states.add(IBlockState.of(block, stack.getItem().getMetadata(damage)));
                states.add(IBlockState.of(block, damage));
                if (isGregTechOreBlock(block)) {
                    // the ore dictionary registers the ITEM form (bare material id), but ore
                    // generated in the world carries extra bits in its 16-bit metadata:
                    // meta = material(0..999) + stoneType*1000 + natural(+8000) + small(+16000)
                    int material = damage % 1000;
                    for (int stone = 0; stone < 8; stone++) {
                        int base = stone * 1000 + material;
                        states.add(IBlockState.of(block, base));
                        states.add(IBlockState.of(block, base + 8000));  // natural
                        states.add(IBlockState.of(block, base + 16000)); // small
                        states.add(IBlockState.of(block, base + 24000)); // small natural
                    }
                }
            }
        }
        return states;
    }

    /**
     * GT-family ore blocks use the 16-bit metadata encoding expanded above; everything else
     * (vanilla, most mods) must not get phantom high-meta states added.
     */
    private static boolean isGregTechOreBlock(Block block) {
        String name = Block.blockRegistry.getNameForObject(block);
        if (name == null) {
            return false;
        }
        int idx = name.indexOf(':');
        String domain = idx >= 0 ? name.substring(0, idx).toLowerCase(java.util.Locale.ROOT) : "";
        switch (domain) {
            case "gregtech":
            case "bartworks":
            case "miscutils":
            case "gtplusplus":
            case "galacticgreg":
            case "gtnhlanth":
                return true;
            default:
                return false;
        }
    }

    /**
     * Evaluate the target meta value for the specified state. The target meta value is
     * most often that which is influenced by the variant/color of the block.
     * <p>
     * 1.7.10 has no blockstate properties, so this normalizes the raw metadata by masking
     * out the orientation/decay bits for the common cases (logs, leaves, slabs), leaving
     * only the variant/color bits.
     *
     * @param state The state to check
     * @return The target meta of the state
     */
    public static int stateMeta(IBlockState state) {
        Block block = state.getBlock();
        int meta = state.getMeta();
        if (block instanceof BlockRotatedPillar) {
            // logs, hay bales: orientation is in bits 0x4 and 0x8
            return meta & 3;
        }
        if (block instanceof BlockLeavesBase) {
            // leaves: decayable/check-decay are in bits 0x4 and 0x8
            return meta & 3;
        }
        if (block instanceof BlockSlab) {
            // slabs: top half is bit 0x8
            return meta & 7;
        }
        return meta;
    }

    private static Set<IBlockState> getStates(@Nonnull Block block, @Nullable Integer meta) {
        // linked so that getAnyBlockState() deterministically returns the lowest matching meta
        Set<IBlockState> states = new LinkedHashSet<>();
        if (meta != null && meta > 15) {
            // explicit extended metadata (GTNH 16-bit metas): a single exact state
            states.add(IBlockState.of(block, meta));
            return Collections.unmodifiableSet(states);
        }
        for (int m = 0; m < 16; m++) {
            IBlockState state = IBlockState.of(block, m);
            if (meta == null || stateMeta(state) == meta) {
                states.add(state);
            }
        }
        return Collections.unmodifiableSet(states);
    }

    private static ImmutableSet<Integer> getStateHashes(Set<IBlockState> blockstates) {
        return ImmutableSet.copyOf(
                blockstates.stream()
                        .map(IBlockState::hashCode)
                        .toArray(Integer[]::new)
        );
    }

    private static ImmutableSet<Integer> getStackHashes(Set<IBlockState> blockstates) {
        Set<Integer> hashes = new HashSet<>();
        for (IBlockState state : blockstates) {
            // the natural (non-silk-touch) drop, with its real damage value — the damage must
            // NOT be left at 0, or the damage-insensitive match clause would treat the entry
            // as "any damage of this item" (e.g. every GT ore material, not just the target)
            try {
                Item item = state.getBlock().getItemDropped(state.getMeta(), new Random(), 0);
                if (item != null) {
                    ItemStack stack = new ItemStack(item, 1, state.getBlock().damageDropped(state.getMeta()));
                    //noinspection ConstantConditions
                    hashes.add(((IItemStack) (Object) stack).getBaritoneHash());
                }
            } catch (Throwable ignored) {
                // modded getItemDropped/damageDropped may need a live world; drop matching is
                // only used for counting/picking up spilled items, so skip rather than fail
            }
            // the silk-touch / block-item form, so quantity counting treats both consistently
            // ("#mine 5 minecraft:stone" counts silk-touched stone as well as cobblestone)
            try {
                Item blockItem = Item.getItemFromBlock(state.getBlock());
                if (blockItem != null) {
                    ItemStack stack = new ItemStack(blockItem, 1, state.getMeta());
                    //noinspection ConstantConditions
                    hashes.add(((IItemStack) (Object) stack).getBaritoneHash());
                }
            } catch (Throwable ignored) {
            }
        }
        return ImmutableSet.copyOf(hashes);
    }

    public Block getBlock() {
        return block;
    }

    /**
     * @return every block this selector matches; more than one for ore dictionary selectors
     */
    public Set<Block> getAllBlocks() {
        return blocks;
    }

    @Deprecated // deprecated because getMeta() == null no longer implies that this BOM only cares about the block
    public Integer getMeta() {
        return noMeta ? null : meta;
    }

    public boolean isAnyMeta() {
        return anyMeta;
    }

    public boolean matches(@Nonnull Block block) {
        return blocks.contains(block);
    }

    public boolean matches(@Nonnull IBlockState blockstate) {
        if (anyMeta) {
            // "any variant" — matches every metadata, including extended (GTNH 16-bit) values
            // that the enumerated 0..15 state set can't contain
            return blocks.contains(blockstate.getBlock());
        }
        return blocks.contains(blockstate.getBlock()) && stateHashes.contains(blockstate.hashCode());
    }

    public boolean matches(ItemStack stack) {
        //noinspection ConstantConditions
        int hash = ((IItemStack) (Object) stack).getBaritoneHash();

        if (noMeta) {
            hash -= stack.getItemDamage();
        }

        return stackHashes.contains(hash);
    }

    @Override
    public String toString() {
        if (noMeta) {
            return String.format("BlockOptionalMeta{block=%s}", block);
        } else {
            return String.format("BlockOptionalMeta{block=%s,meta=%s}", block, getMeta());
        }
    }

    public static IBlockState blockStateFromStack(ItemStack stack) {
        return IBlockState.of(
                Block.getBlockFromItem(stack.getItem()),
                stack.getItem().getMetadata(stack.getItemDamage())
        );
    }

    public IBlockState getAnyBlockState() {
        if (blockstates.size() > 0) {
            return blockstates.iterator().next();
        }

        return null;
    }

    public Set<IBlockState> getAllBlockStates() {
        return blockstates;
    }

    public Set<Integer> stackHashes() {
        return stackHashes;
    }
}
