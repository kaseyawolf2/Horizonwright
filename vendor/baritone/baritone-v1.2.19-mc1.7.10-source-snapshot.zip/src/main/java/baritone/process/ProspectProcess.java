/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.process;

import baritone.Baritone;
import baritone.api.pathing.goals.Goal;
import baritone.api.pathing.goals.GoalBlock;
import baritone.api.pathing.goals.GoalNear;
import baritone.api.process.PathingCommand;
import baritone.api.process.PathingCommandType;
import baritone.api.utils.BetterBlockPos;
import baritone.api.utils.Rotation;
import baritone.api.utils.RotationUtils;
import baritone.api.utils.input.Input;
import baritone.compat.BlockPos;
import baritone.compat.Compat;
import baritone.compat.IBlockState;
import baritone.pathing.movement.MovementHelper;
import baritone.utils.BaritoneProcessHelper;
import net.minecraft.block.Block;
import net.minecraft.util.EnumChatFormatting;

import java.util.HashSet;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;

/**
 * GTNH vein prospector. GregTech: New Horizons generates one ore vein (or a barren slot) per
 * 3x3-chunk grid cell, centered on the chunk whose coordinates are congruent to 1 mod 3. This
 * process walks to the nearest un-prospected cell's center chunk, digs the center column down,
 * and breaks the first vein ore it exposes — which is all VisualProspecting needs to register
 * the whole vein on the JourneyMap overlay. Barren cells advance to the next nearest cell.
 */
public final class ProspectProcess extends BaritoneProcessHelper {

    /**
     * Dig no deeper than this; overworld GTNH veins bottom out above the bedrock band.
     */
    private static final int FLOOR_Y = 6;

    /**
     * How far to search for the next un-prospected grid cell, in cells (1 cell = 48 blocks).
     */
    private static final int CELL_SEARCH_RADIUS = 6;

    private final Set<Long> prospectedCells = new HashSet<>();

    private boolean active;
    private long targetCell;
    private int columnX;
    private int columnZ;
    private BlockPos orePos;

    public ProspectProcess(Baritone baritone) {
        super(baritone);
    }

    public void prospect() {
        onLostControl();
        if (!selectNextCell()) {
            logDirect("All grid cells within range are already prospected this session.");
            return;
        }
        active = true;
        logDirect(String.format("Prospecting the vein slot around (%d, %d) — digging down to Y=%d.", columnX, columnZ, FLOOR_Y));
    }

    @Override
    public boolean isActive() {
        return active;
    }

    @Override
    public PathingCommand onTick(boolean calcFailed, boolean isSafeToCancel) {
        baritone.getInputOverrideHandler().clearAllKeys();

        if (orePos != null) {
            IBlockState state = Compat.getBlockState(ctx.world(), orePos);
            if (!isVeinOre(state.getBlock())) {
                // broken (or otherwise gone) — VisualProspecting registers the vein on break
                prospectedCells.add(cellKey(Math.floorDiv(orePos.getX() >> 4, 3), Math.floorDiv(orePos.getZ() >> 4, 3)));
                prospectedCells.add(targetCell);
                logDirect(EnumChatFormatting.GREEN + "Vein ore broken — check the JourneyMap overlay. Run #prospect again for the next cell.");
                onLostControl();
                return new PathingCommand(null, PathingCommandType.CANCEL_AND_SET_GOAL);
            }
            Optional<Rotation> rot = RotationUtils.reachable(ctx, orePos);
            if (rot.isPresent() && isSafeToCancel) {
                baritone.getLookBehavior().updateTarget(rot.get(), true);
                MovementHelper.switchToBestToolFor(ctx, state, orePos);
                if (ctx.isLookingAt(orePos)) {
                    baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_LEFT, true);
                }
                return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
            }
            return new PathingCommand(new GoalNear(orePos, 2), PathingCommandType.SET_GOAL_AND_PATH);
        }

        BlockPos found = scanForVeinOre();
        if (found != null) {
            orePos = found;
            IBlockState state = Compat.getBlockState(ctx.world(), found);
            logDirect(String.format("Vein ore spotted at (%d, %d, %d): %s — breaking one block to register it.",
                    found.getX(), found.getY(), found.getZ(), state.getBlock().getLocalizedName()));
            return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
        }

        if (calcFailed) {
            logDirect("Couldn't path to the vein column, canceling prospect.");
            onLostControl();
            return new PathingCommand(null, PathingCommandType.CANCEL_AND_SET_GOAL);
        }

        BetterBlockPos feet = ctx.playerFeet();
        if (Math.abs(feet.x - columnX) <= 1 && Math.abs(feet.z - columnZ) <= 1 && feet.y <= FLOOR_Y + 1) {
            prospectedCells.add(targetCell);
            logDirect("No vein ore down to Y=" + FLOOR_Y + " in this cell (barren or already mined out), moving to the next one.");
            if (!selectNextCell()) {
                logDirect("All grid cells within range are already prospected this session.");
                onLostControl();
                return new PathingCommand(null, PathingCommandType.CANCEL_AND_SET_GOAL);
            }
        }

        Goal goal = new GoalBlock(columnX, FLOOR_Y, columnZ);
        return new PathingCommand(goal, PathingCommandType.SET_GOAL_AND_PATH);
    }

    @Override
    public void onLostControl() {
        active = false;
        orePos = null;
        baritone.getInputOverrideHandler().clearAllKeys();
    }

    @Override
    public String displayName0() {
        return "Prospecting" + (orePos != null ? " (breaking vein ore)" : String.format(" (column %d, %d)", columnX, columnZ));
    }

    /**
     * Pick the closest grid cell not yet prospected this session and aim at its center chunk's
     * middle column. Returns false if everything within {@link #CELL_SEARCH_RADIUS} is done.
     */
    private boolean selectNextCell() {
        BetterBlockPos feet = ctx.playerFeet();
        int playerCellX = Math.floorDiv(feet.x >> 4, 3);
        int playerCellZ = Math.floorDiv(feet.z >> 4, 3);
        long bestDist = Long.MAX_VALUE;
        boolean found = false;
        for (int dx = -CELL_SEARCH_RADIUS; dx <= CELL_SEARCH_RADIUS; dx++) {
            for (int dz = -CELL_SEARCH_RADIUS; dz <= CELL_SEARCH_RADIUS; dz++) {
                int cellX = playerCellX + dx;
                int cellZ = playerCellZ + dz;
                if (prospectedCells.contains(cellKey(cellX, cellZ))) {
                    continue;
                }
                // vein center chunk of the cell, then that chunk's middle column
                int colX = ((cellX * 3 + 1) << 4) + 8;
                int colZ = ((cellZ * 3 + 1) << 4) + 8;
                long distSq = (long) (colX - feet.x) * (colX - feet.x) + (long) (colZ - feet.z) * (colZ - feet.z);
                if (distSq < bestDist) {
                    bestDist = distSq;
                    targetCell = cellKey(cellX, cellZ);
                    columnX = colX;
                    columnZ = colZ;
                    found = true;
                }
            }
        }
        return found;
    }

    private BlockPos scanForVeinOre() {
        BetterBlockPos feet = ctx.playerFeet();
        for (int dy = 3; dy >= -3; dy--) {
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    int x = feet.x + dx;
                    int y = feet.y + dy;
                    int z = feet.z + dz;
                    if (y < 0 || y >= 256) {
                        continue;
                    }
                    if (isVeinOre(ctx.world().getBlock(x, y, z))) {
                        return new BlockPos(x, y, z);
                    }
                }
            }
        }
        return null;
    }

    /**
     * A GT-family vein ore block: breaking one registers the vein with VisualProspecting.
     * Small ores are excluded — they're scattered everywhere and don't belong to a vein.
     */
    private static boolean isVeinOre(Block block) {
        String name = Block.blockRegistry.getNameForObject(block);
        if (name == null) {
            return false;
        }
        String lower = name.toLowerCase(Locale.ROOT);
        int colon = lower.indexOf(':');
        if (colon == -1) {
            return false;
        }
        String domain = lower.substring(0, colon);
        String path = lower.substring(colon + 1);
        if (!path.contains("ore") || path.contains("small")) {
            return false;
        }
        switch (domain) {
            case "gregtech":
            case "bartworks":
            case "miscutils":
            case "gtplusplus":
            case "galacticgreg":
            case "gtnhlanth":
                return true;
            default:
                return false;
        }
    }

    private static long cellKey(int cellX, int cellZ) {
        return ((long) cellX << 32) | (cellZ & 0xFFFFFFFFL);
    }
}
