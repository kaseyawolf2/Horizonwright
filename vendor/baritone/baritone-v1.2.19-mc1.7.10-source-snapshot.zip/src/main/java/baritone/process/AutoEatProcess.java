/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.process;

import baritone.Baritone;
import baritone.api.process.PathingCommand;
import baritone.api.process.PathingCommandType;
import baritone.utils.BaritoneProcessHelper;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Automatically eat when hungry so the player doesn't starve while working. This is a temporary,
 * high-priority process: when hunger drops to {@link Baritone.settings#autoEatThreshold} it takes
 * control from whatever is running (mining, farming, ...), eats a bite, and hands control back.
 * <p>
 * 1.7.10 eating is tied to the physical use-key being held (the game keeps eating only while
 * {@code keyBindUseItem} is pressed - Minecraft.java), so we drive that key directly, exactly like
 * a player holding right-click. Eating itself is started with {@code sendUseItem} so it never
 * accidentally interacts with / opens a block (e.g. a GregTech machine) in the crosshair.
 * <p>
 * Food selection is diminishing-returns aware: when AppleCore is present (e.g. GTNH ships it with
 * The Spice of Life: Carrot Edition) each candidate is ranked by the hunger it will <i>actually</i>
 * restore for this player right now - a food eaten too often has its value reduced by the mod, and
 * we read that reduced value through AppleCore instead of the item's base hunger. To avoid wasting
 * food, we then pick the largest food that still fits the current hunger deficit (so a 5-haunch
 * meal isn't burned to fill a half-haunch gap), only falling back to the smallest available food
 * when nothing fits. Without AppleCore this degrades to the vanilla base-hunger value.
 * <p>
 * Not upstream; added for the 1.7.10 backport.
 */
public final class AutoEatProcess extends BaritoneProcessHelper {

    private boolean holdingUseKey;

    public AutoEatProcess(Baritone baritone) {
        super(baritone);
    }

    @Override
    public boolean isActive() {
        if (!Baritone.settings().autoEat.value) {
            setUseKey(false);
            return false;
        }
        if (ctx.player() == null || ctx.world() == null) {
            return false;
        }
        if (isEating()) {
            return true; // finish the current bite before anything else touches control
        }
        // not mid-bite: never leave the use-key stuck down (this runs every tick, even when another
        // process like defend has control), so a preempted bite can't keep the key pressed
        setUseKey(false);
        if (ctx.player().getFoodStats().getFoodLevel() > Baritone.settings().autoEatThreshold.value) {
            return false;
        }
        return bestFoodSlot() >= 0;
    }

    @Override
    public PathingCommand onTick(boolean calcFailed, boolean isSafeToCancel) {
        boolean eating = isEating();
        int slot = eating ? ctx.player().inventory.currentItem : bestFoodSlot();
        if (!eating && slot < 0) {
            setUseKey(false);
            return new PathingCommand(null, PathingCommandType.DEFER);
        }
        if (!eating) {
            // don't yank the player out of a critical movement (parkour, fall) to start a bite
            if (!isSafeToCancel) {
                setUseKey(false);
                return new PathingCommand(null, PathingCommandType.DEFER);
            }
            baritone.getInputOverrideHandler().clearAllKeys(); // stop mining/moving while we eat
            ctx.player().inventory.currentItem = slot;
            // start eating without a block right-click, so we can't open a machine GUI etc.
            ctx.minecraft().playerController.sendUseItem(ctx.player(), ctx.world(), ctx.player().inventory.getStackInSlot(slot));
        }
        setUseKey(true); // hold the use key so vanilla keeps eating until the bite finishes
        return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
    }

    /** True while the player is actively consuming a food item (as opposed to using any other item). */
    private boolean isEating() {
        return ctx.player().isUsingItem() && isEdible(ctx.player().inventory.getCurrentItem());
    }

    /**
     * Pick the safe hotbar food to eat, or -1 if there's nothing worth eating.
     * <p>
     * Foods are valued by the hunger they will <i>actually</i> restore right now ({@link #effectiveHunger},
     * which accounts for Spice of Life-style diminishing returns via AppleCore). To avoid wasting food we
     * prefer the largest food that still fits within the current hunger deficit - so we top off with the
     * least overfill and the fewest bites - and only fall back to the smallest food when every option would
     * overfill anyway. A food whose value has been diminished to nothing is skipped so we don't burn it for
     * zero gain.
     */
    private int bestFoodSlot() {
        int deficit = 20 - ctx.player().getFoodStats().getFoodLevel(); // hunger points needed to top off
        int bestFit = -1;                     // largest food that fits within the deficit (no overfill)
        int bestFitHunger = 0;
        int smallest = -1;                    // smallest food overall, used only if nothing fits
        int smallestHunger = Integer.MAX_VALUE;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = ctx.player().inventory.getStackInSlot(i);
            if (!isEdible(stack)) {
                continue;
            }
            int hunger = effectiveHunger(stack);
            if (hunger <= 0) {
                continue; // diminished to nothing (or valueless) - don't waste the item
            }
            if (hunger < smallestHunger) {
                smallestHunger = hunger;
                smallest = i;
            }
            if (hunger <= deficit && hunger > bestFitHunger) {
                bestFitHunger = hunger;
                bestFit = i;
            }
        }
        return bestFit >= 0 ? bestFit : smallest;
    }

    /**
     * Hunger this food will actually restore for the current player. When AppleCore is present its
     * player-aware value is used, which already has Spice of Life diminishing returns baked in; otherwise
     * we fall back to the item's base hunger.
     */
    private int effectiveHunger(ItemStack stack) {
        Integer modified = appleCoreHunger(stack);
        if (modified != null) {
            return modified;
        }
        return ((ItemFood) stack.getItem()).func_150905_g(stack);
    }

    // AppleCore (squeek.applecore.api.food.FoodValues) reflection - the backport doesn't compile against
    // the mod, so we resolve it once at runtime and gracefully do nothing when it's absent.
    private static boolean appleCoreChecked;
    private static Method appleCoreGetFoodValues; // FoodValues.get(ItemStack, EntityPlayer) -> FoodValues
    private static Field appleCoreHungerField;    // FoodValues.hunger (int)

    /** Player-modified hunger via AppleCore, or null if AppleCore isn't present / the lookup fails. */
    private Integer appleCoreHunger(ItemStack stack) {
        if (!appleCoreChecked) {
            appleCoreChecked = true;
            try {
                Class<?> foodValues = Class.forName("squeek.applecore.api.food.FoodValues");
                appleCoreGetFoodValues = foodValues.getMethod("get", ItemStack.class, EntityPlayer.class);
                appleCoreHungerField = foodValues.getField("hunger");
            } catch (Throwable t) {
                appleCoreGetFoodValues = null;
                appleCoreHungerField = null;
            }
        }
        if (appleCoreGetFoodValues == null) {
            return null;
        }
        try {
            Object values = appleCoreGetFoodValues.invoke(null, stack, ctx.player());
            if (values == null) {
                return null;
            }
            return appleCoreHungerField.getInt(values);
        } catch (Throwable t) {
            return null;
        }
    }

    private static boolean isEdible(ItemStack stack) {
        if (stack == null || !(stack.getItem() instanceof ItemFood)) {
            return false;
        }
        Item item = stack.getItem();
        // skip foods that hurt you, and golden apples (too valuable to burn on hunger)
        if (item == net.minecraft.init.Items.rotten_flesh
                || item == net.minecraft.init.Items.spider_eye
                || item == net.minecraft.init.Items.poisonous_potato
                || item == net.minecraft.init.Items.chicken
                || item == net.minecraft.init.Items.golden_apple) {
            return false;
        }
        // pufferfish is Items.fish with metadata 3 (nausea/poison)
        return !(item == net.minecraft.init.Items.fish && stack.getItemDamage() == 3);
    }

    private void setUseKey(boolean pressed) {
        if (pressed == holdingUseKey || ctx.minecraft() == null || ctx.minecraft().gameSettings == null) {
            return;
        }
        KeyBinding useItem = ctx.minecraft().gameSettings.keyBindUseItem;
        KeyBinding.setKeyBindState(useItem.getKeyCode(), pressed);
        holdingUseKey = pressed;
    }

    @Override
    public void onLostControl() {
        setUseKey(false);
    }

    @Override
    public boolean isTemporary() {
        return true;
    }

    @Override
    public double priority() {
        // above mining/farming so we interrupt them to eat, but below defend (6.0): fight first, then eat
        return 5.5;
    }

    @Override
    public String displayName0() {
        return "Auto eat";
    }
}
