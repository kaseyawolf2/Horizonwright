/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.process;

import baritone.Baritone;
import baritone.api.pathing.goals.Goal;
import baritone.api.pathing.goals.GoalNear;
import baritone.api.process.PathingCommand;
import baritone.api.process.PathingCommandType;
import baritone.api.utils.Rotation;
import baritone.api.utils.RotationUtils;
import baritone.compat.BlockPos;
import baritone.compat.Compat;
import baritone.utils.BaritoneProcessHelper;
import com.google.common.collect.Multimap;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.monster.IMob;
import net.minecraft.item.ItemStack;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * Automatically melee nearby hostile mobs. This is a temporary, high-priority process: whenever a
 * hostile is within {@link Baritone.settings#defendRange} it forcefully takes control from whatever
 * else is running (farming, mining, pathing, ...), fights, and then hands control straight back so
 * the interrupted task resumes.
 * <p>
 * 1.7.10 is pre-1.9, so there is no player attack cooldown - melee is just "face the mob and
 * left-click as fast as you can". We swing every tick (like an autoclicker); the target's own
 * hurt-resistance ticks gate when a hit actually lands, so this deals maximum damage with no
 * artificial waiting.
 * <p>
 * Not upstream; added for the 1.7.10 backport.
 */
public final class DefendProcess extends BaritoneProcessHelper {

    // melee reach; a little generous so we start swinging as soon as the server would accept a hit
    private static final double ATTACK_REACH = 3.5;
    // how close to get to a mob that's out of reach
    private static final int APPROACH_RADIUS = 2;
    // how long to ignore a mob we couldn't path to, so it doesn't stall mining/farming forever
    private static final long UNREACHABLE_BLACKLIST_MS = 3000;

    private Entity target;
    // mobs we recently failed to reach (e.g. behind a wall) -> when to reconsider them
    private final Map<Entity, Long> unreachableUntil = new HashMap<>();

    public DefendProcess(Baritone baritone) {
        super(baritone);
    }

    @Override
    public boolean isActive() {
        if (!Baritone.settings().defendAgainstMobs.value) {
            target = null;
            return false;
        }
        if (ctx.player() == null || ctx.world() == null) {
            return false;
        }
        target = findTarget();
        return target != null;
    }

    private Entity findTarget() {
        long now = System.currentTimeMillis();
        unreachableUntil.values().removeIf(expiry -> expiry <= now); // drop expired blacklist entries
        double range = Baritone.settings().defendRange.value;
        double bestDistSq = range * range;
        Entity best = null;
        for (Object o : ctx.world().loadedEntityList) {
            if (!(o instanceof IMob)) {
                continue; // IMob marks vanilla + most modded hostile mobs
            }
            Entity e = (Entity) o;
            if (e.isDead || e == ctx.player()) {
                continue;
            }
            if (unreachableUntil.containsKey(e)) {
                continue; // recently couldn't path to this one; leave the current task alone
            }
            double distSq = ctx.player().getDistanceSqToEntity(e);
            if (distSq < bestDistSq) {
                bestDistSq = distSq;
                best = e;
            }
        }
        return best;
    }

    @Override
    public PathingCommand onTick(boolean calcFailed, boolean isSafeToCancel) {
        if (target == null || target.isDead || !ctx.world().loadedEntityList.contains(target)) {
            target = findTarget();
        }
        if (target == null) {
            // nothing to fight this tick; let the process underneath us keep working
            return new PathingCommand(null, PathingCommandType.DEFER);
        }

        // drop any inputs the interrupted process was force-holding (e.g. farm's left-click)
        baritone.getInputOverrideHandler().clearAllKeys();

        double dist = ctx.player().getDistanceToEntity(target);
        if (dist <= ATTACK_REACH) {
            // in range: pick the strongest weapon, then stand, face the mob, and swing
            if (Baritone.settings().defendAutoWeapon.value) {
                int slot = bestWeaponSlot(target);
                if (slot != ctx.player().inventory.currentItem) {
                    // attackEntity() calls syncCurrentPlayItem(), so the server sees the new weapon
                    ctx.player().inventory.currentItem = slot;
                }
            }
            Rotation rotation = RotationUtils.calcRotationFromVec3d(
                    ctx.playerHead(),
                    Compat.getPositionEyes(target, 1.0F),
                    ctx.playerRotations()
            );
            baritone.getLookBehavior().updateTarget(rotation, true);
            // swing every tick: no attack cooldown in 1.7.10, and the mob's hurt-resistance decides
            // when a hit registers, so this lands damage the instant the mob is vulnerable again
            ctx.minecraft().playerController.attackEntity(ctx.player(), target);
            ctx.player().swingItem();
            return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
        }

        // out of range: if we already failed to path here (e.g. mob behind a wall), stop hogging
        // control - blacklist it briefly and let mining/farming continue instead of stalling
        if (calcFailed) {
            unreachableUntil.put(target, System.currentTimeMillis() + UNREACHABLE_BLACKLIST_MS);
            target = null;
            return new PathingCommand(null, PathingCommandType.DEFER);
        }
        // otherwise walk up to the (moving) mob, revalidating as it moves
        Goal goal = new GoalNear(new BlockPos(target), APPROACH_RADIUS);
        return new PathingCommand(goal, PathingCommandType.REVALIDATE_GOAL_AND_PATH);
    }

    /**
     * Pick the hotbar slot with the highest attack damage against {@code target}. The currently
     * held slot is the baseline, so we only switch when something is strictly better (no hotbar
     * flicker on ties).
     */
    private int bestWeaponSlot(Entity target) {
        int currentSlot = ctx.player().inventory.currentItem;
        int best = currentSlot;
        double bestDamage = attackDamage(ctx.player().inventory.getStackInSlot(currentSlot), target);
        for (int i = 0; i < 9; i++) {
            double damage = attackDamage(ctx.player().inventory.getStackInSlot(i), target);
            if (damage > bestDamage) {
                bestDamage = damage;
                best = i;
            }
        }
        return best;
    }

    /**
     * Estimate an item's melee damage against {@code target}. Two sources are combined because no
     * single one covers everything on 1.7.10:
     * <ul>
     *   <li>the vanilla/Forge {@code generic.attackDamage} attribute modifier - swords, axes, and
     *       most modded weapons;</li>
     *   <li>a reflective {@code getDamageVsEntity(Entity)} call - Tinkers' Construct tools deal
     *       damage through {@code onLeftClickEntity} and never register an attack attribute, so the
     *       attribute path alone scores every TiC weapon as zero.</li>
     * </ul>
     * The larger of the two is returned, so a Tinkers weapon and a vanilla sword rank on the same
     * scale. A bare hand / non-weapon scores ~1.
     */
    private static double attackDamage(ItemStack stack, Entity target) {
        if (stack == null || stack.getItem() == null) {
            return 1.0; // fist
        }
        double best = 0;
        try {
            Multimap<String, AttributeModifier> modifiers = stack.getAttributeModifiers();
            for (AttributeModifier modifier : modifiers.get(SharedMonsterAttributes.attackDamage.getAttributeUnlocalizedName())) {
                best += modifier.getAmount();
            }
        } catch (Throwable ignored) {
        }
        try {
            // TiC ToolCore.getDamageVsEntity(Entity); absent on vanilla items (their variant is no-arg)
            Method m = stack.getItem().getClass().getMethod("getDamageVsEntity", Entity.class);
            Object result = m.invoke(stack.getItem(), target);
            if (result instanceof Number) {
                best = Math.max(best, ((Number) result).doubleValue());
            }
        } catch (Throwable ignored) {
        }
        return Math.max(best, 1.0);
    }

    @Override
    public void onLostControl() {
        target = null;
        unreachableUntil.clear();
    }

    @Override
    public boolean isTemporary() {
        // forcefully take control, then give it back to whatever we interrupted (like the auto-eat/combat-pause processes)
        return true;
    }

    @Override
    public double priority() {
        // above farm/mine/goto (DEFAULT_PRIORITY) and the inventory pauser (5.1): staying alive comes first
        return 6.0;
    }

    @Override
    public String displayName0() {
        return "Defending against " + (target == null ? "?" : target.getCommandSenderName());
    }
}
