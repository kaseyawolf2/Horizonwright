/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.process;

import baritone.compat.Compat;

import baritone.Baritone;
import baritone.api.BaritoneAPI;
import baritone.api.pathing.goals.Goal;
import baritone.api.pathing.goals.GoalBlock;
import baritone.api.pathing.goals.GoalGetToBlock;
import baritone.api.pathing.goals.GoalComposite;
import baritone.api.process.IFarmProcess;
import baritone.api.process.PathingCommand;
import baritone.api.process.PathingCommandType;
import baritone.api.utils.BlockOptionalMeta;
import baritone.api.utils.BlockUtils;
import baritone.api.utils.RayTraceUtils;
import baritone.api.utils.Rotation;
import baritone.api.utils.RotationUtils;
import baritone.api.utils.input.Input;
import baritone.cache.WorldScanner;
import baritone.pathing.movement.MovementHelper;
import baritone.utils.BaritoneProcessHelper;
import net.minecraft.block.*;
import baritone.compat.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import baritone.compat.Blocks;
import baritone.compat.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemDye;
import net.minecraft.item.ItemStack;
import baritone.compat.EnumFacing;
import baritone.compat.BlockPos;
import baritone.compat.RayTraceResult;
import baritone.compat.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;

public final class FarmProcess extends BaritoneProcessHelper implements IFarmProcess {

    private boolean active;

    private List<BlockPos> locations;
    private int tickCount;

    private int range;
    private BlockPos center;

    // user-specified crop types harvested by right-clicking (e.g. modded GTNH crops); empty by default
    private List<BlockOptionalMeta> customCrops = Collections.emptyList();
    private Set<Block> customCropBlocks = Collections.emptySet();
    private boolean warnedUnknownRipeness;

    // registered IGrowable crops detected automatically (see farmAutoDetectCrops); right-click harvested
    private Set<Block> autoCropBlocks = Collections.emptySet();

    private static final List<Item> FARMLAND_PLANTABLE = Arrays.asList(
            Items.MELON_SEEDS,
            Items.WHEAT_SEEDS,
            Items.PUMPKIN_SEEDS,
            Items.POTATO,
            Items.CARROT
    );

    private static final List<Item> PICKUP_DROPPED = Arrays.asList(
            Items.MELON_SEEDS,
            Items.MELON,
            Item.getItemFromBlock(Blocks.MELON_BLOCK),
            Items.WHEAT_SEEDS,
            Items.WHEAT,
            Items.PUMPKIN_SEEDS,
            Item.getItemFromBlock(Blocks.PUMPKIN),
            Items.POTATO,
            Items.CARROT,
            Items.NETHER_WART,
            Items.REEDS,
            Item.getItemFromBlock(Blocks.CACTUS)
    );

    public FarmProcess(Baritone baritone) {
        super(baritone);
    }

    @Override
    public boolean isActive() {
        return active;
    }

    @Override
    public void farm(int range, BlockPos pos, List<BlockOptionalMeta> crops) {
        if (pos == null) {
            center = baritone.getPlayerContext().playerFeet();
        } else {
            center = pos;
        }
        this.range = range;
        this.customCrops = crops == null ? Collections.emptyList() : crops;
        Set<Block> blocks = new HashSet<>();
        for (BlockOptionalMeta bom : this.customCrops) {
            blocks.addAll(bom.getAllBlocks());
        }
        this.customCropBlocks = blocks;
        this.warnedUnknownRipeness = false;

        Set<Block> auto = new HashSet<>();
        if (Baritone.settings().farmAutoDetectCrops.value) {
            for (Object o : Block.blockRegistry) {
                Block b = (Block) o;
                if (isAutoHarvestableCrop(b)) {
                    auto.add(b);
                }
            }
        }
        this.autoCropBlocks = auto;

        active = true;
        locations = null;
    }

    /** How a ready crop is picked up: broken (pumpkin/melon/cane/cactus) or right-clicked (everything else). */
    private enum HarvestAction {
        NONE, BREAK, RIGHT_CLICK
    }

    private enum Harvest {
        WHEAT((BlockCrops) Blocks.WHEAT),
        CARROTS((BlockCrops) Blocks.CARROTS),
        POTATOES((BlockCrops) Blocks.POTATOES),
        PUMPKIN(Blocks.PUMPKIN, state -> true, true),
        MELON(Blocks.MELON_BLOCK, state -> true, true),
        NETHERWART(Blocks.NETHER_WART, state -> state.getMeta() >= 3, false),
        COCOA(Blocks.COCOA, state -> ((state.getMeta() & 12) >> 2) >= 2, false),
        SUGARCANE(Blocks.REEDS, null, true) {
            @Override
            public boolean readyToHarvest(World world, BlockPos pos, IBlockState state) {
                if (Baritone.settings().replantCrops.value) {
                    return Compat.getBlockState(world, pos.down()).getBlock() instanceof BlockReed;
                }
                return true;
            }
        },
        CACTUS(Blocks.CACTUS, null, true) {
            @Override
            public boolean readyToHarvest(World world, BlockPos pos, IBlockState state) {
                if (Baritone.settings().replantCrops.value) {
                    return Compat.getBlockState(world, pos.down()).getBlock() instanceof BlockCactus;
                }
                return true;
            }
        };
        public final Block block;
        public final Predicate<IBlockState> readyToHarvest;
        // pumpkins/melons/cane/cactus can't be right-click harvested, so they're always broken
        public final boolean harvestByBreaking;

        Harvest(BlockCrops blockCrops) {
            this(blockCrops, state -> state.getMeta() >= 7, false);
            // max age (metadata) is 7 for wheat, carrots, and potatoes
        }

        Harvest(Block block, Predicate<IBlockState> readyToHarvest, boolean harvestByBreaking) {
            this.block = block;
            this.readyToHarvest = readyToHarvest;
            this.harvestByBreaking = harvestByBreaking;
        }

        public boolean readyToHarvest(World world, BlockPos pos, IBlockState state) {
            return readyToHarvest.test(state);
        }
    }

    /**
     * Decide how (if at all) a scanned block should be harvested this pass. Right-click is the default
     * for anything crop-like; only the physically-un-right-clickable specials (pumpkin/melon/cane/cactus)
     * break. Custom-named and auto-detected {@link IGrowable} crops are right-clicked when mature.
     */
    private HarvestAction classifyHarvest(World world, BlockPos pos, IBlockState state) {
        Block block = state.getBlock();
        boolean rightClick = Baritone.settings().farmRightClickHarvest.value;
        for (Harvest harvest : Harvest.values()) {
            if (harvest.block == block) {
                if (!harvest.readyToHarvest(world, pos, state)) {
                    return HarvestAction.NONE;
                }
                return (harvest.harvestByBreaking || !rightClick) ? HarvestAction.BREAK : HarvestAction.RIGHT_CLICK;
            }
        }
        if (isCustomCrop(block)) {
            return customCropReady(world, pos, state) ? HarvestAction.RIGHT_CLICK : HarvestAction.NONE;
        }
        if (autoCropBlocks.contains(block)) {
            // auto-detected modded crops can only be right-clicked (we don't know how to break them safely)
            return rightClick && isGrowableRipe(world, pos, state) ? HarvestAction.RIGHT_CLICK : HarvestAction.NONE;
        }
        return HarvestAction.NONE;
    }

    /** An {@link IGrowable} crop is ripe once it reports it can no longer grow (canGrow == false). */
    private static boolean isGrowableRipe(World world, BlockPos pos, IBlockState state) {
        return state.getBlock() instanceof IGrowable
                && !((IGrowable) state.getBlock()).func_149851_a(world, pos.getX(), pos.getY(), pos.getZ(), world.isRemote);
    }

    /**
     * Every {@link IGrowable} block is treated as a harvestable crop except these: they're growable but
     * either aren't crops, or are handled elsewhere (pumpkin/melon fruit is broken; cocoa has the Harvest
     * enum + log-replant flow).
     */
    private static boolean isAutoHarvestableCrop(Block block) {
        return block instanceof IGrowable
                && !(block instanceof BlockStem)        // pumpkin/melon stems
                && !(block instanceof BlockSapling)     // trees
                && !(block instanceof BlockMushroom)    // mushrooms
                && !(block instanceof BlockTallGrass)   // grass / fern
                && !(block instanceof BlockDoublePlant) // sunflowers, large ferns, ...
                && !(block instanceof BlockGrass)       // the spreading grass-dirt block
                && !(block instanceof BlockCocoa);      // handled by the Harvest enum
    }

    private boolean isCustomCrop(Block block) {
        return customCropBlocks.contains(block);
    }

    /**
     * A user-targeted (right-click harvestable) crop is ripe when either the selector pinned an
     * explicit {@code :meta} that the block is currently at, or - failing that - the block reports
     * via {@link IGrowable} that it can no longer grow. Crops that are neither pinned nor
     * {@link IGrowable} give us no reliable ripeness signal, so we skip them (and warn once) rather
     * than risk right-clicking an immature crop every tick.
     */
    private boolean customCropReady(World world, BlockPos pos, IBlockState state) {
        for (BlockOptionalMeta bom : customCrops) {
            if (!bom.getAllBlocks().contains(state.getBlock())) {
                continue;
            }
            if (bom.getMeta() != null) {
                // explicit meta -> harvest only at exactly that metadata
                if (bom.matches(state)) {
                    return true;
                }
                continue;
            }
            if (state.getBlock() instanceof IGrowable) {
                // func_149851_a == canGrow: true while the crop can still grow, so ripe == !canGrow
                if (!((IGrowable) state.getBlock()).func_149851_a(world, pos.getX(), pos.getY(), pos.getZ(), world.isRemote)) {
                    return true;
                }
                continue;
            }
            if (!warnedUnknownRipeness) {
                warnedUnknownRipeness = true;
                logDirect("Can't tell when '" + BlockUtils.blockToString(state.getBlock())
                        + "' is ripe; specify the mature metadata like 'mod:id:7' to harvest it.");
            }
        }
        return false;
    }

    private boolean isPlantable(ItemStack stack) {
        return FARMLAND_PLANTABLE.contains(stack.getItem());
    }

    private boolean isBoneMeal(ItemStack stack) {
        // 1.7.10: bone meal is dye (ItemDye) with damage 15
        return stack != null && stack.getItem() instanceof ItemDye && stack.getItemDamage() == 15;
    }

    private boolean isNetherWart(ItemStack stack) {
        return stack != null && stack.getItem().equals(Items.NETHER_WART);
    }

    private boolean isCocoa(ItemStack stack) {
        // 1.7.10: cocoa beans are dye (ItemDye) with damage 3
        return stack != null && stack.getItem() instanceof ItemDye && stack.getItemDamage() == 3;
    }

    @Override
    public PathingCommand onTick(boolean calcFailed, boolean isSafeToCancel) {
        ArrayList<Block> scan = new ArrayList<>();
        for (Harvest harvest : Harvest.values()) {
            scan.add(harvest.block);
        }
        scan.addAll(customCropBlocks);
        scan.addAll(autoCropBlocks);
        if (Baritone.settings().replantCrops.value) {
            scan.add(Blocks.FARMLAND);
            scan.add(Blocks.LOG);
            if (Baritone.settings().replantNetherWart.value) {
                scan.add(Blocks.SOUL_SAND);
            }
        }

        if (Baritone.settings().mineGoalUpdateInterval.value != 0 && tickCount++ % Baritone.settings().mineGoalUpdateInterval.value == 0) {
            Baritone.getExecutor().execute(() -> locations = BaritoneAPI.getProvider().getWorldScanner().scanChunkRadius(ctx, scan, 256, 10, 10));
        }
        if (locations == null) {
            return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
        }
        List<BlockPos> toBreak = new ArrayList<>();
        List<BlockPos> toHarvestRightClick = new ArrayList<>();
        List<BlockPos> openFarmland = new ArrayList<>();
        List<BlockPos> bonemealable = new ArrayList<>();
        List<BlockPos> openSoulsand = new ArrayList<>();
        List<BlockPos> openLog = new ArrayList<>();
        for (BlockPos pos : locations) {
            //check if the target block is out of range.
            if (range != 0 && pos.getDistance(center.getX(), center.getY(), center.getZ()) > range) {
                continue;
            }

            IBlockState state = Compat.getBlockState(ctx.world(), pos);
            boolean airAbove = Compat.getBlockState(ctx.world(), pos.up()).getBlock() instanceof BlockAir;
            if (state.getBlock() == Blocks.FARMLAND) {
                if (airAbove) {
                    openFarmland.add(pos);
                }
                continue;
            }
            if (state.getBlock() == Blocks.SOUL_SAND) {
                if (airAbove) {
                    openSoulsand.add(pos);
                }
                continue;
            }
            if (state.getBlock() == Blocks.LOG) {
                // 1.7.10: log variant is the low two metadata bits; jungle is 3
                if ((state.getMeta() & 3) != 3) {
                    continue;
                }
                for (EnumFacing direction : EnumFacing.Plane.HORIZONTAL) {
                    if (Compat.getBlockState(ctx.world(), pos.offset(direction)).getBlock() instanceof BlockAir) {
                        openLog.add(pos);
                        break;
                    }
                }
                continue;
            }
            HarvestAction action = classifyHarvest(ctx.world(), pos, state);
            if (action == HarvestAction.BREAK) {
                toBreak.add(pos);
                continue;
            }
            if (action == HarvestAction.RIGHT_CLICK) {
                toHarvestRightClick.add(pos);
                continue;
            }
            // not a ready crop this pass: offer bonemeal to anything still growing
            if (state.getBlock() instanceof IGrowable) {
                IGrowable ig = (IGrowable) state.getBlock();
                // func_149851_a = canGrow, func_149852_a = canUseBonemeal
                if (ig.func_149851_a(ctx.world(), pos.getX(), pos.getY(), pos.getZ(), true)
                        && ig.func_149852_a(ctx.world(), ctx.world().rand, pos.getX(), pos.getY(), pos.getZ())) {
                    bonemealable.add(pos);
                }
            }
        }

        baritone.getInputOverrideHandler().clearAllKeys();
        for (BlockPos pos : toBreak) {
            Optional<Rotation> rot = RotationUtils.reachable(ctx, pos);
            if (rot.isPresent() && isSafeToCancel) {
                baritone.getLookBehavior().updateTarget(rot.get(), true);
                MovementHelper.switchToBestToolFor(ctx, Compat.getBlockState(ctx.world(), pos));
                if (ctx.isLookingAt(pos)) {
                    baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_LEFT, true);
                }
                return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
            }
        }
        for (BlockPos pos : toHarvestRightClick) {
            // modded crops (e.g. GTNH) harvest and auto-replant on right-click rather than breaking
            Optional<Rotation> rot = RotationUtils.reachable(ctx, pos);
            if (rot.isPresent() && isSafeToCancel) {
                baritone.getLookBehavior().updateTarget(rot.get(), true);
                if (ctx.isLookingAt(pos)) {
                    baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_RIGHT, true);
                }
                return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
            }
        }
        ArrayList<BlockPos> both = new ArrayList<>(openFarmland);
        both.addAll(openSoulsand);
        for (BlockPos pos : both) {
            boolean soulsand = openSoulsand.contains(pos);
            Optional<Rotation> rot = RotationUtils.reachableOffset(ctx, pos, new Vec3d(pos.getX() + 0.5, pos.getY() + 1, pos.getZ() + 0.5), ctx.playerController().getBlockReachDistance(), false);
            if (rot.isPresent() && isSafeToCancel && baritone.getInventoryBehavior().throwaway(true, soulsand ? this::isNetherWart : this::isPlantable)) {
                RayTraceResult result = RayTraceUtils.rayTraceTowards(ctx.player(), rot.get(), ctx.playerController().getBlockReachDistance());
                if (result.typeOfHit == RayTraceResult.Type.BLOCK && result.sideHit == EnumFacing.UP) {
                    baritone.getLookBehavior().updateTarget(rot.get(), true);
                    if (ctx.isLookingAt(pos)) {
                        baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_RIGHT, true);
                    }
                    return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
                }
            }
        }
        for (BlockPos pos : openLog) {
            for (EnumFacing dir : EnumFacing.Plane.HORIZONTAL) {
                if (!(Compat.getBlockState(ctx.world(), pos.offset(dir)).getBlock() instanceof BlockAir)) {
                    continue;
                }
                Vec3d faceCenter = new Vec3d(pos).add(0.5, 0.5, 0.5).add(new Vec3d(dir.getDirectionVec()).scale(0.5));
                Optional<Rotation> rot = RotationUtils.reachableOffset(ctx, pos, faceCenter, ctx.playerController().getBlockReachDistance(), false);
                if (rot.isPresent() && isSafeToCancel && baritone.getInventoryBehavior().throwaway(true, this::isCocoa)) {
                    RayTraceResult result = RayTraceUtils.rayTraceTowards(ctx.player(), rot.get(), ctx.playerController().getBlockReachDistance());
                    if (result.typeOfHit == RayTraceResult.Type.BLOCK && result.sideHit == dir) {
                        baritone.getLookBehavior().updateTarget(rot.get(), true);
                        if (ctx.isLookingAt(pos)) {
                            baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_RIGHT, true);
                        }
                        return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
                    }
                }
            }
        }
        for (BlockPos pos : bonemealable) {
            Optional<Rotation> rot = RotationUtils.reachable(ctx, pos);
            if (rot.isPresent() && isSafeToCancel && baritone.getInventoryBehavior().throwaway(true, this::isBoneMeal)) {
                baritone.getLookBehavior().updateTarget(rot.get(), true);
                if (ctx.isLookingAt(pos)) {
                    baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_RIGHT, true);
                }
                return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
            }
        }

        if (calcFailed) {
            logDirect("Farm failed");
            if (Baritone.settings().notificationOnFarmFail.value) {
                logNotification("Farm failed", true);
            }
            onLostControl();
            return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
        }

        List<Goal> goalz = new ArrayList<>();
        for (BlockPos pos : toBreak) {
            goalz.add(new BuilderProcess.GoalBreak(pos));
        }
        for (BlockPos pos : toHarvestRightClick) {
            // GoalBreak also gets us within reach + line of sight, which is what a right-click needs
            goalz.add(new BuilderProcess.GoalBreak(pos));
        }
        if (baritone.getInventoryBehavior().throwaway(false, this::isPlantable)) {
            for (BlockPos pos : openFarmland) {
                goalz.add(new GoalBlock(pos.up()));
            }
        }
        if (baritone.getInventoryBehavior().throwaway(false, this::isNetherWart)) {
            for (BlockPos pos : openSoulsand) {
                goalz.add(new GoalBlock(pos.up()));
            }
        }
        if (baritone.getInventoryBehavior().throwaway(false, this::isCocoa)) {
            for (BlockPos pos : openLog) {
                for (EnumFacing direction : EnumFacing.Plane.HORIZONTAL) {
                    if (Compat.getBlockState(ctx.world(), pos.offset(direction)).getBlock() instanceof BlockAir) {
                        goalz.add(new GoalGetToBlock(pos.offset(direction)));
                    }
                }
            }
        }
        if (baritone.getInventoryBehavior().throwaway(false, this::isBoneMeal)) {
            for (BlockPos pos : bonemealable) {
                goalz.add(new GoalBlock(pos));
            }
        }
        for (Entity entity : ctx.world().loadedEntityList) {
            if (entity instanceof EntityItem && entity.onGround) {
                EntityItem ei = (EntityItem) entity;
                if (PICKUP_DROPPED.contains(ei.getEntityItem().getItem()) || isCocoa(ei.getEntityItem())) {
                    // +0.1 because of farmland's 0.9375 dummy height lol
                    goalz.add(new GoalBlock(new BlockPos(entity.posX, entity.posY + 0.1, entity.posZ)));
                }
            }
        }
        return new PathingCommand(new GoalComposite(goalz.toArray(new Goal[0])), PathingCommandType.SET_GOAL_AND_PATH);
    }

    @Override
    public void onLostControl() {
        active = false;
    }

    @Override
    public String displayName0() {
        return "Farming";
    }
}
