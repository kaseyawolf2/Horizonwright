/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.launch.mixins;

import baritone.api.utils.accessor.IItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(ItemStack.class)
public abstract class MixinItemStack implements IItemStack {

    @Shadow
    int itemDamage;

    @Shadow
    public abstract Item getItem();

    /**
     * Computed on demand rather than cached from constructor injections: 1.7.10 creates
     * inventory stacks through several paths (NBT load, packet read) and a stale/never-set
     * cached hash made every stack "match" quantity filters (all-zero hashes).
     * <p>
     * Encoding: registry id in the high bits, damage in the low 16 — collision-free, and
     * {@code hash - getItemDamage()} still yields the damage-independent item key that
     * {@link baritone.api.utils.BlockOptionalMeta} relies on.
     */
    @Override
    public int getBaritoneHash() {
        Item item = getItem();
        return item == null ? -1 : (Item.getIdFromItem(item) << 16) | (itemDamage & 0xFFFF);
    }
}
