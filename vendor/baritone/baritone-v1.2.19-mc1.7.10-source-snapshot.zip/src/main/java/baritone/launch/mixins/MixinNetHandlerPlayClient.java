/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.launch.mixins;

import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;
import baritone.api.event.events.BlockChangeEvent;
import baritone.api.event.events.ChunkEvent;
import baritone.api.event.events.type.EventState;
import baritone.api.utils.Pair;
import baritone.compat.BlockPos;
import baritone.compat.ChunkPos;
import baritone.compat.IBlockState;
import net.minecraft.block.Block;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.server.S21PacketChunkData;
import net.minecraft.network.play.server.S26PacketMapChunkBulk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Collections;

/**
 * @author Brady
 * @since 8/3/2018
 */
// priority > 1000: GTNH's ChunkAPI overwrites the block-change handlers at default priority,
// and Mixin forbids injecting into a method merged by an equal-or-higher-priority mixin.
// Applying after ChunkAPI makes the injection legal; require = 0 then skips it cleanly when
// the vanilla call site no longer exists in the replacement body.
@Mixin(value = NetHandlerPlayClient.class, priority = 1010)
public class MixinNetHandlerPlayClient {

    @Inject(
            method = "handleChunkData",
            at = @At("HEAD")
    )
    private void preHandleChunkData(S21PacketChunkData packetIn, CallbackInfo ci) {
        IBaritone baritone = BaritoneAPI.getProvider().getBaritoneForConnection((NetHandlerPlayClient) (Object) this);
        if (baritone == null) {
            return;
        }
        baritone.getGameEventHandler().onChunkEvent(
                new ChunkEvent(
                        EventState.PRE,
                        packetIn.func_149274_i() ? ChunkEvent.Type.POPULATE_FULL : ChunkEvent.Type.POPULATE_PARTIAL,
                        packetIn.func_149273_e(),
                        packetIn.func_149271_f()
                )
        );
    }

    @Inject(
            method = "handleChunkData",
            at = @At("RETURN")
    )
    private void postHandleChunkData(S21PacketChunkData packetIn, CallbackInfo ci) {
        IBaritone baritone = BaritoneAPI.getProvider().getBaritoneForConnection((NetHandlerPlayClient) (Object) this);
        if (baritone == null) {
            return;
        }
        baritone.getGameEventHandler().onChunkEvent(
                new ChunkEvent(
                        EventState.POST,
                        packetIn.func_149274_i() ? ChunkEvent.Type.POPULATE_FULL : ChunkEvent.Type.POPULATE_PARTIAL,
                        packetIn.func_149273_e(),
                        packetIn.func_149271_f()
                )
        );
    }

    /**
     * 1.7.10 delivers almost all chunks via the bulk packet (PlayerManager batches up to 5 per
     * tick into S26); the single-chunk S21 path above is the exception. Without this hook the
     * cached world never populates, which breaks anything cache-driven (#explore in particular).
     */
    @Inject(
            method = "handleMapChunkBulk",
            at = @At("HEAD")
    )
    private void preHandleMapChunkBulk(S26PacketMapChunkBulk packetIn, CallbackInfo ci) {
        IBaritone baritone = BaritoneAPI.getProvider().getBaritoneForConnection((NetHandlerPlayClient) (Object) this);
        if (baritone == null) {
            return;
        }
        for (int i = 0; i < packetIn.func_149254_d(); i++) {
            baritone.getGameEventHandler().onChunkEvent(
                    new ChunkEvent(
                            EventState.PRE,
                            ChunkEvent.Type.POPULATE_FULL,
                            packetIn.func_149255_a(i),
                            packetIn.func_149253_b(i)
                    )
            );
        }
    }

    @Inject(
            method = "handleMapChunkBulk",
            at = @At("RETURN")
    )
    private void postHandleMapChunkBulk(S26PacketMapChunkBulk packetIn, CallbackInfo ci) {
        IBaritone baritone = BaritoneAPI.getProvider().getBaritoneForConnection((NetHandlerPlayClient) (Object) this);
        if (baritone == null) {
            return;
        }
        for (int i = 0; i < packetIn.func_149254_d(); i++) {
            baritone.getGameEventHandler().onChunkEvent(
                    new ChunkEvent(
                            EventState.POST,
                            ChunkEvent.Type.POPULATE_FULL,
                            packetIn.func_149255_a(i),
                            packetIn.func_149253_b(i)
                    )
            );
        }
    }

    /**
     * Wraps the single call path that both handleBlockChange and handleMultiBlockChange use to
     * apply a server-sent block change to the client world, so we can observe the exact
     * coordinates and new state without needing packet field accessors.
     * <p>
     * require = 0: mods like GTNH's ChunkAPI overwrite these handlers with their own logic, in
     * which case the vanilla call site doesn't exist. The block-change event is only a cache
     * refresh optimization, so degrade gracefully instead of crashing the pack.
     */
    @Redirect(
            method = {"handleBlockChange", "handleMultiBlockChange"},
            require = 0,
            at = @At(
                    value = "INVOKE",
                    target = "net/minecraft/client/multiplayer/WorldClient.func_147492_c(IIILnet/minecraft/block/Block;I)Z"
            )
    )
    private boolean onBlockChangeApplied(WorldClient world, int x, int y, int z, Block block, int meta) {
        boolean result = world.func_147492_c(x, y, z, block, meta);

        IBaritone baritone = BaritoneAPI.getProvider().getBaritoneForConnection((NetHandlerPlayClient) (Object) this);
        if (baritone != null) {
            Pair<BlockPos, IBlockState> changed = new Pair<>(new BlockPos(x, y, z), IBlockState.of(block, meta));
            baritone.getGameEventHandler().onBlockChange(new BlockChangeEvent(
                    new ChunkPos(x >> 4, z >> 4),
                    Collections.singletonList(changed)
            ));
        }

        return result;
    }
}
