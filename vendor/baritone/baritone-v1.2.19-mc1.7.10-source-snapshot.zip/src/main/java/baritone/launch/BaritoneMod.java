/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.launch;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.event.FMLInitializationEvent;

/**
 * FML entry point for the 1.7.10 backport. All of Baritone's actual bootstrapping happens from
 * the {@code Minecraft.startGame} mixin; this class only exists so Forge knows about the mod.
 */
@Mod(
        modid = "baritone",
        name = "Baritone",
        version = "1.2.19-mc1.7.10",
        acceptedMinecraftVersions = "[1.7.10]",
        acceptableRemoteVersions = "*"
)
public class BaritoneMod {

    @Mod.EventHandler
    public void onInit(FMLInitializationEvent event) {
        // no-op; see baritone.launch.mixins.MixinMinecraft#postInit
    }
}
