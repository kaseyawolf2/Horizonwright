/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.launch.mixins;

import baritone.utils.accessor.IChunkProviderClient;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import net.minecraft.client.multiplayer.ChunkProviderClient;
import net.minecraft.world.ChunkCoordIntPair;
import net.minecraft.world.chunk.Chunk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 1.7.10's ChunkProviderClient keeps chunks in a LongHashMap, which is not iterable and not
 * generic; we maintain a parallel fastutil map (same key packing as ChunkCoordIntPair.chunkXZ2Int)
 * so Baritone can do fast lookups and iteration off-thread copies.
 */
@Mixin(ChunkProviderClient.class)
public class MixinChunkProviderClient implements IChunkProviderClient {

    @Unique
    private final Long2ObjectMap<Chunk> baritoneLoadedChunks = new Long2ObjectOpenHashMap<>();

    @Inject(method = "loadChunk", at = @At("RETURN"))
    private void postLoadChunk(int chunkX, int chunkZ, CallbackInfoReturnable<Chunk> cir) {
        Chunk chunk = cir.getReturnValue();
        if (chunk != null) {
            this.baritoneLoadedChunks.put(ChunkCoordIntPair.chunkXZ2Int(chunkX, chunkZ), chunk);
        }
    }

    @Inject(method = "unloadChunk", at = @At("RETURN"))
    private void postUnloadChunk(int chunkX, int chunkZ, CallbackInfo ci) {
        this.baritoneLoadedChunks.remove(ChunkCoordIntPair.chunkXZ2Int(chunkX, chunkZ));
    }

    @Override
    public Long2ObjectMap<Chunk> loadedChunks() {
        return this.baritoneLoadedChunks;
    }
}
