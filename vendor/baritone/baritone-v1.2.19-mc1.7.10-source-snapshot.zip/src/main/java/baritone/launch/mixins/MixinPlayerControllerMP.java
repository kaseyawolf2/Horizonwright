/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.launch.mixins;

import baritone.api.BaritoneAPI;
import baritone.api.event.events.BlockInteractEvent;
import baritone.compat.BlockPos;
import baritone.utils.accessor.IPlayerControllerMP;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerControllerMP.class)
public abstract class MixinPlayerControllerMP implements IPlayerControllerMP {

    @Accessor("isHittingBlock")
    @Override
    public abstract void setIsHittingBlock(boolean isHittingBlock);

    @Accessor("currentBlockX")
    public abstract int getCurrentBlockX();

    @Accessor("currentBlockY")
    public abstract int getCurrentBlockY();

    @Accessor("currentblockZ") // sic: 1.7.10 MCP field name has a lowercase 'b'
    public abstract int getCurrentBlockZ();

    @Override
    public BlockPos getCurrentBlock() {
        return new BlockPos(getCurrentBlockX(), getCurrentBlockY(), getCurrentBlockZ());
    }

    @Invoker("syncCurrentPlayItem")
    @Override
    public abstract void callSyncCurrentPlayItem();

    @Accessor("currentGameType")
    @Override
    public abstract net.minecraft.world.WorldSettings.GameType getGameType();

    @Inject(
            method = "clickBlock",
            at = @At("HEAD")
    )
    private void clickBlock(int x, int y, int z, int side, CallbackInfo ci) {
        BaritoneAPI.getProvider().getPrimaryBaritone().getGameEventHandler().onBlockInteract(
                new BlockInteractEvent(new BlockPos(x, y, z), BlockInteractEvent.Type.START_BREAK)
        );
    }

    @Inject(
            method = "onPlayerRightClick",
            at = @At("HEAD")
    )
    private void onPlayerRightClick(EntityPlayer player, World worldIn, ItemStack itemStackIn, int x, int y, int z, int side, Vec3 hitVector, CallbackInfoReturnable<Boolean> cir) {
        BaritoneAPI.getProvider().getPrimaryBaritone().getGameEventHandler().onBlockInteract(
                new BlockInteractEvent(new BlockPos(x, y, z), BlockInteractEvent.Type.USE)
        );
    }
}
