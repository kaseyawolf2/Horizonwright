/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.launch.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import paulscode.sound.SoundSystem;
import paulscode.sound.SoundSystemConfig;
import paulscode.sound.Source;

/**
 * Not a Baritone feature — a crash guard for a vanilla 1.7.10 bug that fast modern CPUs hit
 * constantly: FML's double resource reload races two paulscode SoundSystem inits, the loser
 * trips the 30s watchdog, paulscode switches to "Silent Mode" and unloads the OpenAL natives
 * while the winner's sources are still registered. The next {@code playing()} query from the
 * client thread (MusicTicker) then dies with an UnsatisfiedLinkError and takes the whole game
 * down. Degrade to "not playing" (silence) instead.
 */
@Mixin(targets = "net.minecraft.client.audio.SoundManager$SoundSystemStarterThread")
public abstract class MixinSoundSystemStarterThread extends SoundSystem {

    /**
     * @author Baritone 1.7.10 backport
     * @reason wrap the synchronous OpenAL query in a catch so a torn-down sound system
     * reports silence instead of crashing the client thread with an UnsatisfiedLinkError
     */
    @Overwrite
    public boolean playing(String sourcename) {
        synchronized (SoundSystemConfig.THREAD_SYNC) {
            try {
                if (this.soundLibrary == null) {
                    return false;
                }
                Source source = (Source) this.soundLibrary.getSources().get(sourcename);
                if (source == null) {
                    return false;
                }
                return source.playing() || source.paused() || source.preLoad;
            } catch (Throwable t) {
                // OpenAL natives are gone (vanilla sound-init race, "Silent Mode" switch)
                return false;
            }
        }
    }
}
