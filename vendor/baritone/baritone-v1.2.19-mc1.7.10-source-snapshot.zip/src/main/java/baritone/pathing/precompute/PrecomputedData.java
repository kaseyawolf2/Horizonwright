/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.pathing.precompute;

import baritone.compat.Compat;

import baritone.pathing.movement.MovementHelper;
import baritone.utils.BlockStateInterface;
import net.minecraft.block.Block;
import baritone.compat.IBlockState;

import java.util.concurrent.ConcurrentHashMap;

import static baritone.pathing.precompute.Ternary.MAYBE;
import static baritone.pathing.precompute.Ternary.YES;

public class PrecomputedData {

    // 1.7.10 has no global blockstate id map; a state is (block id, meta). Vanilla ids are
    // 0..4095, but EndlessIDs (GTNH) registers blocks far beyond that, so size the cache from
    // the registry's real max id (frozen after mod load, so compute it once) and treat anything
    // still out of range as uncacheable rather than indexing out of bounds.
    private static volatile int size = -1;

    private final int[] data = new int[computeSize()];

    // states with extended metadata (GTNH 16-bit metas, e.g. GT ores) can't pack into the
    // id<<4 array; cache them here — without this they'd be recomputed through the expensive
    // (exception-probing) MovementHelper paths on every single A* evaluation
    private final ConcurrentHashMap<IBlockState, Integer> extendedData = new ConcurrentHashMap<>();

    private static int computeSize() {
        int cached = size;
        if (cached == -1) {
            int maxId = 4095;
            for (Object block : Block.blockRegistry) {
                maxId = Math.max(maxId, Block.getIdFromBlock((Block) block));
            }
            cached = (maxId + 1) << 4;
            size = cached;
        }
        return cached;
    }

    private static final int COMPLETED_MASK = 1 << 0;
    private static final int CAN_WALK_ON_MASK = 1 << 1;
    private static final int CAN_WALK_ON_SPECIAL_MASK = 1 << 2;
    private static final int CAN_WALK_THROUGH_MASK = 1 << 3;
    private static final int CAN_WALK_THROUGH_SPECIAL_MASK = 1 << 4;
    private static final int FULLY_PASSABLE_MASK = 1 << 5;
    private static final int FULLY_PASSABLE_SPECIAL_MASK = 1 << 6;

    private static int stateId(IBlockState state) {
        int meta = state.getMeta();
        if (meta > 15) {
            return -1; // extended metadata (GTNH 16-bit metas) can't pack into the id<<4 cache
        }
        return (Block.getIdFromBlock(state.getBlock()) << 4) | meta;
    }

    private int computeData(IBlockState state) {
        int blockData = 0;

        Ternary canWalkOnState = MovementHelper.canWalkOnBlockState(state);
        if (canWalkOnState == YES) {
            blockData |= CAN_WALK_ON_MASK;
        }
        if (canWalkOnState == MAYBE) {
            blockData |= CAN_WALK_ON_SPECIAL_MASK;
        }

        Ternary canWalkThroughState = MovementHelper.canWalkThroughBlockState(state);
        if (canWalkThroughState == YES) {
            blockData |= CAN_WALK_THROUGH_MASK;
        }
        if (canWalkThroughState == MAYBE) {
            blockData |= CAN_WALK_THROUGH_SPECIAL_MASK;
        }

        Ternary fullyPassableState = MovementHelper.fullyPassableBlockState(state);
        if (fullyPassableState == YES) {
            blockData |= FULLY_PASSABLE_MASK;
        }
        if (fullyPassableState == MAYBE) {
            blockData |= FULLY_PASSABLE_SPECIAL_MASK;
        }

        blockData |= COMPLETED_MASK;
        return blockData;
    }

    /**
     * Cached pathing flags for the state: the packed int array for vanilla-range states, the
     * extended map for GTNH 16-bit-metadata states, computing and storing on first sight.
     */
    private int getData(IBlockState state) {
        int id = stateId(state);
        if (id < 0 || id >= data.length) {
            Integer cached = extendedData.get(state);
            if (cached != null) {
                return cached;
            }
            int computed = computeData(state);
            extendedData.put(state, computed);
            return computed;
        }
        int blockData = data[id];
        if ((blockData & COMPLETED_MASK) == 0) { // we need to fill in the data
            blockData = computeData(state);
            data[id] = blockData; // in theory, this is thread "safe" because every thread should compute the exact same int to write?
        }
        return blockData;
    }

    public boolean canWalkOn(BlockStateInterface bsi, int x, int y, int z, IBlockState state) {
        int blockData = getData(state);
        if ((blockData & CAN_WALK_ON_SPECIAL_MASK) != 0) {
            return MovementHelper.canWalkOnPosition(bsi, x, y, z, state);
        } else {
            return (blockData & CAN_WALK_ON_MASK) != 0;
        }
    }

    public boolean canWalkThrough(BlockStateInterface bsi, int x, int y, int z, IBlockState state) {
        int blockData = getData(state);
        if ((blockData & CAN_WALK_THROUGH_SPECIAL_MASK) != 0) {
            return MovementHelper.canWalkThroughPosition(bsi, x, y, z, state);
        } else {
            return (blockData & CAN_WALK_THROUGH_MASK) != 0;
        }
    }

    public boolean fullyPassable(BlockStateInterface bsi, int x, int y, int z, IBlockState state) {
        int blockData = getData(state);
        if ((blockData & FULLY_PASSABLE_SPECIAL_MASK) != 0) {
            return MovementHelper.fullyPassablePosition(bsi, x, y, z, state);
        } else {
            return (blockData & FULLY_PASSABLE_MASK) != 0;
        }
    }
}
