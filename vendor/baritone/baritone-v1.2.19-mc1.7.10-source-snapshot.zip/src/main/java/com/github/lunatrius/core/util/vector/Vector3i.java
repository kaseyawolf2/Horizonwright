/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.github.lunatrius.core.util.vector;

/**
 * Compile-only stub matching LunatriusCore 1.2.1-GTNH. Excluded from the built jar;
 * the real class is provided at runtime by the LunatriusCore mod (Schematica dependency).
 * In the real class getX/getY live in the Vector2i superclass, which is fine: virtual
 * method resolution walks the superclass chain at runtime.
 */
public class Vector3i {

    public int getX() {
        throw new LinkageError("stub, must never be shipped or loaded");
    }

    public int getY() {
        throw new LinkageError("stub, must never be shipped or loaded");
    }

    public int getZ() {
        throw new LinkageError("stub, must never be shipped or loaded");
    }
}
