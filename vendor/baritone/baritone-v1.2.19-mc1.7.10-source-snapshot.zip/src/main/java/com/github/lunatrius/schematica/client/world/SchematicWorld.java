/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.github.lunatrius.schematica.client.world;

import com.github.lunatrius.core.util.vector.Vector3i;
import net.minecraft.profiler.Profiler;
import net.minecraft.world.World;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.WorldSettings;
import net.minecraft.world.storage.ISaveHandler;

/**
 * Compile-only stub matching Schematica 1.12.6-GTNH. Excluded from the built jar;
 * the real class is provided at runtime by the Schematica mod.
 * <p>
 * The real class is concrete; abstract here just skips stubbing World's abstract
 * methods. Block/meta/height reads must go through a World-typed reference so the
 * call sites reobfuscate to the SRG names the real class overrides
 * (func_147439_a / func_72805_g / func_72800_K).
 */
public abstract class SchematicWorld extends World {

    public final Vector3i position = null;
    public boolean isRendering;

    private SchematicWorld() {
        super((ISaveHandler) null, (String) null, (WorldProvider) null, (WorldSettings) null, (Profiler) null);
        throw new LinkageError("stub, must never be shipped or loaded");
    }

    public int getWidth() {
        throw new LinkageError("stub, must never be shipped or loaded");
    }

    public int getLength() {
        throw new LinkageError("stub, must never be shipped or loaded");
    }
}
