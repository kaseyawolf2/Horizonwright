/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package baritone.pathing.movement.movements;

import baritone.api.IBaritone;
import baritone.api.pathing.movement.MovementStatus;
import baritone.api.utils.BetterBlockPos;
import baritone.api.utils.input.Input;
import baritone.compat.IBlockState;
import baritone.pathing.movement.CalculationContext;
import baritone.pathing.movement.Movement;
import baritone.pathing.movement.MovementCapabilities;
import baritone.pathing.movement.MovementHelper;
import baritone.pathing.movement.MovementState;
import com.google.common.collect.ImmutableSet;

import java.util.LinkedHashSet;
import java.util.Set;

/** A jump onto an adjacent ledge two or three blocks above the source. */
public final class MovementHighJump extends Movement {

    private final int height;
    private boolean leftGround;

    public MovementHighJump(IBaritone baritone, BetterBlockPos src, BetterBlockPos dest) {
        super(baritone, src, dest, blocksToClear(src, dest));
        this.height = dest.y - src.y;
        if (height < 2) {
            throw new IllegalArgumentException("High jump height must be at least two blocks");
        }
    }

    private static BetterBlockPos[] blocksToClear(BetterBlockPos src, BetterBlockPos dest) {
        LinkedHashSet<BetterBlockPos> result = new LinkedHashSet<>();
        int height = dest.y - src.y;
        for (int dy = 2; dy <= height + 1; dy++) {
            result.add(src.up(dy));
        }
        result.add(dest);
        result.add(dest.up());
        return result.toArray(new BetterBlockPos[0]);
    }

    @Override
    public void reset() {
        super.reset();
        leftGround = false;
    }

    @Override
    public double calculateCost(CalculationContext context) {
        return cost(context, src.x, src.y, src.z, dest.x, dest.z, height);
    }

    public static double cost(CalculationContext context, int x, int y, int z,
                              int destX, int destZ, int height) {
        if (height > context.maxJumpHeight || height < 2 || MovementHelper.isBottomSlab(context.get(x, y - 1, z))) {
            return COST_INF;
        }
        IBlockState support = context.get(destX, y + height - 1, destZ);
        if (!MovementHelper.canWalkOn(context, destX, y + height - 1, destZ, support)) {
            return COST_INF;
        }
        double total = Math.max(JUMP_ONE_BLOCK_COST, WALK_ONE_BLOCK_COST) + context.jumpPenalty + height * 2;
        for (BetterBlockPos pos : blocksToClear(new BetterBlockPos(x, y, z),
                new BetterBlockPos(destX, y + height, destZ))) {
            total += MovementHelper.getMiningDurationTicks(context, pos.x, pos.y, pos.z, true);
            if (total >= COST_INF) {
                return COST_INF;
            }
        }
        return total;
    }

    @Override
    protected Set<BetterBlockPos> calculateValidPositions() {
        ImmutableSet.Builder<BetterBlockPos> result = ImmutableSet.builder();
        for (int dy = 0; dy <= height + 1; dy++) {
            result.add(src.up(dy));
        }
        result.add(dest).add(dest.up());
        return result.build();
    }

    @Override
    public MovementState updateState(MovementState state) {
        super.updateState(state);
        if (state.getStatus() != MovementStatus.RUNNING) {
            return state;
        }
        if (ctx.playerFeet().equals(dest)) {
            return state.setStatus(MovementStatus.SUCCESS);
        }
        if (!ctx.player().onGround) {
            leftGround = true;
        } else if (leftGround) {
            MovementCapabilities.invalidateObservedJump(ctx.player());
            return state.setStatus(MovementStatus.UNREACHABLE);
        }
        if (MovementCapabilities.maxJumpHeight(ctx.player()) < height) {
            return state.setStatus(MovementStatus.UNREACHABLE);
        }
        MovementHelper.moveTowards(ctx, state, dest);
        state.setInput(Input.SPRINT, true);
        if (ctx.player().onGround && ctx.playerFeet().equals(src)) {
            state.setInput(Input.JUMP, true);
        }
        return state;
    }
}
