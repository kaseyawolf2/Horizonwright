/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package baritone.pathing.movement;

import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

import java.lang.reflect.Field;

/**
 * Describes movement bonuses which are exposed by the player rather than by
 * the blocks in the world. Most step-assist implementations update
 * {@link EntityPlayerSP#stepHeight}; vanilla jump boost is a potion effect.
 * Adventure Backpack's Piston Boots predate a common jump-height API, so their
 * configured boost is read reflectively when that optional mod is present.
 *
 * The observed take-off velocity fills the same gap for other 1.7.10 mods:
 * after any jump with an event-based boost, subsequent calculations can use
 * the measured capability without linking Baritone against that mod.
 */
public final class MovementCapabilities {

    private static final double VANILLA_JUMP_VELOCITY = 0.42D;
    private static final double MIN_HEIGHT_MARGIN = 0.05D;

    private static EntityPlayerSP observedPlayer;
    private static boolean wasOnGround;
    private static double observedTakeoffVelocity = VANILLA_JUMP_VELOCITY;

    private MovementCapabilities() {}

    public static synchronized void observe(EntityPlayerSP player) {
        if (player != observedPlayer) {
            observedPlayer = player;
            wasOnGround = player.onGround;
            observedTakeoffVelocity = VANILLA_JUMP_VELOCITY;
            return;
        }
        if (wasOnGround && !player.onGround && player.motionY > 0.2D) {
            // At the next client tick Minecraft has already applied
            // (motionY - 0.08) * 0.98 once. Reverse that step to recover the
            // velocity set by jump() and any LivingJumpEvent handlers.
            double takeoffVelocity = player.motionY / 0.98D + 0.08D;
            observedTakeoffVelocity = Math.max(observedTakeoffVelocity, takeoffVelocity);
        }
        wasOnGround = player.onGround;
    }

    public static synchronized void invalidateObservedJump(EntityPlayerSP player) {
        if (player == observedPlayer) {
            observedTakeoffVelocity = VANILLA_JUMP_VELOCITY;
        }
    }

    public static float stepHeight(EntityPlayerSP player) {
        return player.stepHeight;
    }

    public static int maxJumpHeight(EntityPlayerSP player) {
        double velocity = VANILLA_JUMP_VELOCITY;
        PotionEffect jump = player.getActivePotionEffect(Potion.jump);
        if (jump != null) {
            velocity += 0.1D * (jump.getAmplifier() + 1);
        }
        velocity += pistonBootsBoost(player);
        synchronized (MovementCapabilities.class) {
            if (player == observedPlayer) {
                velocity = Math.max(velocity, observedTakeoffVelocity);
            }
        }
        return maxJumpHeightForVelocity(velocity);
    }

    static int maxJumpHeightForVelocity(double velocity) {
        double height = 0;
        double motion = velocity;
        while (motion > 0 && height < 32) {
            height += motion;
            motion = (motion - 0.08D) * 0.98D;
        }
        return Math.max(1, Math.min(8, (int) Math.floor(height - MIN_HEIGHT_MARGIN)));
    }

    private static double pistonBootsBoost(EntityPlayerSP player) {
        ItemStack boots = player.inventory.armorInventory[0];
        if (boots == null || boots.getItem() == null) {
            return 0;
        }
        Object registryName = Item.itemRegistry.getNameForObject(boots.getItem());
        if (!"adventurebackpack:pistonBoots".equals(String.valueOf(registryName))) {
            return 0;
        }
        try {
            Class<?> config = Class.forName("com.darkona.adventurebackpack.config.ConfigHandler", false,
                    MovementCapabilities.class.getClassLoader());
            Field height = config.getField("pistonBootsJumpHeight");
            return height.getInt(null) / 10.0D;
        } catch (ReflectiveOperationException | LinkageError ignored) {
            // GTNH's default is three tenths, which produces a three-block jump.
            return 0.3D;
        }
    }
}
