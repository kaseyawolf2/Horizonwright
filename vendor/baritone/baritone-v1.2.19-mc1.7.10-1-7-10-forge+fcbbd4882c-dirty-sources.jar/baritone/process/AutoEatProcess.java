/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.process;

import baritone.Baritone;
import baritone.api.process.PathingCommand;
import baritone.api.process.PathingCommandType;
import baritone.utils.BaritoneProcessHelper;
import baritone.utils.InventoryItemHelper;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Automatically eat when hungry so the player doesn't starve while working. This is a temporary,
 * high-priority process: when hunger drops to {@link Baritone.settings#autoEatThreshold} it takes
 * control from whatever is running (mining, farming, ...), eats a bite, and hands control back.
 * <p>
 * 1.7.10 eating is tied to the physical use-key being held (the game keeps eating only while
 * {@code keyBindUseItem} is pressed - Minecraft.java), so we drive that key directly, exactly like
 * a player holding right-click. Eating itself is started with {@code sendUseItem} so it never
 * accidentally interacts with / opens a block (e.g. a GregTech machine) in the crosshair.
 * <p>
 * Food selection is diminishing-returns aware: when AppleCore is present (e.g. GTNH ships it with
 * The Spice of Life) each candidate is ranked by the hunger and saturation it will <i>actually</i>
 * restore for this player right now. Near a full hunger bar, foods that waste the fewest combined
 * hunger/saturation points are preferred. Once at least three full hunger icons (six points) are
 * missing, overfill no longer affects the choice and the most nourishing effective food wins.
 * Foods diminished to no actual hunger or saturation gain are never consumed. Without AppleCore
 * this degrades to the vanilla food values.
 * <p>
 * Not upstream; added for the 1.7.10 backport.
 */
public final class AutoEatProcess extends BaritoneProcessHelper {

    /** Three full hunger icons, expressed in vanilla's half-icon hunger points. */
    private static final int IGNORE_WASTE_AT_DEFICIT = 6;
    private static final float SCORE_EPSILON = 0.0001F;

    private boolean holdingUseKey;

    public AutoEatProcess(Baritone baritone) {
        super(baritone);
    }

    @Override
    public boolean isActive() {
        if (!Baritone.settings().autoEat.value) {
            setUseKey(false);
            return false;
        }
        if (ctx.player() == null || ctx.world() == null) {
            return false;
        }
        if (isEating()) {
            return true; // finish the current bite before anything else touches control
        }
        // not mid-bite: never leave the use-key stuck down (this runs every tick, even when another
        // process like defend has control), so a preempted bite can't keep the key pressed
        setUseKey(false);
        if (ctx.player().getFoodStats().getFoodLevel() > Baritone.settings().autoEatThreshold.value) {
            return false;
        }
        return bestFoodSlot() >= 0;
    }

    @Override
    public PathingCommand onTick(boolean calcFailed, boolean isSafeToCancel) {
        boolean eating = isEating();
        int slot = eating ? ctx.player().inventory.currentItem : bestFoodSlot();
        if (!eating && slot < 0) {
            setUseKey(false);
            return new PathingCommand(null, PathingCommandType.DEFER);
        }
        if (!eating) {
            // don't yank the player out of a critical movement (parkour, fall) to start a bite
            if (!isSafeToCancel) {
                setUseKey(false);
                return new PathingCommand(null, PathingCommandType.DEFER);
            }
            baritone.getInputOverrideHandler().clearAllKeys(); // stop mining/moving while we eat
            ctx.player().inventory.currentItem = slot;
            // start eating without a block right-click, so we can't open a machine GUI etc.
            ctx.minecraft().playerController.sendUseItem(ctx.player(), ctx.world(), ctx.player().inventory.getStackInSlot(slot));
        }
        setUseKey(true); // hold the use key so vanilla keeps eating until the bite finishes
        return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
    }

    /** True while the player is actively consuming a food item (as opposed to using any other item). */
    private boolean isEating() {
        ItemStack stack = ctx.player().inventory.getCurrentItem();
        return ctx.player().isUsingItem() && isSafeFood(stack) && effectiveFoodValues(stack) != null;
    }

    /**
     * Pick the safe hotbar food to eat, or -1 if there's nothing worth eating.
     * <p>
     * AppleCore supplies the player-specific hunger and saturation values, including Spice of Life
     * diminishing returns. When fewer than three full hunger icons are missing, choose the food with the
     * least combined hunger/saturation overfill, then the greatest actual gain. At or above that deficit,
     * overfill is deliberately ignored and the food with the greatest effective nourishment is preferred.
     */
    private int bestFoodSlot() {
        int currentHunger = ctx.player().getFoodStats().getFoodLevel();
        float currentSaturation = ctx.player().getFoodStats().getSaturationLevel();
        boolean minimizeWaste = 20 - currentHunger < IGNORE_WASTE_AT_DEFICIT;
        int bestSlot = -1;
        FoodScore bestScore = null;
        for (int i = 0; i < 36; i++) {
            ItemStack stack = ctx.player().inventory.getStackInSlot(i);
            if (!isSafeFood(stack)) {
                continue;
            }
            FoodValues values = effectiveFoodValues(stack);
            if (values == null) {
                continue;
            }
            FoodScore score = FoodScore.forPlayer(values, currentHunger, currentSaturation);
            if (!score.providesAnything()) {
                continue; // Spice of Life diminished it to no usable hunger or saturation
            }
            if (bestScore == null || score.isBetterThan(bestScore, minimizeWaste)) {
                bestScore = score;
                bestSlot = i;
            }
        }
        if (bestSlot >= 9) {
            // Food withdrawn from a backpack (or already in the main inventory) must be made
            // usable before vanilla can eat it. InventoryBehavior performs the server-safe swap.
            baritone.getInventoryBehavior().attemptToPutOnHotbar(bestSlot, slot -> false);
            return -1;
        }
        return bestSlot;
    }

    /**
     * Effective food values for the current player. AppleCore includes Spice of Life's diminishing returns;
     * vanilla values are used when AppleCore is absent or cannot describe an ItemFood.
     */
    private FoodValues effectiveFoodValues(ItemStack stack) {
        FoodValues modified = appleCoreFoodValues(stack);
        if (modified != null) {
            return modified;
        }
        if (!(stack.getItem() instanceof ItemFood)) {
            return null;
        }
        ItemFood food = (ItemFood) stack.getItem();
        return new FoodValues(food.func_150905_g(stack), food.func_150906_h(stack));
    }

    // AppleCore (squeek.applecore.api.food.FoodValues) reflection - the backport doesn't compile against
    // the mod, so we resolve it once at runtime and gracefully do nothing when it's absent.
    private static boolean appleCoreChecked;
    private static Method appleCoreGetFoodValues; // FoodValues.get(ItemStack, EntityPlayer) -> FoodValues
    private static Field appleCoreHungerField;    // FoodValues.hunger (int)
    private static Field appleCoreSaturationModifierField; // FoodValues.saturationModifier (float)

    /** Player-modified values via AppleCore, or null if AppleCore isn't present / the lookup fails. */
    private FoodValues appleCoreFoodValues(ItemStack stack) {
        if (!appleCoreChecked) {
            appleCoreChecked = true;
            try {
                Class<?> foodValues = Class.forName("squeek.applecore.api.food.FoodValues");
                appleCoreGetFoodValues = foodValues.getMethod("get", ItemStack.class, EntityPlayer.class);
                appleCoreHungerField = foodValues.getField("hunger");
                appleCoreSaturationModifierField = foodValues.getField("saturationModifier");
            } catch (Throwable t) {
                appleCoreGetFoodValues = null;
                appleCoreHungerField = null;
                appleCoreSaturationModifierField = null;
            }
        }
        if (appleCoreGetFoodValues == null) {
            return null;
        }
        try {
            Object values = appleCoreGetFoodValues.invoke(null, stack, ctx.player());
            if (values == null) {
                return null;
            }
            return new FoodValues(
                    appleCoreHungerField.getInt(values),
                    appleCoreSaturationModifierField.getFloat(values)
            );
        } catch (Throwable t) {
            return null;
        }
    }

    private static boolean isSafeFood(ItemStack stack) {
        return InventoryItemHelper.isSafeFood(stack);
    }

    /** Hunger and saturation values in the same units used by FoodStats and AppleCore. */
    private static final class FoodValues {
        private final int hunger;
        private final float saturation;

        private FoodValues(int hunger, float saturationModifier) {
            this.hunger = Math.max(0, hunger);
            this.saturation = Math.min(
                    20.0F,
                    this.hunger * Math.max(0.0F, saturationModifier) * 2.0F
            );
        }
    }

    /** The useful and wasted portions of eating one candidate at the player's current food state. */
    private static final class FoodScore {
        private final float usefulHunger;
        private final float usefulSaturation;
        private final float wasted;
        private final float nourishment;

        private FoodScore(float usefulHunger, float usefulSaturation, float wasted, float nourishment) {
            this.usefulHunger = usefulHunger;
            this.usefulSaturation = usefulSaturation;
            this.wasted = wasted;
            this.nourishment = nourishment;
        }

        private static FoodScore forPlayer(FoodValues values, int currentHunger, float currentSaturation) {
            float hunger = Math.max(0, values.hunger);
            float usefulHunger = Math.min(hunger, Math.max(0, 20 - currentHunger));
            float resultingHunger = Math.min(20, currentHunger + usefulHunger);
            float saturationCapacity = Math.max(0.0F, resultingHunger - currentSaturation);
            float usefulSaturation = Math.min(values.saturation, saturationCapacity);
            float wasted = hunger - usefulHunger + values.saturation - usefulSaturation;
            return new FoodScore(usefulHunger, usefulSaturation, wasted, hunger + values.saturation);
        }

        private boolean providesAnything() {
            return usefulHunger > SCORE_EPSILON || usefulSaturation > SCORE_EPSILON;
        }

        private boolean isBetterThan(FoodScore other, boolean minimizeWaste) {
            if (minimizeWaste && Math.abs(wasted - other.wasted) > SCORE_EPSILON) {
                return wasted < other.wasted;
            }
            float useful = usefulHunger + usefulSaturation;
            float otherUseful = other.usefulHunger + other.usefulSaturation;
            if (minimizeWaste && Math.abs(useful - otherUseful) > SCORE_EPSILON) {
                return useful > otherUseful;
            }
            if (Math.abs(nourishment - other.nourishment) > SCORE_EPSILON) {
                return nourishment > other.nourishment;
            }
            return usefulHunger > other.usefulHunger;
        }
    }

    private void setUseKey(boolean pressed) {
        if (pressed == holdingUseKey || ctx.minecraft() == null || ctx.minecraft().gameSettings == null) {
            return;
        }
        KeyBinding useItem = ctx.minecraft().gameSettings.keyBindUseItem;
        KeyBinding.setKeyBindState(useItem.getKeyCode(), pressed);
        holdingUseKey = pressed;
    }

    @Override
    public void onLostControl() {
        setUseKey(false);
    }

    @Override
    public boolean isTemporary() {
        return true;
    }

    @Override
    public double priority() {
        // above mining/farming so we interrupt them to eat, but below defend (6.0): fight first, then eat
        return 5.5;
    }

    @Override
    public String displayName0() {
        return "Auto eat";
    }
}
