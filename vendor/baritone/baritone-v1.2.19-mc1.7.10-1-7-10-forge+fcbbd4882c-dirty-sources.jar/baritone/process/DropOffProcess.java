/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.process;

import baritone.Baritone;
import baritone.api.cache.IWaypoint;
import baritone.api.cache.IWaypointCollection;
import baritone.api.cache.Waypoint;
import baritone.api.pathing.goals.GoalGetToBlock;
import baritone.api.process.PathingCommand;
import baritone.api.process.PathingCommandType;
import baritone.api.utils.BetterBlockPos;
import baritone.api.utils.Rotation;
import baritone.api.utils.RotationUtils;
import baritone.api.utils.input.Input;
import baritone.compat.BlockPos;
import baritone.compat.Blocks;
import baritone.utils.BaritoneProcessHelper;
import baritone.utils.BlockStateInterface;
import baritone.utils.InventoryItemHelper;
import net.minecraft.block.Block;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

/**
 * Temporarily interrupts mining, circle digging, or farming to unload a full standard inventory.
 * The hotbar is intentionally excluded both from the fullness trigger and from chest transfers.
 */
public final class DropOffProcess extends BaritoneProcessHelper {

    private static final int STANDARD_INVENTORY_START = 9;
    private static final int STANDARD_INVENTORY_END = 36;
    private static final int OPEN_TIMEOUT_TICKS = 60;
    private static final int CONTAINER_INIT_GRACE_TICKS = 20;
    private static final int MAX_PATH_FAILURES = 5;
    private static final int FAILURE_RETRY_TICKS = 600;
    private static final int PORTABLE_WORK_HOTBAR_SLOT = 6;

    private enum PortablePhase { NONE, OPENING, RESTORING }

    private boolean droppingOff;
    private boolean unloadStarted;
    private boolean travelCommitted;
    private BetterBlockPos target;
    private int openTicks;
    private int transferDelay;
    private int retryCooldown;
    private int containerInitTicks;
    private int pathFailures;
    private final boolean[] rejectedSlots = new boolean[STANDARD_INVENTORY_END];
    private final boolean[] drainedPortableSlots = new boolean[STANDARD_INVENTORY_END];
    private final Set<Integer> attemptedPortableSlots = new HashSet<>();
    private PortablePhase portablePhase = PortablePhase.NONE;
    private int portableInventorySlot = -1;
    private int previousSelectedSlot = -1;
    private boolean portableMovedToHotbar;
    private boolean portableCompletelyDrained;
    private boolean portableOpenRequested;

    public DropOffProcess(Baritone baritone) {
        super(baritone);
    }

    /**
     * Portable storage gets the first chance to make room. Once physical drop-off actually gains
     * control, it owns bags through both the journey and unloading to prevent retries and loops.
     */
    public boolean ownsPortableStorage() {
        return droppingOff && (travelCommitted || unloadStarted || portablePhase != PortablePhase.NONE);
    }

    public void setDesignation(BetterBlockPos chest) {
        IWaypointCollection waypoints = waypoints();
        for (IWaypoint existing : new ArrayList<>(waypoints.getByTag(IWaypoint.Tag.DROP_OFF))) {
            waypoints.removeWaypoint(existing);
        }
        waypoints.addWaypoint(new Waypoint("dropoff", IWaypoint.Tag.DROP_OFF, chest));
        stopRun();
    }

    public boolean clearDesignation() {
        IWaypointCollection waypoints = waypoints();
        ArrayList<IWaypoint> existing = new ArrayList<>(waypoints.getByTag(IWaypoint.Tag.DROP_OFF));
        for (IWaypoint waypoint : existing) {
            waypoints.removeWaypoint(waypoint);
        }
        stopRun();
        return !existing.isEmpty();
    }

    public BetterBlockPos getDesignation() {
        if (baritone.getWorldProvider().getCurrentWorld() == null) {
            return null;
        }
        IWaypoint waypoint = waypoints().getMostRecentByTag(IWaypoint.Tag.DROP_OFF);
        return waypoint == null ? null : waypoint.getLocation();
    }

    public boolean isStorageAt(BlockPos pos) {
        if (ctx.world() == null || pos == null) {
            return false;
        }
        Block block = BlockStateInterface.get(ctx, pos).getBlock();
        if (block == Blocks.CHEST || block == Blocks.TRAPPED_CHEST || block == Blocks.ENDER_CHEST) {
            return true;
        }
        TileEntity tileEntity = ctx.world().getTileEntity(pos.getX(), pos.getY(), pos.getZ());
        return tileEntity instanceof IInventory;
    }

    @Override
    public boolean isActive() {
        if (ctx.player() == null || ctx.world() == null) {
            return false;
        }
        if (droppingOff) {
            return true;
        }
        if (retryCooldown > 0) {
            retryCooldown--;
            return false;
        }
        if (!gatheringProcessActive() || !standardInventorySaturated()) {
            return false;
        }
        // Never take over while the user has some unrelated container or GUI open.
        if (ctx.player().openContainer != ctx.player().inventoryContainer) {
            return false;
        }
        BetterBlockPos designated = getDesignation();
        if (designated == null) {
            return false;
        }
        target = designated;
        droppingOff = true;
        unloadStarted = false;
        travelCommitted = false;
        openTicks = 0;
        transferDelay = 0;
        containerInitTicks = 0;
        pathFailures = 0;
        clearRejectedSlots();
        clearPortableState();
        logDirect(String.format("Standard inventory full; unloading at %d, %d, %d", target.x, target.y, target.z));
        return true;
    }

    @Override
    public PathingCommand onTick(boolean calcFailed, boolean isSafeToCancel) {
        baritone.getInputOverrideHandler().clearAllKeys();

        if (target == null) {
            return fail("Drop-off storage is missing or no longer accessible");
        }
        if (portablePhase != PortablePhase.NONE) {
            return tickPortableStorage(isSafeToCancel);
        }
        if (!unloadStarted
                && ctx.player().openContainer == ctx.player().inventoryContainer
                && !standardInventorySaturated()) {
            // A higher-priority backpack run made room before we committed to travelling/unloading.
            droppingOff = false;
            target = null;
            retryCooldown = 20;
            return new PathingCommand(null, PathingCommandType.CANCEL_AND_SET_GOAL);
        }
        // Reaching this point means every higher-priority portable-storage attempt has finished
        // without creating a free slot. Own the bags for the entire journey so their retry
        // cooldown cannot expire and reopen them at random on the walk to the chest.
        travelCommitted = true;
        GoalGetToBlock goal = new GoalGetToBlock(target);
        if (calcFailed) {
            if (++pathFailures >= MAX_PATH_FAILURES) {
                return fail("Unable to path to the drop-off chest after repeated attempts");
            }
            logDebug(String.format("Drop-off path calculation failed (%d/%d); retrying", pathFailures, MAX_PATH_FAILURES));
            return new PathingCommand(goal, PathingCommandType.REVALIDATE_GOAL_AND_PATH);
        }
        if (baritone.getPathingBehavior().isPathing()) {
            // A successful retry breaks the failure streak. Failures from unrelated
            // plan-ahead calculations must not accumulate across the entire journey.
            pathFailures = 0;
        }
        if (ctx.player().openContainer != ctx.player().inventoryContainer) {
            Container open = ctx.player().openContainer;
            if (!isStorageContainer(open)) {
                // Several modded GUIs create their container before all slot-registration
                // packets arrive. Give them a moment instead of declaring the storage invalid.
                if (++containerInitTicks <= CONTAINER_INIT_GRACE_TICKS) {
                    return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
                }
                return fail("The opened storage does not expose transferable player and storage slots");
            }
            unloadStarted = true;
            containerInitTicks = 0;
            pathFailures = 0;
            return transferStandardInventory(open);
        }
        containerInitTicks = 0;

        if (!goal.isInGoal(ctx.playerFeet()) || !isSafeToCancel) {
            return new PathingCommand(goal, PathingCommandType.REVALIDATE_GOAL_AND_PATH);
        }
        pathFailures = 0;

        Optional<Rotation> rotation = RotationUtils.reachable(
                ctx,
                target,
                ctx.playerController().getBlockReachDistance()
        );
        if (rotation.isPresent()) {
            baritone.getLookBehavior().updateTarget(rotation.get(), true);
            if (ctx.isLookingAt(target)) {
                baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_RIGHT, true);
            }
        }
        if (++openTicks > OPEN_TIMEOUT_TICKS) {
            return fail("Reached the drop-off coordinates, but the storage is missing or would not open");
        }
        return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
    }

    private PathingCommand transferStandardInventory(Container container) {
        int delay = Math.max(1, Baritone.settings().ticksBetweenInventoryMoves.value);
        if (++transferDelay < delay) {
            return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
        }
        transferDelay = 0;

        ItemStack[] inventory = ctx.player().inventory.mainInventory;
        boolean hasStandardInventoryItems = false;
        for (int inventorySlot = STANDARD_INVENTORY_START; inventorySlot < STANDARD_INVENTORY_END; inventorySlot++) {
            ItemStack stack = inventory[inventorySlot];
            if (stack == null || InventoryItemHelper.isPortableStorage(stack)) {
                continue;
            }
            hasStandardInventoryItems = true;
            if (rejectedSlots[inventorySlot] || !canAccept(container, stack)) {
                continue;
            }
            Slot playerSlot = findPlayerSlot(container, inventorySlot);
            if (playerSlot == null) {
                rejectedSlots[inventorySlot] = true;
                continue;
            }
            int beforeSize = stack.stackSize;
            ctx.playerController().windowClick(container.windowId, playerSlot.slotNumber, 0, 1, ctx.player());
            ItemStack remaining = inventory[inventorySlot];
            if (remaining != null && remaining.stackSize == beforeSize && remaining.isItemEqual(stack)
                    && ItemStack.areItemStackTagsEqual(remaining, stack)) {
                // The custom container rejected the shift-click despite advertising a compatible slot.
                rejectedSlots[inventorySlot] = true;
            }
            return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
        }

        if (hasStandardInventoryItems) {
            return fail("Drop-off storage is full or rejects the remaining items; leaving them and the hotbar untouched");
        }

        int portable = findUndrainedPortableStorage();
        if (portable >= 0) {
            beginPortableDrain(portable);
            return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
        }
        closeStorage();
        logDirect("Drop-off complete; resuming the interrupted task");
        droppingOff = false;
        unloadStarted = false;
        travelCommitted = false;
        target = null;
        retryCooldown = 20;
        return new PathingCommand(null, PathingCommandType.CANCEL_AND_SET_GOAL);
    }

    private void beginPortableDrain(int inventorySlot) {
        closeStorage();
        portablePhase = PortablePhase.OPENING;
        portableInventorySlot = inventorySlot;
        previousSelectedSlot = ctx.player().inventory.currentItem;
        portableMovedToHotbar = inventorySlot >= 9;
        portableCompletelyDrained = false;
        portableOpenRequested = false;
        attemptedPortableSlots.clear();
        openTicks = 0;
        transferDelay = 0;
    }

    private PathingCommand tickPortableStorage(boolean isSafeToCancel) {
        baritone.getInputOverrideHandler().clearAllKeys();
        if (portablePhase == PortablePhase.RESTORING) {
            return restorePortableStorage();
        }

        if (ctx.player().openContainer != ctx.player().inventoryContainer) {
            Container open = ctx.player().openContainer;
            if (!isStorageContainer(open)) {
                if (++containerInitTicks <= CONTAINER_INIT_GRACE_TICKS) {
                    return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
                }
                return fail("Portable storage does not expose transferable slots");
            }
            containerInitTicks = 0;
            return drainPortableStorage(open);
        }
        if (!isSafeToCancel) {
            return new PathingCommand(null, PathingCommandType.DEFER);
        }

        int heldSlot = portableInventorySlot;
        if (portableMovedToHotbar) {
            heldSlot = PORTABLE_WORK_HOTBAR_SLOT;
            if (!InventoryItemHelper.isPortableStorage(ctx.player().inventory.getStackInSlot(heldSlot))) {
                if (!baritone.getInventoryBehavior().swapWithHotbar(portableInventorySlot, heldSlot)) {
                    return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
                }
                return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
            }
        }
        ItemStack portable = ctx.player().inventory.getStackInSlot(heldSlot);
        if (!InventoryItemHelper.isPortableStorage(portable)) {
            return fail("Portable storage item disappeared while unloading it");
        }
        ctx.player().inventory.currentItem = heldSlot;
        if (!portableOpenRequested) {
            portableOpenRequested = true;
            ctx.minecraft().playerController.sendUseItem(ctx.player(), ctx.world(), portable);
        }
        if (++openTicks > OPEN_TIMEOUT_TICKS) {
            return fail("Portable storage would not open for drop-off");
        }
        return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
    }

    private PathingCommand drainPortableStorage(Container container) {
        int delay = Math.max(1, Baritone.settings().ticksBetweenInventoryMoves.value);
        if (++transferDelay < delay) {
            return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
        }
        transferDelay = 0;

        for (Object object : container.inventorySlots) {
            Slot slot = (Slot) object;
            if (slot.inventory == ctx.player().inventory || attemptedPortableSlots.contains(slot.slotNumber)) {
                continue;
            }
            ItemStack stack = slot.getStack();
            if (stack == null) {
                continue;
            }
            if (!canFitInStandardInventory(stack)) {
                portableCompletelyDrained = false;
                return startPortableRestore();
            }
            attemptedPortableSlots.add(slot.slotNumber);
            ctx.playerController().windowClick(container.windowId, slot.slotNumber, 0, 1, ctx.player());
            return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
        }

        // Empty, or every remaining custom slot rejected shift-click. Mark it handled for this run
        // so one unusual bag cannot trap drop-off in an endless open/close loop.
        portableCompletelyDrained = true;
        return startPortableRestore();
    }

    private PathingCommand startPortableRestore() {
        closeStorage();
        portablePhase = PortablePhase.RESTORING;
        return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
    }

    private PathingCommand restorePortableStorage() {
        if (ctx.player().openContainer != ctx.player().inventoryContainer) {
            closeStorage();
            return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
        }
        if (portableMovedToHotbar
                && InventoryItemHelper.isPortableStorage(ctx.player().inventory.getStackInSlot(PORTABLE_WORK_HOTBAR_SLOT))) {
            if (!baritone.getInventoryBehavior().swapWithHotbar(portableInventorySlot, PORTABLE_WORK_HOTBAR_SLOT)) {
                return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
            }
            return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
        }
        if (previousSelectedSlot >= 0 && previousSelectedSlot < 9) {
            ctx.player().inventory.currentItem = previousSelectedSlot;
        }
        if (portableCompletelyDrained && portableInventorySlot >= 0) {
            drainedPortableSlots[portableInventorySlot] = true;
        }
        portablePhase = PortablePhase.NONE;
        portableInventorySlot = -1;
        previousSelectedSlot = -1;
        portableMovedToHotbar = false;
        portableOpenRequested = false;
        attemptedPortableSlots.clear();
        clearRejectedSlots();
        openTicks = 0;
        transferDelay = 0;
        return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
    }

    private int findUndrainedPortableStorage() {
        for (int slot = 0; slot < STANDARD_INVENTORY_END; slot++) {
            ItemStack stack = ctx.player().inventory.getStackInSlot(slot);
            if (!drainedPortableSlots[slot]
                    && InventoryItemHelper.isPortableStorage(stack)
                    && !InventoryItemHelper.isRemoteStorageTerminal(stack)) {
                return slot;
            }
        }
        return -1;
    }

    private boolean canFitInStandardInventory(ItemStack incoming) {
        int remaining = incoming.stackSize;
        for (int slot = STANDARD_INVENTORY_START; slot < STANDARD_INVENTORY_END; slot++) {
            ItemStack stored = ctx.player().inventory.getStackInSlot(slot);
            if (stored == null) {
                remaining -= incoming.getMaxStackSize();
                if (remaining <= 0) {
                    return true;
                }
                continue;
            }
            if (stored.isItemEqual(incoming) && ItemStack.areItemStackTagsEqual(stored, incoming)
                    && stored.stackSize < stored.getMaxStackSize()) {
                remaining -= stored.getMaxStackSize() - stored.stackSize;
                if (remaining <= 0) {
                    return true;
                }
            }
        }
        return remaining <= 0;
    }

    private boolean canAccept(Container container, ItemStack incoming) {
        for (Object object : container.inventorySlots) {
            Slot slot = (Slot) object;
            if (slot.inventory == ctx.player().inventory || !slot.isItemValid(incoming)) {
                continue;
            }
            ItemStack stored = slot.getStack();
            if (stored == null) {
                return true;
            }
            int limit = Math.min(stored.getMaxStackSize(), slot.getSlotStackLimit());
            if (stored.isItemEqual(incoming)
                    && ItemStack.areItemStackTagsEqual(stored, incoming)
                    && stored.stackSize < limit) {
                return true;
            }
        }
        return false;
    }

    private boolean isStorageContainer(Container container) {
        boolean hasStandardPlayerSlot = false;
        boolean hasStorageSlot = false;
        for (Object object : container.inventorySlots) {
            Slot slot = (Slot) object;
            if (slot.inventory == ctx.player().inventory) {
                int index = slot.getSlotIndex();
                hasStandardPlayerSlot |= index >= STANDARD_INVENTORY_START && index < STANDARD_INVENTORY_END;
            } else {
                hasStorageSlot = true;
            }
        }
        return hasStandardPlayerSlot && hasStorageSlot;
    }

    private Slot findPlayerSlot(Container container, int inventorySlot) {
        for (Object object : container.inventorySlots) {
            Slot slot = (Slot) object;
            if (slot.inventory == ctx.player().inventory && slot.getSlotIndex() == inventorySlot) {
                return slot;
            }
        }
        return null;
    }

    private boolean gatheringProcessActive() {
        return baritone.getMineProcess().isActive()
                || baritone.getCircleProcess().isActive()
                || baritone.getFarmProcess().isActive();
    }

    /** Require an empty slot; partial stacks cannot accept a different kind of mined drop. */
    private boolean standardInventorySaturated() {
        ItemStack[] inventory = ctx.player().inventory.mainInventory;
        for (int slot = STANDARD_INVENTORY_START; slot < STANDARD_INVENTORY_END; slot++) {
            if (inventory[slot] == null) {
                return false;
            }
        }
        return true;
    }

    private IWaypointCollection waypoints() {
        return baritone.getWorldProvider().getCurrentWorld().getWaypoints();
    }

    private PathingCommand fail(String message) {
        closeStorage();
        logDirect(message + "; retrying in 30 seconds");
        droppingOff = false;
        unloadStarted = false;
        travelCommitted = false;
        target = null;
        retryCooldown = FAILURE_RETRY_TICKS;
        return new PathingCommand(null, PathingCommandType.CANCEL_AND_SET_GOAL);
    }

    private void closeStorage() {
        if (ctx.player() != null && ctx.player().openContainer != ctx.player().inventoryContainer) {
            ctx.player().closeScreen();
        }
    }

    private void clearRejectedSlots() {
        for (int slot = STANDARD_INVENTORY_START; slot < STANDARD_INVENTORY_END; slot++) {
            rejectedSlots[slot] = false;
        }
    }

    private void clearPortableState() {
        portablePhase = PortablePhase.NONE;
        portableInventorySlot = -1;
        previousSelectedSlot = -1;
        portableMovedToHotbar = false;
        portableCompletelyDrained = false;
        portableOpenRequested = false;
        attemptedPortableSlots.clear();
        for (int slot = 0; slot < drainedPortableSlots.length; slot++) {
            drainedPortableSlots[slot] = false;
        }
    }

    private void stopRun() {
        closeStorage();
        droppingOff = false;
        unloadStarted = false;
        travelCommitted = false;
        target = null;
        openTicks = 0;
        transferDelay = 0;
        containerInitTicks = 0;
        pathFailures = 0;
        retryCooldown = 0;
        clearRejectedSlots();
        clearPortableState();
        baritone.getInputOverrideHandler().clearAllKeys();
    }

    @Override
    public void onLostControl() {
        stopRun();
    }

    @Override
    public boolean isTemporary() {
        return true;
    }

    @Override
    public double priority() {
        // Below auto-eat (5.5) and auto-defend (6.0), above normal gathering processes.
        return 5.0;
    }

    @Override
    public String displayName0() {
        return target == null
                ? "Drop off"
                : String.format("Dropping off at %d, %d, %d", target.x, target.y, target.z);
    }
}
