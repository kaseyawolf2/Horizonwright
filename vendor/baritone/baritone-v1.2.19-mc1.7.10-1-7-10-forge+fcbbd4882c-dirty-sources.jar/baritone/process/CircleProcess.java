/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.process;

import baritone.Baritone;
import baritone.api.pathing.goals.Goal;
import baritone.api.pathing.goals.GoalComposite;
import baritone.api.pathing.goals.GoalTwoBlocks;
import baritone.api.pathing.goals.GoalXZ;
import baritone.api.process.PathingCommand;
import baritone.api.process.PathingCommandType;
import baritone.api.utils.BetterBlockPos;
import baritone.api.utils.RayTraceUtils;
import baritone.api.utils.Rotation;
import baritone.api.utils.RotationUtils;
import baritone.api.utils.input.Input;
import baritone.compat.BlockPos;
import baritone.compat.Blocks;
import baritone.compat.ChunkPos;
import baritone.compat.EnumFacing;
import baritone.compat.IBlockState;
import baritone.compat.RayTraceResult;
import baritone.compat.Vec3d;
import baritone.pathing.movement.CalculationContext;
import baritone.pathing.movement.MovementHelper;
import baritone.utils.BaritoneProcessHelper;
import baritone.utils.BlockStateInterface;
import baritone.utils.PathingCommandContext;
import baritone.utils.ProtectedAreaHelper;
import baritone.utils.TinkersAoeToolCompat;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockLiquid;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import static baritone.api.pathing.movement.ActionCosts.COST_INF;

/**
 * Digs a cylindrical shaft (WorldEdit-style disc footprint) from a top Y level down to bedrock,
 * one full Y-layer at a time, top to bottom.
 * <p>
 * Custom to this backport (not upstream); the command-facing behaviour matches the old #circle,
 * but the mechanism is a mining process rather than a {@link BuilderProcess} schematic build.
 * <p>
 * The builder approach didn't scale to large radii: it marks every out-of-render-distance block in
 * the cylinder as "incorrect", hits the {@code incorrectSize} cap with blocks on the far edge of the
 * disc, and then walks off toward a corner it can't path to (appearing to "go to a random location"
 * and hang). This process instead reads the current layer through {@link BlockStateInterface}, which
 * transparently serves both loaded chunks and Baritone's persistent chunk cache — so it can see the
 * solid blocks at the active Y across the whole explored disc, not just what's in render distance
 * right now. It always mines the nearest ones first, refuses (via a custom {@link CalculationContext})
 * to dig below the active layer, walks toward any never-seen columns to reveal them, and only drops
 * to the next layer once the current one is fully cleared.
 */
public final class CircleProcess extends BaritoneProcessHelper {

    /** How many break targets to hand the pathfinder at once. */
    private static final int TARGET_COUNT = 64;
    /** Rescan the current layer this often (ticks). */
    private static final int RESCAN_INTERVAL = 5;
    /** Only fast-break a target if it's within this many of the nearest (keeps the loop cheap). */
    private static final int FAST_BREAK_SCAN = 16;
    /** TConstruct's AOEHarvestTool uses this fixed reach for its internal direction ray trace. */
    private static final double TINKERS_AOE_REACH = 4.5;

    private boolean active;
    private int centerX;
    private int centerZ;
    private int radius;
    private int radiusSq;
    private int topY;

    /** The Y layer currently being cleared; digging proceeds from {@link #topY} down to 1. */
    private volatile int currentLayerY;
    private int tickCount;

    // written by the rescan (main thread on descend, executor otherwise), read on the main thread
    private volatile List<BlockPos> knownTargets = Collections.emptyList();
    private volatile BlockPos loadGoal; // nearest not-yet-loaded disc chunk to go reveal, or null
    private volatile boolean scannedThisLayer;
    private volatile boolean rescanInFlight;

    private final List<BlockPos> blacklist = new ArrayList<>();      // unreachable break targets
    private final LongOpenHashSet unreachableChunks = new LongOpenHashSet(); // unreachable load goals
    private BlockPos priorityTarget;
    private BlockPos priorityReference;
    private double spiralAngle;
    private String activePriorityMode;

    public CircleProcess(Baritone baritone) {
        super(baritone);
    }

    /**
     * Begin digging the cylinder.
     *
     * @param centerX disc centre X (block)
     * @param centerZ disc centre Z (block)
     * @param radius  disc radius in blocks (diameter = 2*radius+1)
     * @param topY    top Y level to start digging from (inclusive), digging down to bedrock
     */
    public void dig(int centerX, int centerZ, int radius, int topY) {
        onLostControl();
        this.centerX = centerX;
        this.centerZ = centerZ;
        this.radius = radius;
        // WorldEdit disc: dx^2 + dz^2 <= (r + 0.5)^2, i.e. r^2 + r (integer form).
        this.radiusSq = radius * radius + radius;
        this.topY = topY;
        this.currentLayerY = topY;
        this.tickCount = 0;
        this.knownTargets = Collections.emptyList();
        this.loadGoal = null;
        this.scannedThisLayer = false;
        this.blacklist.clear();
        this.unreachableChunks.clear();
        this.priorityTarget = null;
        this.priorityReference = ctx.playerFeet();
        this.spiralAngle = Math.toRadians((ctx.player().rotationYaw + 90.0F) % 360.0F);
        if (this.spiralAngle < 0) {
            this.spiralAngle += Math.PI * 2;
        }
        this.activePriorityMode = null;
        this.active = true;
        rescan(new CalculationContext(baritone), topY);
    }

    @Override
    public boolean isActive() {
        return active;
    }

    @Override
    public PathingCommand onTick(boolean calcFailed, boolean isSafeToCancel) {
        baritone.getInputOverrideHandler().clearAllKeys();

        if (calcFailed) {
            List<BlockPos> targets = knownTargets;
            if (!targets.isEmpty()) {
                // Ranked modes publish a single committed target; closest mode publishes a
                // group and lets path cost decide. In either case blacklist the failed target.
                BlockPos failed = targets.stream()
                        .min(Comparator.comparingDouble(pos -> ctx.player().getDistanceSq(pos.getX(), pos.getY(), pos.getZ())))
                        .orElse(null);
                if (failed != null) {
                    blacklist.add(failed);
                    if (failed.equals(priorityTarget)) {
                        completePriorityTarget(failed, normalizedPriority());
                    }
                }
            } else if (loadGoal != null) {
                // couldn't walk to an unloaded part of the disc; give up on that chunk
                unreachableChunks.add(ChunkPos.asLong(loadGoal.getX() >> 4, loadGoal.getZ() >> 4));
                loadGoal = null;
            }
        }

        if (tickCount++ % RESCAN_INTERVAL == 0) {
            scheduleRescan();
        }

        if (!scannedThisLayer) {
            // first scan of this layer hasn't landed yet — idle without giving up control
            return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
        }

        List<BlockPos> targets = knownTargets;

        if (!targets.isEmpty()) {
            // Fast path: break the nearest reachable target directly, rather than making the
            // pathfinder reposition (this is what makes clearing an open layer quick).
            if (isSafeToCancel && ctx.player().onGround) {
                for (int i = 0; i < targets.size() && i < FAST_BREAK_SCAN; i++) {
                    BlockPos pos = targets.get(i);
                    IBlockState state = baritone.bsi.get0(pos);
                    if (state.getBlock() instanceof BlockAir
                            || MovementHelper.avoidBreaking(baritone.bsi, pos.getX(), pos.getY(), pos.getZ(), state)) {
                        continue;
                    }
                    MovementHelper.switchToBestToolFor(ctx, state, pos);
                    ItemStack held = ctx.player().getCurrentEquippedItem();

                    if (TinkersAoeToolCompat.isUsableDirectional3x3Tool(held)) {
                        Optional<Rotation> horizontal = directionalAoeFootprintFits(pos)
                                ? reachableDirectionalAoeLayerFace(pos)
                                : Optional.empty();
                        if (horizontal.isPresent()) {
                            baritone.getLookBehavior().updateTarget(horizontal.get(), true);
                            RayTraceResult trace = ctx.objectMouseOver();
                            if (!ctx.player().isSneaking()
                                    && trace != null
                                    && trace.typeOfHit == RayTraceResult.Type.BLOCK
                                    && pos.equals(trace.getBlockPos())
                                    && trace.sideHit.getAxis() == EnumFacing.Axis.Y) {
                                baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_LEFT, true);
                            }
                            return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
                        }

                        // A side hit would remove blocks from y-1 and y+1, while an edge hit can
                        // remove blocks outside the circular footprint. Prefer another tool. If
                        // AutoTool is disabled (or no alternative exists), wait until sneaking is
                        // active before clicking so TConstruct suppresses the tool's AOE itself.
                        MovementHelper.switchToBestToolForWithoutTinkersAoe(ctx, state, pos);
                        held = ctx.player().getCurrentEquippedItem();
                        if (TinkersAoeToolCompat.isUsableDirectional3x3Tool(held)) {
                            Optional<Rotation> singleBlock = RotationUtils.reachable(
                                    ctx, pos, ctx.playerController().getBlockReachDistance(), true);
                            if (singleBlock.isPresent()) {
                                baritone.getInputOverrideHandler().setInputForceState(Input.SNEAK, true);
                                baritone.getLookBehavior().updateTarget(singleBlock.get(), true);
                                if (ctx.player().isSneaking() && ctx.isLookingAt(pos)) {
                                    baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_LEFT, true);
                                }
                                return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
                            }
                            continue;
                        }
                    }

                    Optional<Rotation> rot = RotationUtils.reachable(ctx, pos);
                    if (rot.isPresent()) {
                        baritone.getLookBehavior().updateTarget(rot.get(), true);
                        if (ctx.isLookingAt(pos) || ctx.playerRotations().isReallyCloseTo(rot.get())) {
                            baritone.getInputOverrideHandler().setInputForceState(Input.CLICK_LEFT, true);
                        }
                        return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
                    }
                }
            }
            Goal goal = new GoalComposite(targets.stream().map(GoalTwoBlocks::new).toArray(Goal[]::new));
            // restrict the pathfinder so it never digs below the layer it's currently clearing
            return new PathingCommandContext(goal, PathingCommandType.REVALIDATE_GOAL_AND_PATH, new LayerCalculationContext(currentLayerY));
        }

        // No diggable blocks known (loaded or cached) on this layer.
        BlockPos toLoad = loadGoal;
        if (toLoad != null) {
            // part of this layer has never been seen — go reveal it before descending
            return new PathingCommandContext(new GoalXZ(toLoad.getX(), toLoad.getZ()), PathingCommandType.SET_GOAL_AND_PATH, new LayerCalculationContext(currentLayerY));
        }

        // This whole layer is known and clear — drop to the next one.
        int finishedLayer = currentLayerY;
        currentLayerY--;
        if (currentLayerY < 1) {
            logDirect("Circle dig complete — cleared down to bedrock.");
            if (Baritone.settings().notificationOnBuildFinished.value) {
                logNotification("Circle dig complete", false);
            }
            onLostControl();
            return new PathingCommand(null, PathingCommandType.CANCEL_AND_SET_GOAL);
        }
        logDirect("Layer y=" + finishedLayer + " complete, descending to y=" + currentLayerY);
        scannedThisLayer = false;
        knownTargets = Collections.emptyList();
        loadGoal = null;
        // kick off a scan of the new layer immediately (bypasses the tick throttle)
        scheduleRescan();
        return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
    }

    /** The horizontal Hammer/Excavator plane must remain inside the layer, disc, and protection policy. */
    private boolean directionalAoeFootprintFits(BlockPos center) {
        for (BlockPos pos : TinkersAoeToolCompat.affectedBlocks(center, EnumFacing.UP)) {
            int dx = pos.getX() - centerX;
            int dz = pos.getZ() - centerZ;
            if (dx * dx + dz * dz > radiusSq
                    || pos.getY() != currentLayerY
                    || ProtectedAreaHelper.isProtected(ctx.world(), pos)) {
                return false;
            }
            IBlockState state = baritone.bsi.get0(pos);
            Block block = state.getBlock();
            if (!(block instanceof BlockAir)
                    && !(block instanceof BlockLiquid)
                    && (block == Blocks.BEDROCK
                    || MovementHelper.avoidBreaking(baritone.bsi, pos.getX(), pos.getY(), pos.getZ(), state))) {
                return false;
            }
        }
        return true;
    }

    /** Find and verify an UP/DOWN hit so native directional AOE stays in the current XZ layer. */
    private Optional<Rotation> reachableDirectionalAoeLayerFace(BlockPos pos) {
        double reach = Math.min(ctx.playerController().getBlockReachDistance(), TINKERS_AOE_REACH);
        for (EnumFacing face : new EnumFacing[]{EnumFacing.UP, EnumFacing.DOWN}) {
            Vec3d faceCenter = new Vec3d(pos).add(0.5, 0.5, 0.5)
                    .add(new Vec3d(face.getDirectionVec()).scale(0.5));
            Optional<Rotation> rotation = RotationUtils.reachableOffset(
                    ctx, pos, faceCenter, reach, false);
            if (!rotation.isPresent()) {
                continue;
            }
            RayTraceResult trace = RayTraceUtils.rayTraceTowards(
                    ctx.player(), rotation.get(), reach);
            if (trace != null
                    && trace.typeOfHit == RayTraceResult.Type.BLOCK
                    && pos.equals(trace.getBlockPos())
                    && trace.sideHit == face) {
                return rotation;
            }
        }
        return Optional.empty();
    }

    /**
     * Schedule an off-thread scan of the current layer, unless one is already running. The scan is
     * tagged with the layer it was launched for, so a scan that finishes after we've descended is
     * discarded rather than clobbering the new layer's results.
     */
    private void scheduleRescan() {
        if (rescanInFlight) {
            return;
        }
        rescanInFlight = true;
        final int layer = currentLayerY;
        CalculationContext context = new CalculationContext(baritone, true);
        Baritone.getExecutor().execute(() -> {
            try {
                rescan(context, layer);
            } finally {
                rescanInFlight = false;
            }
        });
    }

    @Override
    public void onLostControl() {
        active = false;
        knownTargets = Collections.emptyList();
        loadGoal = null;
        scannedThisLayer = false;
        priorityTarget = null;
        priorityReference = null;
        activePriorityMode = null;
        baritone.getInputOverrideHandler().clearAllKeys();
    }

    @Override
    public String displayName0() {
        return String.format("Digging circle r=%d @ (%d, %d), layer y=%d", radius, centerX, centerZ, currentLayerY);
    }

    /**
     * Read a single Y layer of the disc through {@link BlockStateInterface} — which serves loaded
     * chunks and, for anything out of render distance, Baritone's persistent chunk cache — collecting
     * solid, non-bedrock blocks nearest to the player first and publishing the closest
     * {@link #TARGET_COUNT} as break targets. Columns that are neither loaded nor cached (never seen)
     * are noted so the caller can walk over and reveal them before descending. Runs off the main
     * thread (throttled) so it only reads world/cache state, never mutates it.
     *
     * @param layerY the Y layer this scan is for; results are only applied if it's still the active
     *               layer when the scan finishes (guards against a stale async scan clobbering a
     *               freshly-descended layer)
     */
    private void rescan(CalculationContext context, int layerY) {
        if (!active) {
            return;
        }
        final int cx = centerX;
        final int cz = centerZ;
        final int rSq = radiusSq;
        final int r = radius;

        BlockStateInterface bsi = context.bsi;
        BetterBlockPos feet = ctx.playerFeet();

        List<BlockPos> found = new ArrayList<>();
        BlockPos nearestUnknown = null;
        long nearestUnknownDistSq = Long.MAX_VALUE;

        for (int x = cx - r; x <= cx + r; x++) {
            int ddx = x - cx;
            int ddx2 = ddx * ddx;
            if (ddx2 > rSq) {
                continue;
            }
            for (int z = cz - r; z <= cz + r; z++) {
                int ddz = z - cz;
                if (ddx2 + ddz * ddz > rSq) {
                    continue;
                }
                if (!bsi.isLoaded(x, z)) {
                    // never seen — neither loaded nor cached; candidate to go reveal
                    if (unreachableChunks.contains(ChunkPos.asLong(x >> 4, z >> 4))) {
                        continue;
                    }
                    long d = (long) (x - feet.x) * (x - feet.x) + (long) (z - feet.z) * (z - feet.z);
                    if (d < nearestUnknownDistSq) {
                        nearestUnknownDistSq = d;
                        nearestUnknown = new BlockPos(x, layerY, z);
                    }
                    continue;
                }
                Block block = bsi.get0(x, layerY, z).getBlock();
                if (block instanceof BlockAir || block instanceof BlockLiquid || block == Blocks.BEDROCK) {
                    continue;
                }
                found.add(new BlockPos(x, layerY, z));
            }
        }

        String priorityMode = normalizedPriority();
        if (!priorityMode.equals(activePriorityMode)) {
            priorityTarget = null;
            priorityReference = feet;
            activePriorityMode = priorityMode;
        }
        if (priorityTarget != null && !found.contains(priorityTarget)) {
            completePriorityTarget(priorityTarget, priorityMode);
        }

        // Rank before the breakability prefix is checked, preserving the old bounded scan cost.
        // Non-closest modes then commit to the first valid target so GoalComposite cannot override
        // the user's ordering by choosing a cheaper member of the batch.
        found.sort(priorityComparator(priorityMode, feet));
        List<BlockPos> pruned = new ArrayList<>();
        for (BlockPos pos : found) {
            if (pruned.size() >= TARGET_COUNT) {
                break;
            }
            if (blacklist.contains(pos)) {
                continue;
            }
            if (!MineProcess.plausibleToBreak(context, pos)) {
                continue;
            }
            pruned.add(pos);
        }
        if (!priorityMode.equals("CLOSEST") && !pruned.isEmpty()) {
            if (priorityTarget == null || !pruned.contains(priorityTarget)) {
                priorityTarget = pruned.get(0);
            }
            pruned = new ArrayList<>(Collections.singletonList(priorityTarget));
        }

        // only apply if this is still the layer we're working on
        if (active && layerY == currentLayerY) {
            this.knownTargets = pruned;
            this.loadGoal = pruned.isEmpty() ? nearestUnknown : null;
            this.scannedThisLayer = true;
        }
    }

    private String normalizedPriority() {
        String value = Baritone.settings().mineTargetPriority.value;
        value = value == null ? "CLOSEST" : value.trim().toUpperCase(Locale.US);
        switch (value) {
            case "SPIRAL":
            case "VEIN":
            case "LOWEST_Y":
            case "HIGHEST_Y":
                return value;
            default:
                return "CLOSEST";
        }
    }

    private Comparator<BlockPos> priorityComparator(String mode, BlockPos playerFeet) {
        Comparator<BlockPos> playerDistance = Comparator.comparingDouble(
                pos -> ctx.player().getDistanceSq(pos.getX(), pos.getY(), pos.getZ()));
        Comparator<BlockPos> ranking;
        if (mode.equals("VEIN")) {
            BlockPos reference = priorityReference == null ? playerFeet : priorityReference;
            ranking = Comparator.comparingDouble(pos -> pos.distanceSq(reference));
        } else if (mode.equals("SPIRAL")) {
            BlockPos center = new BlockPos(centerX, currentLayerY, centerZ);
            int ringWidth = Math.max(1, Baritone.settings().minePriorityRingWidth.value);
            ranking = Comparator
                    .comparingInt((BlockPos pos) -> radialRing(center, pos, ringWidth))
                    .thenComparingDouble(pos -> clockwiseDelta(spiralAngle, angle(center, pos)))
                    .thenComparing(playerDistance);
        } else if (mode.equals("LOWEST_Y")) {
            ranking = Comparator.comparingInt(BlockPos::getY).thenComparing(playerDistance);
        } else if (mode.equals("HIGHEST_Y")) {
            ranking = Comparator.comparingInt(BlockPos::getY).reversed().thenComparing(playerDistance);
        } else {
            ranking = playerDistance;
        }
        if (priorityTarget != null) {
            ranking = Comparator.<BlockPos>comparingInt(pos -> pos.equals(priorityTarget) ? 0 : 1)
                    .thenComparing(ranking);
        }
        return ranking;
    }

    private void completePriorityTarget(BlockPos completed, String mode) {
        priorityReference = completed;
        if (mode.equals("SPIRAL")) {
            spiralAngle = angle(new BlockPos(centerX, completed.getY(), centerZ), completed);
        }
        priorityTarget = null;
    }

    private static int radialRing(BlockPos origin, BlockPos pos, int width) {
        double dx = pos.getX() - origin.getX();
        double dz = pos.getZ() - origin.getZ();
        return (int) (Math.sqrt(dx * dx + dz * dz) / width);
    }

    private static double angle(BlockPos origin, BlockPos pos) {
        double result = Math.atan2(pos.getZ() - origin.getZ(), pos.getX() - origin.getX());
        return result < 0 ? result + Math.PI * 2 : result;
    }

    private static double clockwiseDelta(double from, double to) {
        double result = to - from;
        return result < 0 ? result + Math.PI * 2 : result;
    }

    /**
     * A pathing context that refuses to break any block below the layer currently being cleared, so
     * the pathfinder can never dig its way down to a lower layer to satisfy a goal cheaply. This is
     * what keeps the dig strictly one-layer-at-a-time.
     */
    private final class LayerCalculationContext extends CalculationContext {

        private final int minBreakableY;

        private LayerCalculationContext(int layerY) {
            super(CircleProcess.this.baritone, true);
            this.minBreakableY = layerY;
        }

        @Override
        public double breakCostMultiplierAt(int x, int y, int z, IBlockState current) {
            if (y < minBreakableY) {
                return COST_INF;
            }
            return super.breakCostMultiplierAt(x, y, z, current);
        }
    }
}
