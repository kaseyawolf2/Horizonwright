/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package baritone.process;

import baritone.Baritone;
import baritone.api.process.PathingCommand;
import baritone.api.process.PathingCommandType;
import baritone.utils.BaritoneProcessHelper;
import baritone.utils.InventoryItemHelper;
import baritone.utils.ToolSet;
import baritone.compat.IBlockState;
import baritone.compat.Blocks;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

import java.util.HashSet;
import java.util.Set;

/**
 * Uses item-backed storage through its normal server-authoritative GUI. No mod classes are linked:
 * backpacks, bags, Ender Pouches, and remote terminals all look like a held item which opens a
 * container containing player slots and non-player slots.
 */
public final class PortableStorageProcess extends BaritoneProcessHelper {

    private static final int MAIN_START = 9;
    private static final int MAIN_END = 36;
    private static final int WORK_HOTBAR_SLOT = 6;
    private static final int OPEN_TIMEOUT = 60;
    private static final int RETRY_COOLDOWN = 200;

    private enum Action { NONE, WITHDRAW_FOOD, WITHDRAW_TOOL, DEPOSIT }

    private Action action = Action.NONE;
    private int portableSlot = -1;
    private int previousSelected = -1;
    private boolean movedToHotbar;
    private boolean openRequested;
    private boolean restoring;
    private int openTicks;
    private int transferTicks;
    private int retryCooldown;
    private final Set<Integer> attemptedSlots = new HashSet<>();
    private final Set<Integer> rejectedDepositBags = new HashSet<>();
    private boolean tryAnotherDepositBag;

    public PortableStorageProcess(Baritone baritone) {
        super(baritone);
    }

    @Override
    public boolean isActive() {
        if (action != Action.NONE) {
            return true;
        }
        // DropOffProcess temporarily stages bag contents in the player inventory before putting
        // them into the chest. Refilling a bag during that staging window creates an endless
        // drain/refill loop, so drop-off owns every portable container until its run is complete.
        if (baritone.getDropOffProcess().ownsPortableStorage()) {
            return false;
        }
        if (!Baritone.settings().allowInventory.value || !Baritone.settings().allowPortableStorage.value
                || ctx.player() == null || ctx.world() == null
                || ctx.player().openContainer != ctx.player().inventoryContainer) {
            return false;
        }

        // A real empty slot ends the current saturation event. Bags rejected while full must be
        // eligible again after mining fills the inventory a second time.
        if (!standardInventorySaturated()) {
            rejectedDepositBags.clear();
        }
        if (retryCooldown > 0) {
            retryCooldown--;
            return false;
        }

        Action wanted = wantedAction();
        if (wanted == Action.NONE) {
            return false;
        }
        int found = findPortableStorage(wanted == Action.DEPOSIT);
        if (found < 0) {
            return false;
        }
        action = wanted;
        portableSlot = found;
        previousSelected = ctx.player().inventory.currentItem;
        movedToHotbar = found >= 9;
        openRequested = false;
        restoring = false;
        openTicks = 0;
        transferTicks = 0;
        tryAnotherDepositBag = false;
        attemptedSlots.clear();
        return true;
    }

    private Action wantedAction() {
        if (Baritone.settings().portableStorageFood.value && Baritone.settings().autoEat.value
                && ctx.player().getFoodStats().getFoodLevel() <= Baritone.settings().autoEatThreshold.value
                && !playerHasFood()) {
            return Action.WITHDRAW_FOOD;
        }
        if (Baritone.settings().portableStorageTools.value && toolUsingProcessActive() && !playerHasTool()) {
            return Action.WITHDRAW_TOOL;
        }
        if (Baritone.settings().portableStorageDeposit.value && gatheringProcessActive()
                && standardInventorySaturated() && hasDepositCandidate()) {
            return Action.DEPOSIT;
        }
        return Action.NONE;
    }

    @Override
    public PathingCommand onTick(boolean calcFailed, boolean isSafeToCancel) {
        baritone.getInputOverrideHandler().clearAllKeys();

        if (restoring) {
            return restorePortableItem();
        }
        if (!isSafeToCancel && ctx.player().openContainer == ctx.player().inventoryContainer) {
            return new PathingCommand(null, PathingCommandType.DEFER);
        }
        if (ctx.player().openContainer != ctx.player().inventoryContainer) {
            return transfer(ctx.player().openContainer);
        }

        int heldSlot = portableSlot;
        if (movedToHotbar) {
            heldSlot = WORK_HOTBAR_SLOT;
            ItemStack held = ctx.player().inventory.getStackInSlot(heldSlot);
            if (!InventoryItemHelper.isPortableStorage(held)) {
                if (!baritone.getInventoryBehavior().swapWithHotbar(portableSlot, heldSlot)) {
                    return pause();
                }
                return pause(); // let the inventory packet settle before using the item
            }
        }
        ItemStack portable = ctx.player().inventory.getStackInSlot(heldSlot);
        if (!InventoryItemHelper.isPortableStorage(portable)) {
            return finish(false, "Portable storage item disappeared before it could be opened");
        }
        ctx.player().inventory.currentItem = heldSlot;
        if (!openRequested) {
            openRequested = true;
            ctx.minecraft().playerController.sendUseItem(ctx.player(), ctx.world(), portable);
        }
        if (++openTicks > OPEN_TIMEOUT) {
            return finish(false, "Portable storage did not open");
        }
        return pause();
    }

    private PathingCommand transfer(Container container) {
        if (!hasPlayerAndStorageSlots(container)) {
            if (++openTicks <= OPEN_TIMEOUT) {
                return pause();
            }
            return finish(false, "Portable storage GUI exposed no transferable inventory slots");
        }
        int delay = Math.max(1, Baritone.settings().ticksBetweenInventoryMoves.value);
        if (++transferTicks < delay) {
            return pause();
        }
        transferTicks = 0;

        if (action == Action.WITHDRAW_FOOD && playerHasFood()) {
            return finish(true, null);
        }
        if (action == Action.WITHDRAW_TOOL && playerHasTool()) {
            return finish(true, null);
        }

        if (action == Action.DEPOSIT) {
            for (int inventorySlot = MAIN_START; inventorySlot < MAIN_END; inventorySlot++) {
                ItemStack stack = ctx.player().inventory.getStackInSlot(inventorySlot);
                if (stack == null || InventoryItemHelper.isOperational(stack) || attemptedSlots.contains(inventorySlot)) {
                    continue;
                }
                Slot playerSlot = findPlayerSlot(container, inventorySlot);
                if (playerSlot == null) {
                    attemptedSlots.add(inventorySlot);
                    continue;
                }
                attemptedSlots.add(inventorySlot);
                ctx.playerController().windowClick(container.windowId, playerSlot.slotNumber, 0, 1, ctx.player());
                return pause();
            }
            boolean relieved = !standardInventorySaturated();
            if (!relieved) {
                rejectedDepositBags.add(portableSlot);
                tryAnotherDepositBag = findPortableStorage(true) >= 0;
            }
            return finish(relieved, relieved ? null
                    : tryAnotherDepositBag
                    ? "Portable storage created no usable capacity; trying the next bag"
                    : "Portable storage created no usable capacity; allowing physical drop-off instead");
        }

        for (Object object : container.inventorySlots) {
            Slot slot = (Slot) object;
            if (slot.inventory == ctx.player().inventory || attemptedSlots.contains(slot.slotNumber)) {
                continue;
            }
            ItemStack stack = slot.getStack();
            boolean wanted = action == Action.WITHDRAW_FOOD
                    ? InventoryItemHelper.isSafeFood(stack)
                    : isUsefulStoneTool(stack);
            if (!wanted) {
                continue;
            }
            attemptedSlots.add(slot.slotNumber);
            ctx.playerController().windowClick(container.windowId, slot.slotNumber, 0, 1, ctx.player());
            return pause();
        }
        return finish(false, action == Action.WITHDRAW_FOOD
                ? "No usable food was found in portable storage"
                : "No usable tool was found in portable storage");
    }

    private PathingCommand finish(boolean success, String failure) {
        if (ctx.player().openContainer != ctx.player().inventoryContainer) {
            ctx.player().closeScreen();
        }
        if (!success && failure != null) {
            logDebug(failure);
        }
        retryCooldown = tryAnotherDepositBag ? 0 : success ? 20 : RETRY_COOLDOWN;
        restoring = true;
        return pause();
    }

    private PathingCommand restorePortableItem() {
        if (ctx.player().openContainer != ctx.player().inventoryContainer) {
            ctx.player().closeScreen();
            return pause();
        }
        if (movedToHotbar) {
            ItemStack held = ctx.player().inventory.getStackInSlot(WORK_HOTBAR_SLOT);
            if (InventoryItemHelper.isPortableStorage(held)) {
                if (!baritone.getInventoryBehavior().swapWithHotbar(portableSlot, WORK_HOTBAR_SLOT)) {
                    return pause();
                }
                return pause();
            }
        }
        if (previousSelected >= 0 && previousSelected < 9) {
            ctx.player().inventory.currentItem = previousSelected;
        }
        resetRun();
        return new PathingCommand(null, PathingCommandType.CANCEL_AND_SET_GOAL);
    }

    private int findPortableStorage(boolean excludeRejectedDepositBags) {
        for (int slot = 0; slot < MAIN_END; slot++) {
            if ((!excludeRejectedDepositBags || !rejectedDepositBags.contains(slot))
                    && InventoryItemHelper.isPortableStorage(ctx.player().inventory.getStackInSlot(slot))) {
                return slot;
            }
        }
        return -1;
    }

    private boolean playerHasFood() {
        for (int slot = 0; slot < MAIN_END; slot++) {
            if (InventoryItemHelper.isSafeFood(ctx.player().inventory.getStackInSlot(slot))) {
                return true;
            }
        }
        return false;
    }

    private boolean playerHasTool() {
        for (int slot = 0; slot < MAIN_END; slot++) {
            if (isUsefulStoneTool(ctx.player().inventory.getStackInSlot(slot))) {
                return true;
            }
        }
        return false;
    }

    private boolean hasDepositCandidate() {
        for (int slot = MAIN_START; slot < MAIN_END; slot++) {
            ItemStack stack = ctx.player().inventory.getStackInSlot(slot);
            if (stack != null && !InventoryItemHelper.isOperational(stack)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Require a genuinely empty slot. A partial stack is only capacity for an identical item;
     * treating it as generic space leaves different mined drops stranded on the ground.
     */
    private boolean standardInventorySaturated() {
        for (int slot = MAIN_START; slot < MAIN_END; slot++) {
            ItemStack stack = ctx.player().inventory.getStackInSlot(slot);
            if (stack == null) {
                return false;
            }
        }
        return true;
    }

    private boolean gatheringProcessActive() {
        return baritone.getMineProcess().isActive()
                || baritone.getCircleProcess().isActive()
                || baritone.getFarmProcess().isActive();
    }

    private boolean toolUsingProcessActive() {
        return baritone.getMineProcess().isActive() || baritone.getCircleProcess().isActive();
    }

    private static boolean isUsefulStoneTool(ItemStack stack) {
        return InventoryItemHelper.isMiningTool(stack)
                && ToolSet.calculateSpeedVsBlock(stack, IBlockState.of(Blocks.STONE))
                > ToolSet.calculateSpeedVsBlock(null, IBlockState.of(Blocks.STONE));
    }

    private boolean hasPlayerAndStorageSlots(Container container) {
        boolean player = false;
        boolean storage = false;
        for (Object object : container.inventorySlots) {
            Slot slot = (Slot) object;
            player |= slot.inventory == ctx.player().inventory;
            storage |= slot.inventory != ctx.player().inventory;
        }
        return player && storage;
    }

    private Slot findPlayerSlot(Container container, int inventorySlot) {
        for (Object object : container.inventorySlots) {
            Slot slot = (Slot) object;
            if (slot.inventory == ctx.player().inventory && slot.getSlotIndex() == inventorySlot) {
                return slot;
            }
        }
        return null;
    }

    private PathingCommand pause() {
        return new PathingCommand(null, PathingCommandType.REQUEST_PAUSE);
    }

    private void resetRun() {
        action = Action.NONE;
        portableSlot = -1;
        previousSelected = -1;
        movedToHotbar = false;
        openRequested = false;
        restoring = false;
        openTicks = 0;
        transferTicks = 0;
        tryAnotherDepositBag = false;
        attemptedSlots.clear();
    }

    @Override
    public void onLostControl() {
        if (ctx.player() != null && ctx.player().openContainer != ctx.player().inventoryContainer) {
            ctx.player().closeScreen();
        }
        resetRun();
    }

    @Override
    public boolean isTemporary() {
        return true;
    }

    @Override
    public double priority() {
        // Prepares food for auto-eat and empties inventory before the physical drop-off journey.
        return 5.25;
    }

    @Override
    public String displayName0() {
        switch (action) {
            case WITHDRAW_FOOD:
                return "Getting food from portable storage";
            case WITHDRAW_TOOL:
                return "Getting a tool from portable storage";
            case DEPOSIT:
                return "Storing items in portable storage";
            default:
                return "Portable storage";
        }
    }
}
