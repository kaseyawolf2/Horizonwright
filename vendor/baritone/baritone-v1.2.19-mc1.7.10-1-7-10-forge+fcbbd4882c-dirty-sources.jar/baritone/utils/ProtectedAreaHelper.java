/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package baritone.utils;

import baritone.Baritone;
import baritone.compat.BlockPos;
import net.minecraft.world.World;

/**
 * Encoding and lookup for persistent, horizontal protected areas.
 */
public final class ProtectedAreaHelper {

    private ProtectedAreaHelper() {
    }

    public static String key(int dimension, int x1, int z1, int x2, int z2) {
        int minX = Math.min(x1, x2);
        int minZ = Math.min(z1, z2);
        int maxX = Math.max(x1, x2);
        int maxZ = Math.max(z1, z2);
        return dimension + ":" + minX + ":" + minZ + ":" + maxX + ":" + maxZ;
    }

    public static boolean isProtected(World world, BlockPos pos) {
        return world != null && pos != null && isProtected(world, pos.getX(), pos.getZ());
    }

    public static boolean isProtected(World world, int blockX, int blockZ) {
        if (world == null) {
            return false;
        }
        int dimension = world.provider.dimensionId;
        for (String entry : Baritone.settings().protectedAreas.value) {
            String[] parts = entry.split(":", 5);
            if (parts.length != 5) {
                continue;
            }
            try {
                if (Integer.parseInt(parts[0]) == dimension
                        && blockX >= Integer.parseInt(parts[1])
                        && blockZ >= Integer.parseInt(parts[2])
                        && blockX <= Integer.parseInt(parts[3])
                        && blockZ <= Integer.parseInt(parts[4])) {
                    return true;
                }
            } catch (NumberFormatException ignored) {
                // Ignore malformed entries rather than breaking path calculation.
            }
        }
        return false;
    }
}
