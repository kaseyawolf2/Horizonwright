package baritone.utils;

import baritone.Baritone;
import baritone.api.Settings;
import baritone.api.process.IBaritoneProcess;
import baritone.api.selection.ISelection;
import baritone.api.utils.BetterBlockPos;
import baritone.api.utils.SettingsUtil;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.EnumChatFormatting;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/** A compact, dependency-free control panel suitable for the 1.7.10 client. */
public class GuiBaritoneControl extends GuiScreen {

    private static final String[] TABS = {"Overview", "Settings", "Mining", "Protected"};
    private static final String[] TOGGLES = {
            "allowBreak", "allowPlace", "allowSprint", "allowInventory", "autoTool",
            "allowParkour", "allowDownward", "allowDiagonalAscend", "allowDiagonalDescend",
            "avoidance", "autoEat", "defendAgainstMobs", "backfill", "renderPath",
            "renderGoal", "renderSelection", "mineScanDroppedItems", "blacklistClosestOnFailure"
    };
    private static final String[] PRIORITIES = {"CLOSEST", "SPIRAL", "VEIN", "LOWEST_Y", "HIGHEST_Y"};

    private final Baritone baritone;
    private int tab;
    private int page;
    private int left;
    private int top;
    private int panelWidth;
    private String notice = "";

    public GuiBaritoneControl(Baritone baritone) {
        this.baritone = baritone;
    }

    @Override
    public void initGui() {
        buttonList.clear();
        panelWidth = Math.min(380, width - 16);
        left = (width - panelWidth) / 2;
        top = Math.max(8, (height - 248) / 2);
        int tabWidth = panelWidth / TABS.length;
        for (int i = 0; i < TABS.length; i++) {
            GuiButton button = new GuiButton(10 + i, left + i * tabWidth, top + 22, tabWidth - 2, 20, TABS[i]);
            button.enabled = tab != i;
            buttonList.add(button);
        }
        if (tab == 0) {
            addOverviewButtons();
        } else if (tab == 1) {
            addSettingsButtons();
        } else if (tab == 2) {
            addMiningButtons();
        } else {
            addAreaButtons();
        }
        buttonList.add(new GuiButton(1, left + panelWidth - 70, top + 220, 70, 20, "Done"));
    }

    private void addOverviewButtons() {
        int y = top + 78;
        int w = (panelWidth - 12) / 3;
        buttonList.add(new GuiButton(20, left, y, w, 20, "Pause"));
        buttonList.add(new GuiButton(21, left + w + 6, y, w, 20, "Resume"));
        buttonList.add(new GuiButton(22, left + (w + 6) * 2, y, w, 20, "Cancel"));
        buttonList.add(new GuiButton(23, left, y + 28, (panelWidth - 6) / 2, 20, "Save settings"));
        buttonList.add(new GuiButton(24, left + (panelWidth + 6) / 2, y + 28, (panelWidth - 6) / 2, 20, "World click selector"));
    }

    private void addSettingsButtons() {
        int first = page * 8;
        int cellWidth = (panelWidth - 6) / 2;
        for (int i = 0; i < 8 && first + i < TOGGLES.length; i++) {
            Settings.Setting<?> setting = setting(TOGGLES[first + i]);
            int x = left + (i % 2) * (cellWidth + 6);
            int y = top + 55 + (i / 2) * 27;
            buttonList.add(new GuiButton(100 + first + i, x, y, cellWidth, 20, toggleLabel(setting)));
        }
        addPager(TOGGLES.length, 8);
    }

    private void addMiningButtons() {
        int y = top + 58;
        String current = normalizedPriority();
        for (int i = 0; i < PRIORITIES.length; i++) {
            GuiButton button = new GuiButton(200 + i, left, y + i * 23, 126, 20, friendly(PRIORITIES[i]));
            button.enabled = !PRIORITIES[i].equals(current);
            buttonList.add(button);
        }
        int x = left + 140;
        addToggleButton(230, "legitMine", x, y, panelWidth - 140);
        addToggleButton(231, "allowOnlyExposedOres", x, y + 25, panelWidth - 140);
        addToggleButton(232, "mineScanDroppedItems", x, y + 50, panelWidth - 140);
        buttonList.add(new GuiButton(240, x, y + 82, 25, 20, "-"));
        buttonList.add(new GuiButton(241, left + panelWidth - 25, y + 82, 25, 20, "+"));
    }

    private void addAreaButtons() {
        List<String> areas = currentAreas();
        int first = page * 5;
        for (int i = 0; i < 5 && first + i < areas.size(); i++) {
            String entry = areas.get(first + i);
            buttonList.add(new GuiButton(300 + first + i, left + panelWidth - 58, top + 55 + i * 25, 58, 20, "Delete"));
        }
        int y = top + 184;
        buttonList.add(new GuiButton(350, left, y, (panelWidth - 6) / 2, 20, "Add last selection"));
        buttonList.add(new GuiButton(351, left + (panelWidth + 6) / 2, y, (panelWidth - 6) / 2, 20, "Add 16x16 around me"));
        addPager(areas.size(), 5);
    }

    private void addPager(int count, int perPage) {
        int maxPage = Math.max(0, (count - 1) / perPage);
        GuiButton previous = new GuiButton(60, left, top + 220, 25, 20, "<");
        previous.enabled = page > 0;
        buttonList.add(previous);
        GuiButton next = new GuiButton(61, left + 31, top + 220, 25, 20, ">");
        next.enabled = page < maxPage;
        buttonList.add(next);
    }

    private void addToggleButton(int id, String name, int x, int y, int width) {
        buttonList.add(new GuiButton(id, x, y, width, 20, toggleLabel(setting(name))));
    }

    @Override
    protected void actionPerformed(GuiButton button) {
        if (button.id == 1) {
            mc.displayGuiScreen(null);
        } else if (button.id >= 10 && button.id < 14) {
            tab = button.id - 10;
            page = 0;
            notice = "";
            initGui();
        } else if (button.id == 20 || button.id == 21 || button.id == 22) {
            baritone.getCommandManager().execute(button.id == 20 ? "pause" : button.id == 21 ? "resume" : "cancel");
            notice = button.id == 20 ? "Pause requested" : button.id == 21 ? "Resume requested" : "Task cancelled";
        } else if (button.id == 23) {
            SettingsUtil.save(Baritone.settings());
            notice = "Settings saved";
        } else if (button.id == 24) {
            mc.displayGuiScreen(null);
            baritone.openClick();
        } else if (button.id == 60 || button.id == 61) {
            page += button.id == 60 ? -1 : 1;
            initGui();
        } else if (button.id >= 100 && button.id < 100 + TOGGLES.length) {
            toggle(setting(TOGGLES[button.id - 100]));
        } else if (button.id >= 200 && button.id < 200 + PRIORITIES.length) {
            Baritone.settings().mineTargetPriority.value = PRIORITIES[button.id - 200];
            saveAndRefresh("Mining priority: " + friendly(PRIORITIES[button.id - 200]));
        } else if (button.id >= 230 && button.id <= 232) {
            toggle(setting(button.id == 230 ? "legitMine" : button.id == 231 ? "allowOnlyExposedOres" : "mineScanDroppedItems"));
        } else if (button.id == 240 || button.id == 241) {
            int change = button.id == 240 ? -1 : 1;
            Baritone.settings().minePriorityRingWidth.value = Math.max(1, Baritone.settings().minePriorityRingWidth.value + change);
            saveAndRefresh("Spiral ring width updated");
        } else if (button.id >= 300 && button.id < 350) {
            List<String> areas = currentAreas();
            int index = button.id - 300;
            if (index < areas.size()) {
                List<String> updated = new ArrayList<>(Baritone.settings().protectedAreas.value);
                updated.remove(areas.get(index));
                applyAreas(updated, "Protected area deleted");
            }
        } else if (button.id == 350) {
            addSelectionArea();
        } else if (button.id == 351) {
            BetterBlockPos pos = baritone.getPlayerContext().playerFeet();
            addArea(pos.x - 8, pos.z - 8, pos.x + 7, pos.z + 7, "Protected 16x16 around player");
        }
    }

    private void addSelectionArea() {
        ISelection selection = baritone.getSelectionManager().getLastSelection();
        if (selection == null) {
            notice = EnumChatFormatting.RED + "No selection. Use the world click selector first.";
            return;
        }
        addArea(selection.min().x, selection.min().z, selection.max().x, selection.max().z, "Selection protected");
    }

    private void addArea(int x1, int z1, int x2, int z2, String message) {
        int dimension = mc.theWorld.provider.dimensionId;
        String key = ProtectedAreaHelper.key(dimension, x1, z1, x2, z2);
        List<String> updated = new ArrayList<>(Baritone.settings().protectedAreas.value);
        if (!updated.contains(key)) {
            updated.add(key);
        }
        applyAreas(updated, message);
    }

    private void applyAreas(List<String> updated, String message) {
        if (updated.isEmpty()) {
            Baritone.settings().protectedAreas.reset();
        } else {
            Baritone.settings().protectedAreas.value = updated;
        }
        baritone.getInputOverrideHandler().getBlockBreakHelper().stopBreakingBlock();
        page = 0;
        saveAndRefresh(message);
    }

    @SuppressWarnings("unchecked")
    private void toggle(Settings.Setting<?> raw) {
        if (raw != null && raw.getValueClass() == Boolean.class) {
            Settings.Setting<Boolean> setting = (Settings.Setting<Boolean>) raw;
            setting.value = !setting.value;
            saveAndRefresh(friendly(setting.getName()) + ": " + (setting.value ? "ON" : "OFF"));
        }
    }

    private void saveAndRefresh(String message) {
        SettingsUtil.save(Baritone.settings());
        notice = message;
        initGui();
    }

    private Settings.Setting<?> setting(String name) {
        return Baritone.settings().byLowerName.get(name.toLowerCase(Locale.US));
    }

    private static String toggleLabel(Settings.Setting<?> setting) {
        if (setting == null) {
            return "Unavailable";
        }
        return friendly(setting.getName()) + ": " + ((Boolean) setting.value ? EnumChatFormatting.GREEN + "ON" : EnumChatFormatting.RED + "OFF");
    }

    private String normalizedPriority() {
        String value = Baritone.settings().mineTargetPriority.value;
        value = value == null ? "CLOSEST" : value.toUpperCase(Locale.US);
        return Arrays.asList(PRIORITIES).contains(value) ? value : "CLOSEST";
    }

    private List<String> currentAreas() {
        List<String> result = new ArrayList<>();
        if (mc.theWorld == null) {
            return result;
        }
        String prefix = mc.theWorld.provider.dimensionId + ":";
        for (String area : Baritone.settings().protectedAreas.value) {
            if (area.startsWith(prefix)) {
                result.add(area);
            }
        }
        return result;
    }

    private static String friendly(String raw) {
        String words = raw.replace('_', ' ').replaceAll("([a-z])([A-Z])", "$1 $2").toLowerCase(Locale.US);
        return words.isEmpty() ? words : Character.toUpperCase(words.charAt(0)) + words.substring(1);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        drawRect(left - 6, top - 6, left + panelWidth + 6, top + 246, 0xD0101218);
        drawCenteredString(fontRendererObj, "Baritone Control Panel", width / 2, top + 6, 0xFFFFFFFF);
        if (tab == 0) {
            IBaritoneProcess process = baritone.getPathingControlManager().mostRecentInControl().orElse(null);
            drawString(fontRendererObj, "Status: " + (process == null ? "Idle" : process.displayName()), left, top + 57, 0xFFE0E0E0);
            drawString(fontRendererObj, "Quick controls", left, top + 68, 0xFF8FAAD0);
            drawString(fontRendererObj, "Use #panel, #gui, or #controlpanel to reopen this screen.", left, top + 144, 0xFFAAAAAA);
        } else if (tab == 1) {
            drawString(fontRendererObj, "Click a setting to toggle it. Changes save immediately.", left, top + 47, 0xFFAAAAAA);
        } else if (tab == 2) {
            drawString(fontRendererObj, "Target ranking (#mine and #circle)", left, top + 47, 0xFF8FAAD0);
            drawString(fontRendererObj, "Spiral ring width: " + Baritone.settings().minePriorityRingWidth.value, left + 169, top + 145, 0xFFFFFFFF);
            drawString(fontRendererObj, priorityDescription(normalizedPriority()), left + 140, top + 174, 0xFFBBBBBB);
        } else {
            List<String> areas = currentAreas();
            drawString(fontRendererObj, "Dimension " + (mc.theWorld == null ? "?" : mc.theWorld.provider.dimensionId) + " protected areas", left, top + 47, 0xFF8FAAD0);
            int first = page * 5;
            if (areas.isEmpty()) {
                drawString(fontRendererObj, "No protected areas in this dimension.", left, top + 64, 0xFFAAAAAA);
            }
            for (int i = 0; i < 5 && first + i < areas.size(); i++) {
                String[] parts = areas.get(first + i).split(":", 5);
                String label = parts.length == 5 ? "[" + parts[1] + ", " + parts[2] + "] to [" + parts[3] + ", " + parts[4] + "]" : areas.get(first + i);
                drawString(fontRendererObj, label, left, top + 61 + i * 25, 0xFFE0E0E0);
            }
        }
        if (!notice.isEmpty()) {
            drawCenteredString(fontRendererObj, notice, width / 2, top + 210, 0xFFFFFFFF);
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    private static String priorityDescription(String mode) {
        if (mode.equals("SPIRAL")) return "Works outward and around each ring.";
        if (mode.equals("VEIN")) return "Stays near the last finished target.";
        if (mode.equals("LOWEST_Y")) return "Lowest blocks first.";
        if (mode.equals("HIGHEST_Y")) return "Highest blocks first.";
        return "Shortest travel first.";
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
