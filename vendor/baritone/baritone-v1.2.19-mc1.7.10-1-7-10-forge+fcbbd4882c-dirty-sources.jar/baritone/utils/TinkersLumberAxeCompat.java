/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package baritone.utils;

import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

import java.util.Map;
import java.util.WeakHashMap;

/**
 * Dependency-free support for the Tinkers' Construct 1.7.10 Lumber Axe.
 *
 * <p>TConstruct performs the 3x3 fallback synchronously, but fells detected trees from a
 * server-side task. That task explicitly stops when the player no longer holds the exact same
 * {@link ItemStack}. Baritone normally chooses a tool again as soon as the first log disappears,
 * which can switch away from the axe before the task has visited the remaining logs.</p>
 */
public final class TinkersLumberAxeCompat {

    private static final String LUMBER_AXE_CLASS = "tconstruct.items.tools.LumberAxe";
    private static final int HOLD_TICKS = 20;
    /** Leaves and delayed server block updates can invalidate paths well after the logs are gone. */
    private static final int SETTLE_TICKS = 100;
    private static final Map<EntityPlayer, Hold> ACTIVE = new WeakHashMap<>();

    private TinkersLumberAxeCompat() {}

    public static boolean isLumberAxe(ItemStack stack) {
        if (stack == null || stack.getItem() == null) {
            return false;
        }
        Item item = stack.getItem();
        if (LUMBER_AXE_CLASS.equals(item.getClass().getName())) {
            return true;
        }
        // Keep compatibility with forks which relocate or subclass the original implementation.
        try {
            String name = item.getUnlocalizedName(stack);
            return name != null && name.toLowerCase(java.util.Locale.ROOT).contains("lumberaxe");
        } catch (Throwable ignored) {
            return false;
        }
    }

    /** Record a native Lumber Axe area/tree break started by Baritone. */
    public static void onBlockStartBreak(EntityPlayer player, World world, int x, int y, int z) {
        if (player == null || world == null || player.isSneaking()) {
            return;
        }
        ItemStack held = player.getCurrentEquippedItem();
        if (!isUsableLumberAxe(held)) {
            return;
        }
        Block block = world.getBlock(x, y, z);
        if (block == null || (!block.isWood(world, x, y, z)
                && block.getMaterial() != net.minecraft.block.material.Material.wood)) {
            return;
        }
        boolean treeFelling = detectsTree(held, world, x, y, z);
        synchronized (ACTIVE) {
            ACTIVE.put(player, new Hold(
                    held,
                    // While the first log is still being mined, keep the selected axe but do
                    // not pause attack. The shorter task-completion lease starts on removal.
                    player.ticksExisted + (treeFelling ? SETTLE_TICKS : 0),
                    player.ticksExisted + SETTLE_TICKS,
                    world, block, x, y, z, treeFelling));
        }
    }

    /** Ask the installed TConstruct implementation so forks retain their own tree definition. */
    private static boolean detectsTree(ItemStack stack, World world, int x, int y, int z) {
        try {
            java.lang.reflect.Method method = stack.getItem().getClass()
                    .getMethod("detectTree", World.class, int.class, int.class, int.class);
            return Boolean.TRUE.equals(method.invoke(null, world, x, y, z));
        } catch (Throwable ignored) {
            // Conservatively preserve the axe when a fork hides or renames the detector.
            return true;
        }
    }

    /**
     * Return the hotbar slot that must remain selected while TConstruct finishes its tree task,
     * or {@code -1} when there is no active task lease.
     */
    public static int heldSlot(EntityPlayer player) {
        if (player == null) {
            return -1;
        }
        Hold hold;
        synchronized (ACTIVE) {
            hold = ACTIVE.get(player);
            if (hold == null) {
                return -1;
            }
            if (player.ticksExisted > hold.settleUntilTick) {
                ACTIVE.remove(player);
                return -1;
            }
            if (player.ticksExisted > hold.untilTick || !isUsableLumberAxe(hold.stack)) {
                return -1;
            }
        }
        for (int slot = 0; slot < 9; slot++) {
            if (player.inventory.getStackInSlot(slot) == hold.stack) {
                return slot;
            }
        }
        return -1;
    }

    /** True while the axe must stay selected so TConstruct's server task is not cancelled. */
    public static boolean isFelling(EntityPlayer player) {
        if (player == null) {
            return false;
        }
        synchronized (ACTIVE) {
            Hold hold = ACTIVE.get(player);
            if (hold == null) {
                return false;
            }
            if (!hold.treeFelling) {
                return false;
            }
            // Do not release attack on mouse-down. TConstruct may not start its follow-up task
            // until the initial block has actually finished breaking on the server.
            try {
                if (hold.world.getBlock(hold.x, hold.y, hold.z) != hold.targetBlock) {
                    if (!hold.breakObserved) {
                        hold.breakObserved = true;
                        hold.untilTick = player.ticksExisted + HOLD_TICKS;
                        hold.settleUntilTick = player.ticksExisted + SETTLE_TICKS;
                    }
                    return heldSlot(player) >= 0;
                }
                return false;
            } catch (Throwable ignored) {
                return false;
            }
        }
    }

    /**
     * True while paths may still be invalidated by delayed log updates, falling, or leaf decay.
     * MineProcess uses this only to retry a fresh path instead of blacklisting a valid log.
     */
    public static boolean isSettling(EntityPlayer player) {
        if (player == null) {
            return false;
        }
        synchronized (ACTIVE) {
            Hold hold = ACTIVE.get(player);
            if (hold == null) {
                return false;
            }
            if (player.ticksExisted > hold.settleUntilTick) {
                ACTIVE.remove(player);
                return false;
            }
            return true;
        }
    }

    private static boolean isUsableLumberAxe(ItemStack stack) {
        if (!isLumberAxe(stack)) {
            return false;
        }
        try {
            return !stack.hasTagCompound()
                    || !stack.getTagCompound().getCompoundTag("InfiTool").getBoolean("Broken");
        } catch (Throwable ignored) {
            return true;
        }
    }

    private static final class Hold {
        private final ItemStack stack;
        private int untilTick;
        private int settleUntilTick;
        private boolean breakObserved;
        private final World world;
        private final Block targetBlock;
        private final int x;
        private final int y;
        private final int z;
        private final boolean treeFelling;

        private Hold(ItemStack stack, int untilTick, int settleUntilTick,
                     World world, Block targetBlock, int x, int y, int z, boolean treeFelling) {
            this.stack = stack;
            this.untilTick = untilTick;
            this.settleUntilTick = settleUntilTick;
            this.world = world;
            this.targetBlock = targetBlock;
            this.x = x;
            this.y = y;
            this.z = z;
            this.treeFelling = treeFelling;
        }
    }
}
