/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.utils;

import baritone.Baritone;
import baritone.compat.Compat;

import baritone.api.utils.IPlayerContext;
import baritone.compat.IBlockState;
import baritone.compat.RayTraceResult;
import net.minecraft.item.ItemStack;

/**
 * @author Brady
 * @since 8/25/2018
 */
public final class BlockBreakHelper {

    private final IPlayerContext ctx;
    private boolean didBreakLastTick;

    BlockBreakHelper(IPlayerContext ctx) {
        this.ctx = ctx;
    }

    public void stopBreakingBlock() {
        // The player controller will never be null, but the player can be
        if (ctx.player() != null && didBreakLastTick) {
            if (!ctx.playerController().hasBrokenBlock()) {
                // insane bypass to check breaking succeeded
                ctx.playerController().setHittingBlock(true);
            }
            ctx.playerController().resetBlockRemoving();
            didBreakLastTick = false;
        }
    }

    public void tick(boolean isLeftClick) {
        RayTraceResult trace = ctx.objectMouseOver();
        boolean isBlockTrace = trace != null && trace.typeOfHit == RayTraceResult.Type.BLOCK;

        if (isLeftClick && isBlockTrace) {
            if (ProtectedAreaHelper.isProtected(ctx.world(), trace.getBlockPos())) {
                stopBreakingBlock();
                return;
            }
            ItemStack held = ctx.player().getCurrentEquippedItem();
            if (TinkersAoeToolCompat.hasAreaEffect(ctx.player(), held)
                    && TinkersAoeToolCompat.affectedBlocks(trace.getBlockPos(), trace.sideHit).stream()
                    .anyMatch(pos -> ProtectedAreaHelper.isProtected(ctx.world(), pos))) {
                // The target itself can be outside a protected rectangle while the tool's
                // face-oriented 3x3 reaches into it. Use the best non-AOE tool when AutoTool
                // owns selection; otherwise refuse the unsafe break. Repeat this guard on every
                // damage tick because AutoTool may select the AOE tool again between ticks.
                if (!Baritone.settings().autoTool.value || Baritone.settings().assumeExternalAutoTool.value) {
                    stopBreakingBlock();
                    return;
                }
                IBlockState state = Compat.getBlockState(ctx.world(), trace.getBlockPos());
                int safeSlot = new ToolSet(ctx.player()).getBestSlotWithoutTinkersAoe(
                        state, Baritone.settings().preferSilkTouch.value, trace.getBlockPos());
                if (safeSlot < 0) {
                    stopBreakingBlock();
                    return;
                }
                ctx.player().inventory.currentItem = safeSlot;
                held = ctx.player().getCurrentEquippedItem();
                if (TinkersAoeToolCompat.isAoeHarvestTool(held)) {
                    stopBreakingBlock();
                    return;
                }
                ctx.playerController().syncHeldItem();
            }
            if (!didBreakLastTick) {
                ctx.playerController().syncHeldItem();
                TinkersLumberAxeCompat.onBlockStartBreak(
                        ctx.player(), ctx.world(),
                        trace.getBlockPos().getX(), trace.getBlockPos().getY(), trace.getBlockPos().getZ());
                ctx.playerController().clickBlock(trace.getBlockPos(), trace.sideHit);
                ctx.player().swingItem();
            }

            // Attempt to break the block
            if (ctx.playerController().onPlayerDamageBlock(trace.getBlockPos(), trace.sideHit)) {
                ctx.player().swingItem();
            }

            ctx.playerController().setHittingBlock(false);

            didBreakLastTick = true;
        } else if (didBreakLastTick) {
            stopBreakingBlock();
            didBreakLastTick = false;
        }
    }
}
