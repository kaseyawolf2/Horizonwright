/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package baritone.utils;

import baritone.compat.BlockPos;
import baritone.compat.EnumFacing;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Dependency-free description of the Tinkers' Construct 1.7.10 directional 3x3 tools.
 *
 * <p>Hammer and Excavator both use an {@code AOEHarvestTool} radius of one and depth of zero.
 * The native tools perform their own extra breaks from {@code onBlockStartBreak}; this class only
 * predicts that footprint so Baritone can choose a safe face/tool. A hit on UP or DOWN removes an
 * XZ plane, NORTH or SOUTH removes an XY plane, and WEST or EAST removes a YZ plane.</p>
 *
 * <p>Lumber Axe is detected by {@link #isAoeHarvestTool(ItemStack)} for safe fallback exclusion,
 * but is deliberately omitted from {@link #isDirectional3x3Tool(ItemStack)} because its tree
 * felling has separate lifecycle handling in {@link TinkersLumberAxeCompat}.</p>
 */
public final class TinkersAoeToolCompat {

    private static final String HAMMER_CLASS = "tconstruct.items.tools.Hammer";
    private static final String EXCAVATOR_CLASS = "tconstruct.items.tools.Excavator";
    private static final String AOE_HARVEST_TOOL_CLASS = "tconstruct.library.tools.AOEHarvestTool";

    private TinkersAoeToolCompat() {}

    public static boolean isHammer(ItemStack stack) {
        return hasTypeNamed(stack, HAMMER_CLASS) || hasUnlocalizedToken(stack, "infitool.hammer");
    }

    public static boolean isExcavator(ItemStack stack) {
        return hasTypeNamed(stack, EXCAVATOR_CLASS) || hasUnlocalizedToken(stack, "infitool.excavator");
    }

    public static boolean isDirectional3x3Tool(ItemStack stack) {
        return isHammer(stack) || isExcavator(stack);
    }

    /** Detect any native TConstruct area-harvest tool for safe single-block fallback selection. */
    public static boolean isAoeHarvestTool(ItemStack stack) {
        if (hasTypeNamed(stack, AOE_HARVEST_TOOL_CLASS)) {
            return true;
        }
        // Known 1.7.10 AOE tools, for forks which relocate the library hierarchy.
        return isDirectional3x3Tool(stack) || hasUnlocalizedToken(stack, "infitool.lumberaxe");
    }

    public static boolean isUsableDirectional3x3Tool(ItemStack stack) {
        if (!isDirectional3x3Tool(stack)) {
            return false;
        }
        try {
            return stack.hasTagCompound()
                    && !stack.getTagCompound().getCompoundTag("InfiTool").getBoolean("Broken");
        } catch (Throwable ignored) {
            return true;
        }
    }

    public static boolean hasAreaEffect(EntityPlayer player, ItemStack stack) {
        return player != null && !player.isSneaking() && isUsableDirectional3x3Tool(stack);
    }

    /**
     * Return the conservative 3x3 footprint centered on {@code center} for the struck face.
     * TConstruct may skip individual entries because of its exclusion list, harvest level,
     * relative hardness, or a cancelled Forge break event.
     */
    public static List<BlockPos> affectedBlocks(BlockPos center, EnumFacing face) {
        List<BlockPos> result = new ArrayList<>(9);
        if (center == null || face == null) {
            return result;
        }
        for (int first = -1; first <= 1; first++) {
            for (int second = -1; second <= 1; second++) {
                switch (face.getAxis()) {
                    case X:
                        result.add(center.add(0, first, second));
                        break;
                    case Y:
                        result.add(center.add(first, 0, second));
                        break;
                    case Z:
                        result.add(center.add(first, second, 0));
                        break;
                    default:
                        throw new IllegalStateException("Unknown directional AOE face axis " + face.getAxis());
                }
            }
        }
        return result;
    }

    private static boolean hasTypeNamed(ItemStack stack, String className) {
        if (stack == null || stack.getItem() == null) {
            return false;
        }
        Item item = stack.getItem();
        for (Class<?> type = item.getClass(); type != null; type = type.getSuperclass()) {
            if (className.equals(type.getName())) {
                return true;
            }
        }
        return false;
    }

    private static boolean hasUnlocalizedToken(ItemStack stack, String token) {
        if (stack == null || stack.getItem() == null) {
            return false;
        }
        try {
            String name = stack.getItem().getUnlocalizedName(stack);
            return name != null && name.toLowerCase(Locale.ROOT).contains(token);
        } catch (Throwable ignored) {
            return false;
        }
    }
}
