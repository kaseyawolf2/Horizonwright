/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package baritone.utils;

import baritone.Baritone;
import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemBucket;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;

import java.util.Locale;

/** Shared, dependency-free classification for inventory automation. */
public final class InventoryItemHelper {

    private InventoryItemHelper() {}

    public static boolean isPortableStorage(ItemStack stack) {
        String normalized = identity(stack);
        if (normalized == null) {
            return false;
        }
        for (String identifier : Baritone.settings().portableStorageIdentifiers.value) {
            if (identifier != null && !identifier.isEmpty()
                    && normalized.contains(identifier.toLowerCase(Locale.ROOT).replace(" ", ""))) {
                return true;
            }
        }
        return false;
    }

    /** Remote network access items are usable, but must never be drained during chest drop-off. */
    public static boolean isRemoteStorageTerminal(ItemStack stack) {
        String normalized = identity(stack);
        return normalized != null
                && (normalized.contains("wireless") || normalized.contains("terminal"))
                && !normalized.contains("enderpouch") && !normalized.contains("ender_pouch");
    }

    private static String identity(ItemStack stack) {
        if (stack == null || stack.getItem() == null) {
            return null;
        }
        Item item = stack.getItem();
        StringBuilder identity = new StringBuilder(item.getClass().getName());
        try {
            identity.append(' ').append(item.getUnlocalizedName(stack));
        } catch (Throwable ignored) {}
        try {
            GameRegistry.UniqueIdentifier id = GameRegistry.findUniqueIdentifierFor(item);
            if (id != null) {
                identity.append(' ').append(id.modId).append(':').append(id.name);
            }
        } catch (Throwable ignored) {}
        return identity.toString().toLowerCase(Locale.ROOT).replace(" ", "");
    }

    public static boolean isTool(ItemStack stack) {
        if (stack == null || stack.getItem() == null) {
            return false;
        }
        try {
            if (!stack.getItem().getToolClasses(stack).isEmpty()) {
                return true;
            }
        } catch (Throwable ignored) {}
        return stack.getItem() instanceof ItemSword;
    }

    /** A block-breaking tool, excluding weapons that merely count as operational equipment. */
    public static boolean isMiningTool(ItemStack stack) {
        if (stack == null || stack.getItem() == null) {
            return false;
        }
        try {
            return !stack.getItem().getToolClasses(stack).isEmpty();
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static boolean isSafeFood(ItemStack stack) {
        if (stack == null || !(stack.getItem() instanceof ItemFood)) {
            return false;
        }
        Item item = stack.getItem();
        if (item == net.minecraft.init.Items.rotten_flesh
                || item == net.minecraft.init.Items.spider_eye
                || item == net.minecraft.init.Items.poisonous_potato
                || item == net.minecraft.init.Items.chicken
                || item == net.minecraft.init.Items.golden_apple) {
            return false;
        }
        return !(item == net.minecraft.init.Items.fish && stack.getItemDamage() == 3);
    }

    /** Items kept in the player inventory when unloading into a portable store. */
    public static boolean isOperational(ItemStack stack) {
        if (stack == null) {
            return false;
        }
        Item item = stack.getItem();
        return isPortableStorage(stack)
                || isTool(stack)
                || isSafeFood(stack)
                || item instanceof ItemArmor
                || item instanceof ItemBow
                || item instanceof ItemBucket;
    }
}
