/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package baritone.utils;

import baritone.compat.BlockPos;
import net.minecraft.block.Block;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

import java.lang.reflect.Method;

/**
 * Optional, reflection-only compatibility with GTNH's CropsNH crop sticks.
 *
 * CropsNH stores the planted crop and its growth progress in a tile entity, so the block neither
 * implements {@code IGrowable} nor exposes ripeness through metadata. Keeping this bridge free of a
 * compile-time CropsNH dependency lets the same Baritone jar run with or without the mod installed.
 */
public final class CropsNHCompat {

    private static final String CROP_STICKS_ID = "cropsnh:cropSticks";

    private static Class<?> cachedTileClass;
    private static Method hasCrop;
    private static Method hasWeed;
    private static Method isSick;
    private static Method isCrossCrop;
    private static Method isMature;

    private CropsNHCompat() {}

    /**
     * @return the CropsNH crop-stick block, or {@code null} when CropsNH is not installed
     */
    public static Block cropSticksBlock() {
        return Block.getBlockFromName(CROP_STICKS_ID);
    }

    public static boolean isCropSticks(Block block) {
        Block cropSticks = cropSticksBlock();
        return cropSticks != null && cropSticks == block;
    }

    /**
     * Tests only state which CropsNH synchronizes to the client. Its {@code canHarvest()} method
     * cannot be used here because that method deliberately returns false for a remote/client world.
     * The server performs the final requirements check when Baritone sends the real right-click.
     */
    public static boolean isReadyToHarvest(World world, BlockPos pos) {
        if (world == null || pos == null) {
            return false;
        }
        TileEntity tile = world.getTileEntity(pos.getX(), pos.getY(), pos.getZ());
        if (tile == null) {
            return false;
        }
        try {
            initializeMethods(tile.getClass());
            return invokeBoolean(hasCrop, tile)
                    && !invokeBoolean(hasWeed, tile)
                    && !invokeBoolean(isSick, tile)
                    && !invokeBoolean(isCrossCrop, tile)
                    && invokeBoolean(isMature, tile);
        } catch (ReflectiveOperationException | RuntimeException | LinkageError ignored) {
            // CropsNH changed its API or this is not its crop-stick tile. Fail closed: never click it.
            return false;
        }
    }

    private static void initializeMethods(Class<?> tileClass) throws NoSuchMethodException {
        if (cachedTileClass == tileClass) {
            return;
        }
        Method newHasCrop = tileClass.getMethod("hasCrop");
        Method newHasWeed = tileClass.getMethod("hasWeed");
        Method newIsSick = tileClass.getMethod("isSick");
        Method newIsCrossCrop = tileClass.getMethod("isCrossCrop");
        Method newIsMature = tileClass.getMethod("isMature");

        // Publish the class last so a partial reflective lookup can never be treated as initialized.
        hasCrop = newHasCrop;
        hasWeed = newHasWeed;
        isSick = newIsSick;
        isCrossCrop = newIsCrossCrop;
        isMature = newIsMature;
        cachedTileClass = tileClass;
    }

    private static boolean invokeBoolean(Method method, Object target) throws ReflectiveOperationException {
        return Boolean.TRUE.equals(method.invoke(target));
    }
}
