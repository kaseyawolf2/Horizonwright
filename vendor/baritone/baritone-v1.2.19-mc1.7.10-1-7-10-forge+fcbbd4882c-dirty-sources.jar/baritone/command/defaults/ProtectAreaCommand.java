/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package baritone.command.defaults;

import baritone.Baritone;
import baritone.api.IBaritone;
import baritone.api.command.Command;
import baritone.api.command.argument.IArgConsumer;
import baritone.api.command.exception.CommandException;
import baritone.api.command.exception.CommandInvalidTypeException;
import baritone.api.command.helpers.TabCompleteHelper;
import baritone.api.utils.SettingsUtil;
import baritone.utils.ProtectedAreaHelper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class ProtectAreaCommand extends Command {

    public ProtectAreaCommand(IBaritone baritone) {
        super(baritone, "protectarea", "protectedarea", "pa");
    }

    @Override
    public void execute(String label, IArgConsumer args) throws CommandException {
        args.requireMin(1);
        args.requireMax(5);

        String action = args.getString().toLowerCase();
        int dimension = ctx.world().provider.dimensionId;

        if (action.equals("list")) {
            args.requireMax(0);
            List<String> currentDimension = new ArrayList<>();
            String prefix = dimension + ":";
            for (String entry : Baritone.settings().protectedAreas.value) {
                if (entry.startsWith(prefix)) {
                    currentDimension.add("[" + entry.substring(prefix.length()).replace(':', ',') + "]");
                }
            }
            logDirect(currentDimension.isEmpty()
                    ? "No protected areas in dimension " + dimension
                    : "Protected areas in dimension " + dimension + ": " + String.join("; ", currentDimension));
            return;
        }

        if (action.equals("clear")) {
            args.requireMax(0);
            List<String> updated = new ArrayList<>(Baritone.settings().protectedAreas.value);
            String prefix = dimension + ":";
            updated.removeIf(entry -> entry.startsWith(prefix));
            apply(updated);
            logDirect("Cleared protected areas in dimension " + dimension);
            return;
        }

        if (!action.equals("add") && !action.equals("remove")) {
            throw new CommandInvalidTypeException(args.consumed(), "add, remove, list, or clear");
        }

        args.requireMin(4);
        args.requireMax(4);
        int x1 = args.getAs(Integer.class);
        int z1 = args.getAs(Integer.class);
        int x2 = args.getAs(Integer.class);
        int z2 = args.getAs(Integer.class);

        String key = ProtectedAreaHelper.key(dimension, x1, z1, x2, z2);
        List<String> updated = new ArrayList<>(Baritone.settings().protectedAreas.value);
        boolean changed = action.equals("add") ? !updated.contains(key) && updated.add(key) : updated.remove(key);
        apply(updated);
        ((Baritone) baritone).getInputOverrideHandler().getBlockBreakHelper().stopBreakingBlock();

        String[] normalized = key.split(":", 5);
        String area = "[" + normalized[1] + "," + normalized[2] + "," + normalized[3] + "," + normalized[4] + "]";
        logDirect((action.equals("add") ? "Protected area " : "Unprotected area ") + area
                + " in dimension " + dimension + (changed ? "" : " (no change)"));
    }

    private static void apply(List<String> updated) {
        if (updated.isEmpty()) {
            Baritone.settings().protectedAreas.reset();
        } else {
            Baritone.settings().protectedAreas.value = updated;
        }
        SettingsUtil.save(Baritone.settings());
    }

    @Override
    public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandException {
        if (args.hasExactlyOne()) {
            return new TabCompleteHelper().append("add", "remove", "list", "clear").filterPrefix(args.peekString()).stream();
        }
        return Stream.empty();
    }

    @Override
    public String getShortDesc() {
        return "Protect block-coordinate areas from breaking";
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList(
                "Prevents Baritone from breaking blocks inside horizontal rectangular areas at every Y level.",
                "Coordinates are normalized, so either corner may be supplied first. Protection is dimension-aware and persistent.",
                "Walking through and placing blocks in a protected area are still allowed.",
                "",
                "Usage:",
                "> protectarea add <x1> <z1> <x2> <z2> - Protect an inclusive rectangular area.",
                "> protectarea remove <x1> <z1> <x2> <z2> - Remove that exact area.",
                "> protectarea list - List protected areas in this dimension.",
                "> protectarea clear - Clear protected areas in this dimension."
        );
    }
}
