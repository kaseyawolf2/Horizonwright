/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.command.defaults;

import baritone.Baritone;
import baritone.api.IBaritone;
import baritone.api.command.Command;
import baritone.api.command.argument.IArgConsumer;
import baritone.api.command.exception.CommandException;
import baritone.api.command.datatypes.RelativeBlockPos;
import baritone.api.utils.BetterBlockPos;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class CircleCommand extends Command {

    public CircleCommand(IBaritone baritone) {
        super(baritone, "circle", "cylinder");
    }

    @Override
    public void execute(String label, IArgConsumer args) throws CommandException {
        args.requireMax(4);
        int radius = args.getAs(Integer.class);
        if (radius < 1) {
            logDirect("Radius must be at least 1 block.");
            return;
        }
        BetterBlockPos center = args.hasAny()
                ? args.getDatatypePost(RelativeBlockPos.INSTANCE, ctx.playerFeet())
                : ctx.playerFeet();
        if (center.y <= 1) {
            logDirect("Center is already at bedrock level.");
            return;
        }
        int diameter = 2 * radius + 1;
        logDirect(String.format("Digging a circle of radius %d (%dx%d) centered at %d,%d from y=%d down to bedrock, using %s target priority", radius, diameter, diameter, center.x, center.z, center.y, Baritone.settings().mineTargetPriority.value));
        ((Baritone) baritone).getCircleProcess().dig(center.x, center.z, radius, center.y);
    }

    @Override
    public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandException {
        if (args.has(2) && args.hasAtMost(4)) {
            args.get(); // radius
            return args.tabCompleteDatatype(RelativeBlockPos.INSTANCE);
        }
        return Stream.empty();
    }

    @Override
    public String getShortDesc() {
        return "Dig a circle down to bedrock";
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList(
                "The circle command digs a circular shaft of the given radius, centered on the block",
                "you are standing on (or a given position), from that level all the way down to bedrock.",
                "It uses the control panel's target-priority style and only targets known blocks, so",
                "large circles (radius 100+) dig outward from you instead of walking off to a far edge.",
                "Bedrock itself is left alone, so the dig finishes cleanly at the bottom of the world.",
                "",
                "Usage:",
                "> circle <radius> - Dig a circle of the given radius (diameter = 2*radius+1) to bedrock.",
                "> circle <radius> <x> <y> <z> - Same, but centered at x,z digging down from y.",
                "Coordinates may be relative, e.g. circle 10 ~20 ~ ~ for a circle 20 blocks east of you."
        );
    }
}
