package baritone.command.defaults;

import baritone.Baritone;
import baritone.api.IBaritone;
import baritone.api.command.Command;
import baritone.api.command.argument.IArgConsumer;
import baritone.api.command.exception.CommandException;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class ControlPanelCommand extends Command {

    public ControlPanelCommand(IBaritone baritone) {
        super(baritone, "controlpanel", "panel", "gui");
    }

    @Override
    public void execute(String label, IArgConsumer args) throws CommandException {
        args.requireMax(0);
        ((Baritone) baritone).openControlPanel();
    }

    @Override
    public Stream<String> tabComplete(String label, IArgConsumer args) {
        return Stream.empty();
    }

    @Override
    public String getShortDesc() {
        return "Open the Baritone control panel";
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList("Opens a graphical control panel for settings, mining priorities, protected areas, and task controls.", "", "Usage:", "> panel");
    }
}
