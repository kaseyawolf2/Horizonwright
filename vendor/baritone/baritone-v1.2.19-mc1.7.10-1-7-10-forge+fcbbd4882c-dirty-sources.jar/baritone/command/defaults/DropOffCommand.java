/*
 * This file is part of Baritone.
 *
 * Baritone is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Baritone is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Baritone.  If not, see <https://www.gnu.org/licenses/>.
 */

package baritone.command.defaults;

import baritone.Baritone;
import baritone.api.IBaritone;
import baritone.api.command.Command;
import baritone.api.command.argument.IArgConsumer;
import baritone.api.command.exception.CommandException;
import baritone.api.command.exception.CommandInvalidStateException;
import baritone.api.utils.BetterBlockPos;
import baritone.process.DropOffProcess;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Stream;

/** Configure the per-world chest used by automated gathering processes. */
public final class DropOffCommand extends Command {

    public DropOffCommand(IBaritone baritone) {
        super(baritone, "dropoff", "deposit");
    }

    @Override
    public void execute(String label, IArgConsumer args) throws CommandException {
        DropOffProcess process = ((Baritone) baritone).getDropOffProcess();
        String action = args.hasAny() ? args.getString().toLowerCase(Locale.US) : "set";
        args.requireMax(0);

        switch (action) {
            case "set": {
                Optional<baritone.compat.BlockPos> selected = ctx.getSelectedBlock();
                if (!selected.isPresent()) {
                    throw new CommandInvalidStateException("Look directly at the chest to designate, then run #dropoff set");
                }
                BetterBlockPos chest = BetterBlockPos.from(selected.get());
                if (!process.isStorageAt(chest)) {
                    throw new CommandInvalidStateException("The selected block is not an inventory-bearing chest or storage block");
                }
                process.setDesignation(chest);
                logDirect(String.format("Drop-off chest set to %d, %d, %d", chest.x, chest.y, chest.z));
                break;
            }
            case "clear":
            case "reset":
                if (process.clearDesignation()) {
                    logDirect("Drop-off chest cleared");
                } else {
                    logDirect("No drop-off chest was designated");
                }
                break;
            case "status": {
                BetterBlockPos chest = process.getDesignation();
                if (chest == null) {
                    logDirect("No drop-off chest is designated");
                } else {
                    logDirect(String.format("Drop-off chest: %d, %d, %d", chest.x, chest.y, chest.z));
                }
                break;
            }
            default:
                throw new CommandInvalidStateException("Expected set, clear, or status");
        }
    }

    @Override
    public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandException {
        if (!args.hasExactlyOne()) {
            return Stream.empty();
        }
        String prefix = args.getString().toLowerCase(Locale.US);
        return Stream.of("set", "clear", "status").filter(action -> action.startsWith(prefix));
    }

    @Override
    public String getShortDesc() {
        return "Designate an automatic drop-off chest";
    }

    @Override
    public List<String> getLongDesc() {
        return Arrays.asList(
                "Designates a per-world chest or GUI-backed modded inventory for mining, circle digging, and farming output.",
                "This includes Iron Chests, EnderStorage chests, and Binnie Core compartments.",
                "When all 27 standard inventory slots are occupied, Baritone temporarily travels",
                "to this chest, shift-clicks only those standard slots into it, closes it, and resumes.",
                "The nine hotbar slots are never moved.",
                "",
                "Usage:",
                "> dropoff set - Designate the chest you are looking at.",
                "> dropoff clear - Remove the designation and disable automatic unloading.",
                "> dropoff status - Show the designated chest coordinates."
        );
    }
}
